"""Cross-document ingestion for Context Receipts."""

from __future__ import annotations

import os
import re
from collections.abc import Mapping, Sequence
from pathlib import Path, PurePath

from .models import (
    SCHEMA_VERSION,
    ContextIndex,
    DocumentChunk,
    DocumentRecord,
    byte_digest,
    stable_hash,
    text_fingerprint,
)

DOCUMENT_EXTENSIONS = frozenset({
    ".txt",
    ".md",
    ".markdown",
    ".rst",
})

SOURCE_EXTENSIONS = frozenset({
    ".c",
    ".cc",
    ".cpp",
    ".cs",
    ".css",
    ".go",
    ".h",
    ".hpp",
    ".html",
    ".java",
    ".js",
    ".jsx",
    ".json",
    ".kt",
    ".mjs",
    ".py",
    ".rb",
    ".rs",
    ".sh",
    ".sql",
    ".swift",
    ".toml",
    ".ts",
    ".tsx",
    ".xml",
    ".yaml",
    ".yml",
})

SUPPORTED_FILENAMES = frozenset({
    "Containerfile",
    "Dockerfile",
    "Justfile",
    "Makefile",
    "Procfile",
    "Rakefile",
})

SUPPORTED_FILENAME_PREFIXES = (
    "Containerfile.",
    "Dockerfile.",
)

SUPPORTED_EXTENSIONS = DOCUMENT_EXTENSIONS | SOURCE_EXTENSIONS

SKIP_DIRECTORIES = frozenset({
    ".entroly",
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".svn",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "target",
    "venv",
})

SKIP_DIRECTORY_SUFFIXES = (
    ".egg-info",
)

SKIP_FILENAMES = frozenset({
    "Cargo.lock",
    "Gemfile.lock",
    "Pipfile.lock",
    "bun.lockb",
    "composer.lock",
    "package-lock.json",
    "pnpm-lock.yaml",
    "poetry.lock",
    "yarn.lock",
})

TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_\-']*|[^\w\s]", re.UNICODE)
HEADING_RE = re.compile(
    r"^\s{0,3}(#{1,6}\s+.+|"
    r"(?:section|article|clause|exhibit|schedule|addendum)\s+[A-Za-z0-9.\-]+.*|"
    r"\d+(?:\.\d+)*\s+.+)$",
    re.IGNORECASE,
)
PAGE_RE = re.compile(r"\bpage\s+(\d+)\b", re.IGNORECASE)

# Headings are a *document* concept. Applying HEADING_RE to source code is not a
# near-miss: its first alternation is `#{1,6}\s+.+`, which matches an ordinary
# Python, Ruby, shell, YAML or TOML comment, so every comment line was treated as
# a section heading and forced a chunk boundary. Source files have no headings,
# so no pattern is applied to them at all.
HEADING_AWARE_EXTENSIONS = DOCUMENT_EXTENSIONS


def _heading_pattern(source_path: str) -> re.Pattern[str] | None:
    """Return the heading matcher for this document type, or None for source code."""
    return (
        HEADING_RE
        if Path(source_path).suffix.lower() in HEADING_AWARE_EXTENSIONS
        else None
    )


def _int_or_default(value: object, default: int) -> int:
    if isinstance(value, bool):
        return default
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _overlap_tokens_or_default(
    value: object, *, chunk_tokens: int, default: int = 32
) -> int:
    overlap = max(0, _int_or_default(value, default))
    max_overlap = max(0, chunk_tokens - 1)
    return min(overlap, max_overlap)


def _source_path_to_str(source: object) -> str:
    if isinstance(source, PurePath):
        return source.as_posix()
    return str(source)


def normalize_document_pairs(documents: object) -> list[tuple[str, str]]:
    """Return deterministic ``(source_path, text)`` pairs from public input.

    Public SDK callers and older integrations occasionally pass ``Path`` objects,
    bytes text, mapping-shaped records, or malformed rows.  Normalize valid rows
    and skip rows that cannot identify both a source and text so ingestion never
    fails before receipt generation can produce an auditable empty result.
    """
    pairs: list[tuple[str, str]] = []
    if isinstance(documents, Mapping) or isinstance(documents, str | bytes):
        iterable = ()
    else:
        try:
            iterable = iter(documents)  # type: ignore[arg-type]
        except TypeError:
            iterable = ()

    for item in iterable:
        source: object
        text: object
        if isinstance(item, Mapping):
            source = item.get("source_path", item.get("path"))
            text = item.get("text", item.get("content"))
        elif isinstance(item, Sequence) and not isinstance(item, str | bytes):
            if len(item) < 2:
                continue
            source, text = item[0], item[1]
        else:
            continue
        if source is None or text is None:
            continue
        if isinstance(text, bytes):
            normalized_text = text.decode("utf-8", errors="replace")
        else:
            normalized_text = str(text)
        pairs.append((_source_path_to_str(source), normalized_text))
    return pairs


def estimate_tokens(text: str) -> int:
    return max(1, len(TOKEN_RE.findall(text)))


def _byte_offset(text: str, char_offset: int) -> int:
    return len(text[:char_offset].encode("utf-8"))


def _clean_heading(line: str) -> str:
    return line.strip().lstrip("#").strip()


def _title_for_path(source_path: str) -> str:
    name = Path(source_path).name
    return Path(name).stem.replace("_", " ").replace("-", " ").strip() or name


def _is_skipped_directory(name: str) -> bool:
    return name in SKIP_DIRECTORIES or name.endswith(SKIP_DIRECTORY_SUFFIXES)


def _is_skipped_filename(name: str) -> bool:
    return name in SKIP_FILENAMES


def _has_supported_filename(name: str) -> bool:
    return name in SUPPORTED_FILENAMES or name.startswith(SUPPORTED_FILENAME_PREFIXES)


def _is_supported_document_path(path: Path) -> bool:
    return (
        path.is_file()
        and not _is_skipped_filename(path.name)
        and (path.suffix.lower() in SUPPORTED_EXTENSIONS or _has_supported_filename(path.name))
    )


def _discover_supported_paths(root: Path) -> list[Path]:
    if root.is_file():
        return [root] if _is_supported_document_path(root) else []

    paths: list[Path] = []
    for current_root, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if not _is_skipped_directory(d))
        current_path = Path(current_root)
        for filename in sorted(filenames):
            candidate = current_path / filename
            if _is_supported_document_path(candidate):
                paths.append(candidate)
    return paths


def supported_documents_hint() -> str:
    extensions = ", ".join(sorted(DOCUMENT_EXTENSIONS | SOURCE_EXTENSIONS))
    filenames = ", ".join(sorted(SUPPORTED_FILENAMES | {"Dockerfile.*", "Containerfile.*"}))
    return f"Use supported text/source files ({extensions}) or filenames ({filenames})."


def read_documents_from_path(path: str | Path) -> list[tuple[str, str]]:
    root = Path(path)
    paths = _discover_supported_paths(root)
    documents: list[tuple[str, str]] = []
    for p in paths:
        source_path = p.as_posix()
        # Read bytes and decode explicitly. Path.read_text() applies universal
        # newline translation, so on a CRLF checkout the indexed text differed
        # from the file before chunking even began and no byte range could
        # recover the original. Recovery is a byte contract; do not normalize.
        raw = p.read_bytes()
        try:
            documents.append((source_path, raw.decode("utf-8")))
        except UnicodeDecodeError:
            documents.append((source_path, raw.decode("utf-8", errors="replace")))
    return documents


def _paragraph_blocks(
    text: str, heading_pattern: re.Pattern[str] | None = HEADING_RE
) -> list[dict[str, object]]:
    blocks: list[dict[str, object]] = []
    current: list[str] = []
    start: int | None = None
    line_start = 0
    heading: str | None = None
    page: int | None = None

    def flush(end: int) -> None:
        nonlocal current, start
        if not current or start is None:
            current = []
            start = None
            return
        joined = "".join(current)
        # Trim by *offset*, never by rebuilding the string: the block must stay
        # addressable as text[block_start:block_end] so a byte range can recover
        # it exactly. `.strip()` here used to discard the leading indentation of
        # the first line while `start` still pointed before it, which both
        # altered the text and skewed every offset derived from it.
        lead = len(joined) - len(joined.lstrip())
        trail = len(joined) - len(joined.rstrip())
        block_start = start + lead
        block_end = start + len(joined) - trail
        if block_end > block_start:
            blocks.append(
                {
                    "text": text[block_start:block_end],
                    "start": block_start,
                    "end": block_end,
                    "heading": heading,
                    "page": page,
                }
            )
        current = []
        start = None

    for line in text.splitlines(keepends=True):
        stripped = line.strip()
        match = PAGE_RE.search(stripped)
        if match:
            try:
                page = int(match.group(1))
            except ValueError:
                pass
        if "\f" in line:
            page = 1 if page is None else page + line.count("\f")

        if stripped and heading_pattern is not None and heading_pattern.match(stripped):
            flush(line_start)
            heading = _clean_heading(stripped)

        if not stripped:
            flush(line_start)
        else:
            if start is None:
                start = line_start
            current.append(line)
        line_start += len(line)
    flush(len(text))
    return blocks


def _token_spans(text: str) -> list[re.Match[str]]:
    return list(TOKEN_RE.finditer(text))


def _split_large_block(
    source_text: str,
    block: dict[str, object],
    *,
    chunk_tokens: int,
    overlap_tokens: int,
) -> list[dict[str, object]]:
    block_text = str(block["text"])
    tokens = _token_spans(block_text)
    if not tokens:
        return []
    chunks: list[dict[str, object]] = []
    step = max(1, chunk_tokens - max(0, overlap_tokens))
    block_start = int(block["start"])
    for token_start in range(0, len(tokens), step):
        token_end = min(len(tokens), token_start + chunk_tokens)
        # Token offsets are relative to the block, and the block is now exactly
        # source_text[block_start:block_end], so adding block_start yields a true
        # source offset. Slice the source with it so the text and the range agree
        # by construction rather than by coincidence.
        start = block_start + tokens[token_start].start()
        end = block_start + tokens[token_end - 1].end()
        chunks.append(
            {
                "text": source_text[start:end],
                "start": start,
                "end": end,
                "heading": block.get("heading"),
                "page": block.get("page"),
            }
        )
        if token_end >= len(tokens):
            break
    return chunks


def _chunk_document(
    source_path: str,
    text: str,
    *,
    document_id: str,
    document_fingerprint: str,
    source_digest: str,
    chunk_tokens: int,
    overlap_tokens: int,
) -> list[DocumentChunk]:
    blocks = _paragraph_blocks(text, _heading_pattern(source_path))
    chunks_raw: list[dict[str, object]] = []
    pending = 0
    start: int | None = None
    end = 0
    heading: str | None = None
    page: int | None = None
    token_count = 0

    def flush() -> None:
        nonlocal pending, start, end, heading, page, token_count
        if not pending or start is None:
            pending = 0
            start = None
            token_count = 0
            return
        chunks_raw.append(
            {
                # Splice the original span rather than rejoining the blocks.
                # `"\n\n".join(...)` inserted a blank line between blocks that
                # were adjacent in the source, so the chunk contained bytes that
                # existed nowhere in the file and could never be recovered.
                "text": text[start:end],
                "start": start,
                "end": end,
                "heading": heading,
                "page": page,
            }
        )
        pending = 0
        start = None
        token_count = 0

    for block in blocks:
        btokens = estimate_tokens(str(block["text"]))
        if btokens > chunk_tokens:
            flush()
            chunks_raw.extend(
                _split_large_block(
                    text,
                    block,
                    chunk_tokens=chunk_tokens,
                    overlap_tokens=overlap_tokens,
                )
            )
            continue
        if pending and token_count + btokens > chunk_tokens:
            flush()
        if start is None:
            start = int(block["start"])
            heading = (
                block.get("heading") if isinstance(block.get("heading"), str) else None
            )
            page = block.get("page") if isinstance(block.get("page"), int) else None
        pending += 1
        end = int(block["end"])
        token_count += btokens
    flush()

    title = _title_for_path(source_path)
    result: list[DocumentChunk] = []
    running_tokens = 0
    for idx, raw in enumerate(chunks_raw):
        chunk_text = str(raw["text"])
        count = estimate_tokens(chunk_text)
        start_char = int(raw["start"])
        end_char = int(raw["end"])
        fp = text_fingerprint(
            f"{document_fingerprint}\n{start_char}:{end_char}\n{chunk_text}"
        )
        chunk_id = (
            "chk_"
            + stable_hash(
                {
                    "doc": document_id,
                    "start": start_char,
                    "end": end_char,
                    "fingerprint": fp,
                }
            )[:12]
        )
        result.append(
            DocumentChunk(
                chunk_id=chunk_id,
                document_id=document_id,
                source_path=source_path,
                title=title,
                section_heading=raw.get("heading")
                if isinstance(raw.get("heading"), str)
                else None,
                page_number=raw.get("page")
                if isinstance(raw.get("page"), int)
                else None,
                chunk_index=idx,
                byte_start=_byte_offset(text, start_char),
                byte_end=_byte_offset(text, end_char),
                token_start=running_tokens,
                token_end=running_tokens + count,
                token_count=count,
                fingerprint=fp,
                text=chunk_text,
                fragment_sha256=byte_digest(chunk_text),
                source_sha256=source_digest,
            )
        )
        running_tokens += count
    return result


def ingest_documents(
    documents: list[tuple[str, str]],
    *,
    chunk_tokens: int = 360,
    overlap_tokens: int = 32,
) -> ContextIndex:
    records: list[DocumentRecord] = []
    chunks: list[DocumentChunk] = []
    source_fingerprints: dict[str, str] = {}
    chunk_token_count = max(40, _int_or_default(chunk_tokens, 360))
    overlap_token_count = _overlap_tokens_or_default(
        overlap_tokens, chunk_tokens=chunk_token_count
    )

    for source_path, text in sorted(
        normalize_document_pairs(documents), key=lambda item: item[0]
    ):
        doc_fp = text_fingerprint(text)
        doc_id = (
            "doc_" + stable_hash({"source": source_path, "fingerprint": doc_fp})[:12]
        )
        doc_chunks = _chunk_document(
            source_path,
            text,
            document_id=doc_id,
            document_fingerprint=doc_fp,
            source_digest=byte_digest(text),
            chunk_tokens=chunk_token_count,
            overlap_tokens=overlap_token_count,
        )
        source_fingerprints[source_path] = doc_fp
        records.append(
            DocumentRecord(
                document_id=doc_id,
                source_path=source_path,
                title=_title_for_path(source_path),
                fingerprint=doc_fp,
                token_count=estimate_tokens(text),
                byte_count=len(text.encode("utf-8")),
                chunk_ids=[c.chunk_id for c in doc_chunks],
                source_sha256=byte_digest(text),
            )
        )
        chunks.extend(doc_chunks)

    return ContextIndex(
        schema_version=SCHEMA_VERSION,
        documents=records,
        chunks=chunks,
        chunk_token_limit=chunk_token_count,
        chunk_overlap=overlap_token_count,
        source_fingerprints=source_fingerprints,
    )
