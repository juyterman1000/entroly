"""
Entroly — Information-Theoretic Context Optimization for Agentic AI
========================================================================

An MCP server that mathematically optimizes what goes into an LLM's
context window. Uses knapsack dynamic programming, Shannon entropy scoring,
SimHash deduplication, and predictive pre-fetching to cut token costs by
50–70% while improving agent accuracy.

Quick Setup (Cursor)::

    Add to .cursor/mcp.json:
    {
      "mcpServers": {
        "entroly": {
          "command": "entroly"
        }
      }
    }

Quick Setup (Claude Code)::

    claude mcp add entroly -- entroly

"""

__version__ = "1.0.78"

try:
    from .sdk import (  # noqa: F401
        compress,
        compress_messages,
        compress_with_receipt,
        verify,
    )
    from .sdk import detect_hallucination, optimize  # noqa: F401
    from .sdk import eicv_verify, eicv_suppress  # noqa: F401
    from .sdk import (  # noqa: F401
        context_receipt_from_path,
        create_context_receipt,
        explain_receipt_omission,
        render_context_receipt,
    )
except ImportError:
    pass  # Graceful degradation if dependencies missing

# Context Commit: portable, content-addressed proof of what an agent received.
try:
    from .context_commit import (  # noqa: F401
        ContextCommitVerification,
        create_context_commit,
        replay_context,
        verify_context_commit,
    )
except ImportError:
    pass

# Verified AI efficiency layer: secure intake, proof-carrying context,
# hallucination suppression, exact recovery, and verified-only evolution.
try:
    from .verified_efficiency import (  # noqa: F401
        AuditArtifact,
        AuditUnavailableError,
        AuditVerification,
        ContextRiskError,
        EfficiencyLayerError,
        EvolutionEvidenceError,
        LearningReceipt,
        PreparedContext,
        RecoveredContext,
        RecoveryIntegrityError,
        UnsafeContextError,
        VerificationFailureError,
        VerifiedEfficiencyLayer,
        VerifiedOutput,
    )
except ImportError:
    pass

# Proof-guided fixed point: bounded claim verification, exact evidence
# rehydration, monotonic context expansion, and signed round decisions.
try:
    from .context_fixed_point import (  # noqa: F401
        EvidenceCandidate,
        EvidenceObligation,
        EvidencePlan,
        FixedPointError,
        FixedPointModelError,
        FixedPointModelRequest,
        FixedPointRecoveryError,
        FixedPointResult,
        FixedPointRound,
        FixedPointSession,
        FixedPointStep,
        FixedPointVerificationError,
        ProofGuidedRecoveryPlanner,
        advance_proof_guided_fixed_point,
        run_proof_guided_fixed_point,
        start_proof_guided_fixed_point,
    )
except ImportError:
    pass

# Durable host adapter used by MCP, HTTP sidecars, CLI, and agent plugins.
try:
    from .proof_guided_runtime import (  # noqa: F401
        ProofGuidedRuntime,
        ProofGuidedRuntimeError,
        ProofGuidedSessionConflict,
        ProofGuidedSessionNotFound,
    )
except ImportError:
    pass

# engine_s6 — public file-localization API (used internally by SDK / MCP /
# proxy / CLI; also callable directly for advanced agent integrations).
try:
    from .file_localizer import localize_files, localize_fragments  # noqa: F401
except ImportError:
    pass

# Verification SDK: hallucination detection + suppression
try:
    from .verifiers import trace_provenance, forge_loop  # noqa: F401
except ImportError:
    pass  # Verifiers are available but don't block core functionality

try:
    from .witness import WitnessAnalyzer  # noqa: F401
except ImportError:
    pass

# EICV — Evidence-Invariant Causal Verification.
# Deterministic hallucination detector. See benchmarks/results/ for the
# specific datasets, splits, and accuracy numbers achieved in our test
# runs. No claims of superiority over any specific external system.
try:
    from .eicv import EICVAnalyzer, EICVCertificate  # noqa: F401
    from .eicv_suppressor import EICVSuppressor  # noqa: F401
    from .esg import ESGAnalyzer, compute_tension  # noqa: F401
except ImportError:
    pass

# STAVE — Semantic Triplet Alignment Via Extraction.
# Binary-relational hallucination verifier. Novel: checks whether the
# *relationship* between entities in the answer matches knowledge, not
# just whether individual tokens appear. Wrong-slot gate: 100% precision.
# Already wired into WitnessAnalyzer (use_stave=True by default).
try:
    from .verifiers.stave import stave_verify, stave_risk  # noqa: F401
except ImportError:
    pass

# Local NLI — zero-API entailment using DeBERTa-v3-small (~80MB).
# Enable: WitnessAnalyzer(use_local_nli=True) or ENTROLY_LOCAL_NLI=1.
try:
    from .verifiers.local_nli import nli_score, is_available as nli_available  # noqa: F401
except ImportError:
    pass

# ── Breakthrough Inventions ──────────────────────────────────────────

# ESC — Entropic Shell Codec.
# Universal shell compressor: one algorithm replaces 95+ per-tool regex
# patterns.  Uses Shannon entropy scoring + structural classification +
# SimHash dedup + knapsack DP selection.  Works on ANY CLI tool output.
try:
    from .shell_codec import esc_compress, ESCResult  # noqa: F401
except ImportError:
    pass

# ELC — Evidence-Locked Compression.
# Compress around evidence, never through evidence: anchors, query matches,
# outliers, omitted-span receipts, and JSON schema+examples.
try:
    from .evidence_locked_compression import (  # noqa: F401
        CompressionReceipt,
        CompressionResult,
        OmittedSpan,
        compress_evidence_locked,
        compress_payload_messages,
        detect_heavy_content_type,
    )
except ImportError:
    pass

# Optional native ELC fast-path adapter.
try:
    from .native_elc import compress_evidence_locked_fast, native_elc_available  # noqa: F401
except ImportError:
    pass

# Compression Proxy — provider-light request payload compression surface.
try:
    from .compression_proxy import (  # noqa: F401
        ProxyCompressionReceipt,
        ProxyCompressionResult,
        compress_proxy_payload,
        compress_proxy_payload_from_env,
    )
except ImportError:
    pass

# Direct non-monkey-patch proxy integration helper.
try:
    from .compression_proxy_direct import apply_elc_to_proxy_body  # noqa: F401
except ImportError:
    pass

# Compression Retrieval Store — local recoverability for omitted spans.
try:
    from .compression_retrieval_store_secure import (  # noqa: F401
        CompressionRetrievalStore,
        StoredCompression,
        StoredSpan,
    )
except ImportError:
    pass

# Compression dashboard and verification loop.
try:
    from .compression_dashboard import (  # noqa: F401
        CompressionDashboard,
        dashboard_from_proxy_receipts,
        dashboard_from_store,
    )
    from .compression_verification_loop import (  # noqa: F401
        VerificationLoopResult,
        answer_with_retrieval_verification,
    )
except ImportError:
    pass

# Compression MCP server — focused MCP tools for omitted-span retrieval.
try:
    from .compression_mcp import create_compression_mcp_server  # noqa: F401
except ImportError:
    pass

# Live HTTP proxy installer. Exported but intentionally not executed at import
# time; the proxy entry path or embedding app must call it explicitly after
# setting ENTROLY_COMPRESSION_PROXY_MODE=elc. Package imports must be side-effect
# free for wheel builds, Docker quality gates, and downstream libraries.
try:
    from .compression_proxy_live import install_live_compression_proxy  # noqa: F401
except ImportError:
    pass

# SRP — Semantic Resolution Protocol.
# Information-optimal file reads: automatically selects per-block resolution
# (FULL/MEDIUM/LOW/SKIP) based on query relevance and token budget, with caller
# controls for exact FULL/DIFF/range reads and native STRUCTURE outlines.
try:
    from .semantic_resolution import resolve as srp_resolve, SRPResult  # noqa: F401
except ImportError:
    pass

# CMWP — Causal Memory is handled by hippocampus LTM + Ebbinghaus decay.
# See entroly/long_term_memory.py and entroly/checkpoint.py.

# WVH — Witness-Verified Handoff.
# Multi-agent handoff protocol with built-in hallucination filtering.
# Strips contradicted claims before they propagate to downstream agents.
try:
    from .verified_handoff import handoff as wvh_handoff, HandoffBundle  # noqa: F401
except ImportError:
    pass

# Ebbiforge bridge -- optional audit adapter for Ebbiforge Swarm provenance.
try:
    from .integrations.ebbiforge import (  # noqa: F401
        EbbiforgeAuditResult,
        EbbiforgeEntrolyBridge,
        run_swarm_with_entroly,
        summarize_ebbiforge_anomalies,
    )
except ImportError:
    pass

# ACF — Adversarial Context Firewall.
# End-to-end content security: prompt injection detection (20+ patterns),
# Unicode steganography detection, base64 payload detection, repetition
# flooding detection, cryptographic pipeline integrity verification.
try:
    from .context_firewall import scan as acf_scan, sanitize as acf_sanitize  # noqa: F401
    from .context_firewall import IntegrityChain  # noqa: F401
except ImportError:
    pass

# Cache Aligner — provider KV-cache prefix stabilizer (lever #3).
# Hashes injected context and stabilizes it across requests so Anthropic's
# 90% / OpenAI's 50% cached-prefix discounts actually hit. Documented in the
# README as `from entroly import CacheAligner`.
try:
    from .cache_aligner import CacheAligner  # noqa: F401
except ImportError:
    pass

# Control plane -- read-only request planning and transform compliance audit.
try:
    from .control_plane import (  # noqa: F401
        ControlAudit,
        ControlPlaneDecision,
        EntrolyCompressionDecision,
        audit_request_transform,
        canonical_json_dumps,
        plan_request,
        stable_request_fingerprint,
    )
except ImportError:
    pass

try:
    from .image_optimizer import (  # noqa: F401
        ImageOptimizationDecision,
        ImageTokenEstimate,
        estimate_image_tokens,
        estimate_image_tokens_from_dimensions,
        optimize_image_bytes,
        plan_image_optimization,
    )
except ImportError:
    pass

# Cost Cortex — price-aware budget clamp + recoverability ledger (the
# control-plane cost organ). Available to SDK/pip users directly:
#   from entroly import clamp_injected_budget, ProviderPrice, ContextLedger
try:
    from .cost_cortex import (  # noqa: F401
        ContextDecision,
        ContextLedger,
        CostBudget,
        Decision,
        ProviderPrice,
        clamp_injected_budget,
    )
except ImportError:
    pass

# Entroly Memory OS — public, dependency-free memory-control facade.
# Gives users a clean product surface while the native Rust memory stack is
# exposed more deeply over time.
try:
    from .memory import (  # noqa: F401
        MemoryContext,
        MemoryEntry,
        MemoryOS,
        MemorySafetyFinding,
        MemorySafetyResult,
        OmittedMemory,
        SelectedMemory,
    )
except ImportError:
    pass

# Loop/harness session controls: receipt chaining, turn-budget envelopes, and
# WITNESS taint propagation across multi-turn agent runs.
try:
    from .session_intelligence import (  # noqa: F401
        HallucinationTaintTracker,
        SessionBudgetDecision,
        SessionReceiptChain,
        SessionReceiptLink,
        SuspectEntity,
        TaintPropagationReport,
        allocate_session_turn_budget,
        extract_taint_entities,
    )
except ImportError:
    pass


# Cache-aware gateway control plane: deterministic prefixes, provider cache
# leases, capability-safe failover, real usage accounting, and harness budgets.
try:
    from .cache_routing import (  # noqa: F401
        CacheAwareRouter,
        CachePrice,
        CacheRoutingDecision,
        CacheRoutingPolicy,
        ConversationCacheLease,
        ModelCandidate,
    )
    from .gateway_control_plane import (  # noqa: F401
        GatewayControlPlane,
        GatewayExecutionPlan,
    )
    from .harness_budget import (  # noqa: F401
        CodingHarnessBudgetController,
        HarnessBudgetPlan,
        SubagentAllocation,
        SubagentBudgetAllocator,
        SubagentDemand,
    )
    from .provider_policy import (  # noqa: F401
        CanonicalGatewayRequest,
        Capability,
        FailoverPlan,
        GatewayRedactionPolicy,
        ProviderFailoverPlanner,
        ProviderTarget,
        RedactionReceipt,
    )
    from .stable_prefix import (  # noqa: F401
        CanonicalPrefixBuilder,
        PrefixSection,
        StablePrompt,
        conversation_anchor,
    )
    from .usage_ledger import (  # noqa: F401
        TokenUsage,
        UsageEvent,
        UsageLedger,
        UsagePricing,
        parse_provider_usage,
        price_usage,
    )
except ImportError:
    pass


# Optimization economics: realized, estimated, and opportunity savings remain
# separate so dashboards cannot present forecasts as invoice savings.
try:
    from .optimization_ledger import (  # noqa: F401
        OptimizationAdjustment,
        OptimizationEvent,
        OptimizationLedger,
        SavingsSummary,
        SavingsTier,
    )
except ImportError:
    pass

# Query-conditioned checkpoint continuity with explicit decision preservation.
try:
    from .checkpoint_relevance import (  # noqa: F401
        CheckpointMatch,
        CheckpointRelevancePolicy,
        render_recovery_context,
        select_relevant_checkpoint,
    )
except ImportError:
    pass

# Forecast-only cache retention economics. This surface performs no provider I/O.
try:
    from .cache_retention import (  # noqa: F401
        CacheRetentionEstimate,
        CacheRetentionForecast,
        CacheRetentionForecaster,
        CacheRetentionPlan,
        anthropic_retention_plans,
    )
except ImportError:
    pass

# Advisory retry, error-loop, and model-churn telemetry.
try:
    from .behavioral_waste import (  # noqa: F401
        BehavioralWasteDetector,
        WasteFinding,
        observe_canonical_messages,
    )
except ImportError:
    pass

# Air-gap mode: when ENTROLY_AIR_GAP=1, install a process-wide socket guard
# that refuses non-loopback connections. A hard, checkable no-outbound
# guarantee for regulated/offline deployments; a no-op otherwise.
try:
    from .air_gap import (  # noqa: F401
        AirGapViolation,
        air_gap_enabled,
        air_gap_status,
        install_air_gap_guard,
    )

    install_air_gap_guard()
except Exception:  # never let the guard break import
    pass
