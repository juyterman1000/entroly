"""
Checkpoint & Resume System
===========================

Serializes the full agent state to disk so that multi-step tasks
can resume from the last checkpoint instead of restarting from scratch.

The Problem:
  An agent working on a 10-step refactoring task fails at step 7
  (API timeout, context overflow, rate limit). Today, the developer
  must restart the entire task — re-reading files, re-planning,
  re-executing steps 1-6 — wasting time and tokens.

The Solution:
  Entroly automatically checkpoints after every N tool calls:
    - All tracked context fragments (with scores)
    - The dedup index state
    - Co-access patterns from the pre-fetcher
    - Custom metadata (task plan, current step, etc.)

  On resume, the full state is restored in <100ms, and the agent
  picks up exactly where it left off.

Multi-Instance Support:
  Each CheckpointManager has an instance_id (hostname + PID).
  Checkpoints include the instance_id in metadata so multiple
  entroly instances on the same project can share learned state.
  merge_from_peers() scans for other instances' checkpoints and
  merges fragments using most-recent-writer-wins with access_count
  tiebreaker. Uses Pitman-Yor lifecycle management.

Storage Format:
  JSON for human readability and debuggability. Gzipped for
  space efficiency. Typical checkpoint: 50-200 KB compressed.

References:
  - Agentic Plan Caching (arXiv 2025) -- reusing structured plans
  - SagaLLM (arXiv 2025) -- transactional guarantees for multi-agent planning
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import math
import os
import re
import socket
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .checkpoint_relevance import (
    CheckpointMatch,
    CheckpointRelevancePolicy,
    merge_checkpoint_metadata,
    render_recovery_context,
    select_relevant_checkpoint,
)

from .native_status import usable_core as _usable_core

# Ask the shared gate rather than importing the core directly. A bare
# `import entroly_core` here took the Rust ContextFragment even when the engine
# had already refused that same core as below the minimum version, so one
# module built fragments the other could not accept:
#   TypeError: ContextFragment.__new__() got an unexpected keyword 'recency_score'
_core = _usable_core()
if _core is not None:
    ContextFragment = _core.ContextFragment
else:
    from dataclasses import dataclass as _dataclass

    @_dataclass
    class ContextFragment:  # type: ignore[no-redef]
        """Pure-Python fallback when the native engine is absent or unusable."""
        fragment_id: str
        content: str
        token_count: int
        source: str = ""
        recency_score: float = 1.0
        frequency_score: float = 0.0
        semantic_score: float = 0.0
        entropy_score: float = 0.5
        turn_created: int = 0
        turn_last_accessed: int = 0
        access_count: int = 0
        is_pinned: bool = False
        simhash: int = 0

logger = logging.getLogger("entroly.checkpoint")

# Checkpoint schema version — increment when serialization format changes.
# Migration functions handle loading older versions.
CHECKPOINT_SCHEMA_VERSION = 2


@dataclass
class Checkpoint:
    """A serialized snapshot of the Entroly state."""

    checkpoint_id: str
    """Unique ID for this checkpoint (timestamp-based)."""

    timestamp: float
    """Unix timestamp when this checkpoint was created."""

    current_turn: int
    """The turn number at checkpoint time."""

    fragments: list[dict[str, Any]]
    """Serialized context fragments."""

    dedup_fingerprints: dict[str, int]
    """fragment_id -> SimHash fingerprint mapping."""

    co_access_data: dict[str, dict[str, int]]
    """Pre-fetcher co-access counts."""

    metadata: dict[str, Any]
    """Custom metadata (task plan, current step, instance_id, etc.)."""

    stats: dict[str, Any]
    """Performance stats at checkpoint time."""


def _fragment_to_dict(frag: ContextFragment, include_content: bool = True) -> dict[str, Any]:
    """Serialize a ContextFragment to a JSON-safe dict.

    Args:
        include_content: If False, store only a SHA-256 content hash instead
            of raw source code.  This prevents user code from persisting on
            disk in plaintext while still allowing dedup verification on
            restore.  Content can be re-read from the filesystem via
            ``source`` (the file path) when the checkpoint is loaded.
    """
    d: dict[str, Any] = {
        "fragment_id": frag.fragment_id,
        "token_count": frag.token_count,
        "source": frag.source,
        "recency_score": round(frag.recency_score, 6),
        "frequency_score": round(frag.frequency_score, 6),
        "semantic_score": round(frag.semantic_score, 6),
        "entropy_score": round(frag.entropy_score, 6),
        "turn_created": frag.turn_created,
        "turn_last_accessed": frag.turn_last_accessed,
        "access_count": frag.access_count,
        "is_pinned": frag.is_pinned,
        "simhash": frag.simhash,
    }
    if include_content:
        d["content"] = frag.content
    else:
        # Store only a hash — enough to verify integrity on reload,
        # but impossible to reconstruct original source from.
        d["content_hash"] = hashlib.sha256(frag.content.encode()).hexdigest()
        d["content"] = ""  # empty sentinel; re-read from source on restore
    return d


def _dict_to_fragment(d: dict[str, Any]) -> ContextFragment:
    """Deserialize a dict back to a ContextFragment."""
    frag = ContextFragment(
        fragment_id=d["fragment_id"],
        content=d["content"],
        token_count=d["token_count"],
        source=d.get("source", ""),
    )
    frag.recency_score = d.get("recency_score", 0.0)
    frag.frequency_score = d.get("frequency_score", 0.0)
    frag.semantic_score = d.get("semantic_score", 0.0)
    frag.entropy_score = d.get("entropy_score", 0.5)
    frag.turn_created = d.get("turn_created", 0)
    frag.turn_last_accessed = d.get("turn_last_accessed", 0)
    frag.access_count = d.get("access_count", 0)
    frag.is_pinned = d.get("is_pinned", False)
    frag.simhash = d.get("simhash", 0)
    return frag


def _merge_fragments(
    local: list[dict[str, Any]], remote: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Merge fragment lists from different instances.

    Conflict resolution: most-recent-writer-wins with access_count tiebreaker.
    Uses Pitman-Yor lifecycle management.
    """
    merged: dict[str, dict[str, Any]] = {f["fragment_id"]: f for f in local}

    for rf in remote:
        fid = rf["fragment_id"]
        if fid not in merged:
            merged[fid] = rf
        else:
            local_f = merged[fid]
            # Prefer the version with more recent access
            if rf.get("turn_last_accessed", 0) > local_f.get("turn_last_accessed", 0):
                merged[fid] = rf
            elif rf.get("turn_last_accessed", 0) == local_f.get("turn_last_accessed", 0):
                # Tiebreak: higher access_count wins
                if rf.get("access_count", 0) > local_f.get("access_count", 0):
                    merged[fid] = rf

    return list(merged.values())


_LOCK_SIZE = 1024  # Lock region size for Windows msvcrt


def _acquire_file_lock(lock_path: Path) -> Any:
    """Acquire a file lock for distributed checkpoint safety.

    Uses fcntl on POSIX, msvcrt on Windows.
    Returns the lock file handle (caller must close to release).
    """
    lock_file = open(lock_path, "w")
    try:
        import fcntl
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (ImportError, OSError):
        try:
            import msvcrt
            # Seek to start and lock a meaningful region
            lock_file.seek(0)
            lock_file.write(" " * _LOCK_SIZE)
            lock_file.flush()
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, _LOCK_SIZE)
        except (ImportError, OSError):
            pass  # Best-effort: if locking unavailable, proceed without
    return lock_file


def _release_file_lock(lock_file: Any) -> None:
    """Release a file lock."""
    try:
        import fcntl
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
    except (ImportError, OSError):
        try:
            import msvcrt
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, _LOCK_SIZE)
        except (ImportError, OSError):
            pass
    lock_file.close()


# Ebbinghaus decay constant
_EBBINGHAUS_LAMBDA = 0.01


class CheckpointManager:
    """
    Manages saving and restoring Entroly state.

    Checkpoints are stored as gzipped JSON files in the checkpoint
    directory. Each checkpoint includes the full state needed to
    resume a session without any data loss.

    Multi-instance: Each manager has an instance_id. Checkpoints from
    peer instances can be merged via merge_from_peers().

    Auto-checkpoint:
      If auto_interval is set, the manager automatically creates
      a checkpoint every N tool calls. This provides crash recovery
      without explicit save calls.

    Retention:
      Keeps the last `max_checkpoints` checkpoints and deletes older
      ones to prevent unbounded disk usage.
    """

    def __init__(
        self,
        checkpoint_dir: str | Path,
        auto_interval: int = 5,
        max_checkpoints: int = 10,
        instance_id: str | None = None,
        peer_retention_seconds: float | None = None,
        max_total_checkpoints: int | None = None,
    ):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.auto_interval = auto_interval
        self.max_checkpoints = max_checkpoints
        # Reaping another instance's checkpoints is DISABLED by default and is
        # opt-in only. `instance_id` embeds the pid, so every restart makes the
        # previous run's checkpoints "peers" — and cross-instance reads are
        # exactly how resume works (`load_latest`/`find_relevant`/
        # `merge_from_peers` glob ckpt_*). Reaping peers by default therefore
        # deletes the resume history it is supposed to be pruning, which is a
        # worse failure than the disk growth it was meant to bound.
        #
        # Opt in with ENTROLY_PEER_CHECKPOINT_TTL=<seconds>. A value <= 0, unset,
        # or unparseable means "never reap a peer".
        if peer_retention_seconds is None:
            raw = os.environ.get("ENTROLY_PEER_CHECKPOINT_TTL", "")
            try:
                peer_retention_seconds = float(raw) if raw.strip() else 0.0
            except (TypeError, ValueError):
                peer_retention_seconds = 0.0
        # <= 0 disables reaping entirely (never "reap everything immediately").
        self.peer_retention_seconds = (
            peer_retention_seconds if peer_retention_seconds > 0 else 0.0
        )
        # Hard ceiling on total checkpoints across every instance. This is the
        # default-on mechanism that actually bounds disk; peer reaping above is
        # an optional extra. Override with ENTROLY_MAX_TOTAL_CHECKPOINTS; <= 0
        # disables the cap.
        if max_total_checkpoints is None:
            try:
                max_total_checkpoints = int(
                    os.environ.get("ENTROLY_MAX_TOTAL_CHECKPOINTS", "") or 40
                )
            except (TypeError, ValueError):
                max_total_checkpoints = 40
        self.max_total_checkpoints = max_total_checkpoints
        if instance_id:
            self.instance_id = instance_id
        else:
            # Hash hostname to avoid leaking machine identity in checkpoint files
            host_hash = hashlib.sha256(socket.gethostname().encode()).hexdigest()[:12]
            self.instance_id = f"{host_hash}_{os.getpid()}"

        self._tool_calls_since_checkpoint = 0
        self._total_checkpoints_created = 0

        # Ensure directory exists with restricted permissions (0700).
        # Some environments cannot write to the default home-backed path,
        # so fail over to a temp-backed directory instead of aborting startup.
        try:
            self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            self.checkpoint_dir = Path(tempfile.mkdtemp(prefix="entroly_ckpt_"))
        try:
            os.chmod(str(self.checkpoint_dir), 0o700)
        except OSError:
            pass  # Best-effort on platforms without chmod

        # Security: verify directory is not a symlink (prevents symlink attacks)
        if os.path.islink(str(self.checkpoint_dir)):
            import logging as _log
            _log.getLogger("entroly.checkpoint").warning(
                "Checkpoint directory is a symlink — refusing to use: %s",
                self.checkpoint_dir,
            )
            # Fall back to a safe temporary directory
            self.checkpoint_dir = Path(tempfile.mkdtemp(prefix="entroly_ckpt_"))
            os.chmod(str(self.checkpoint_dir), 0o700)

        # Security: on POSIX, verify we own the directory
        try:
            dir_stat = os.stat(str(self.checkpoint_dir))
            if hasattr(os, "getuid") and dir_stat.st_uid != os.getuid():
                import logging as _log
                _log.getLogger("entroly.checkpoint").warning(
                    "Checkpoint directory not owned by current user (uid=%d, dir_uid=%d)",
                    os.getuid(), dir_stat.st_uid,
                )
                self.checkpoint_dir = Path(tempfile.mkdtemp(prefix="entroly_ckpt_"))
                os.chmod(str(self.checkpoint_dir), 0o700)
        except OSError:
            pass  # Best-effort; Windows may not support uid checks

    def should_auto_checkpoint(self) -> bool:
        """Check if an auto-checkpoint is due."""
        self._tool_calls_since_checkpoint += 1
        return self._tool_calls_since_checkpoint >= self.auto_interval

    def save(
        self,
        fragments: list[ContextFragment],
        dedup_fingerprints: dict[str, int],
        co_access_data: dict[str, dict[str, int]],
        current_turn: int,
        metadata: dict[str, Any] | None = None,
        stats: dict[str, Any] | None = None,
    ) -> str:
        """
        Save a checkpoint to disk with distributed file locking.

        Returns the checkpoint file path.
        """
        checkpoint_id = f"ckpt_{self.instance_id}_{int(time.time())}_{self._total_checkpoints_created}"

        previous = self._load_latest_for_instance()
        meta = merge_checkpoint_metadata(
            previous.metadata if previous is not None else None,
            metadata,
        )
        meta["instance_id"] = self.instance_id

        # Privacy: strip raw code content from checkpoints when requested.
        # Default is True (include content) for backward compat; set
        # ENTROLY_STRIP_CONTENT=1 to store only content hashes.
        include_content = os.environ.get("ENTROLY_STRIP_CONTENT", "") not in ("1", "true", "yes")
        checkpoint = Checkpoint(
            checkpoint_id=checkpoint_id,
            timestamp=time.time(),
            current_turn=current_turn,
            fragments=[_fragment_to_dict(f, include_content=include_content) for f in fragments],
            dedup_fingerprints={k: v for k, v in dedup_fingerprints.items()},
            co_access_data={
                k: dict(v) for k, v in co_access_data.items()
            },
            metadata=meta,
            stats=stats or {},
        )

        # Disk-space check: bail early if < 10MB free (prevents silent corruption)
        try:
            import shutil as _shutil
            disk_usage = _shutil.disk_usage(str(self.checkpoint_dir))
            free_bytes = disk_usage.free
            if free_bytes < 10 * 1024 * 1024:  # 10 MB minimum
                import logging
                logging.getLogger("entroly").warning(
                    f"Checkpoint skipped: only {free_bytes // 1024}KB free on disk"
                )
                return ""
        except (OSError, AttributeError):
            pass  # statvfs not available on Windows; proceed best-effort

        # Serialize to gzipped JSON
        filepath = self.checkpoint_dir / f"{checkpoint_id}.json.gz"
        data = json.dumps({
            "schema_version": CHECKPOINT_SCHEMA_VERSION,
            "checkpoint_id": checkpoint.checkpoint_id,
            "timestamp": checkpoint.timestamp,
            "current_turn": checkpoint.current_turn,
            "fragments": checkpoint.fragments,
            "dedup_fingerprints": checkpoint.dedup_fingerprints,
            "co_access_data": checkpoint.co_access_data,
            "metadata": checkpoint.metadata,
            "stats": checkpoint.stats,
        }, separators=(",", ":"))

        # Distributed file lock + atomic write
        lock_path = self.checkpoint_dir / ".checkpoint.lock"
        lock_file = _acquire_file_lock(lock_path)
        try:
            tmp_fd, tmp_path = tempfile.mkstemp(
                dir=str(self.checkpoint_dir), suffix=".json.gz.tmp"
            )
            os.close(tmp_fd)
            try:
                with gzip.open(tmp_path, "wt", encoding="utf-8") as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                # Restrict permissions before moving into place (0600 = owner-only)
                try:
                    os.chmod(tmp_path, 0o600)
                except OSError:
                    pass  # Windows may not support chmod
                os.replace(tmp_path, str(filepath))  # atomic on POSIX + Windows
            except BaseException:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise
        finally:
            _release_file_lock(lock_file)

        self._tool_calls_since_checkpoint = 0
        self._total_checkpoints_created += 1

        # Enforce retention policy
        self._prune_old_checkpoints()

        return str(filepath)

    def load_latest(self) -> Checkpoint | None:
        """
        Load the most recent checkpoint (from this instance).

        Returns None if no checkpoints exist or all are unreadable.
        """
        checkpoints = self._globbed_newest_first("ckpt_*.json.gz")

        for cp in checkpoints:
            result = self._load_file(cp)
            if result is not None:
                return result

        return None

    def _load_latest_for_instance(self) -> Checkpoint | None:
        """Load this live instance's latest checkpoint for metadata continuity."""
        paths = self._globbed_newest_first(f"ckpt_{self.instance_id}_*.json.gz")
        for path in paths:
            checkpoint = self._load_file(path)
            if checkpoint is not None:
                return checkpoint
        return None

    def find_relevant(
        self,
        query: str,
        *,
        project: str = "",
        now: float | None = None,
        policy: CheckpointRelevancePolicy | None = None,
    ) -> CheckpointMatch | None:
        """Return the best task-relevant checkpoint, or None below threshold."""
        checkpoints: list[Checkpoint] = []
        paths = self._globbed_newest_first("ckpt_*.json.gz")
        for path in paths:
            checkpoint = self._load_file(path)
            if checkpoint is not None:
                checkpoints.append(checkpoint)
        return select_relevant_checkpoint(
            checkpoints,
            query,
            project=project,
            now=now,
            policy=policy,
        )

    @staticmethod
    def render_recovery_context(match: CheckpointMatch) -> str:
        """Render fenced continuity metadata for a selected checkpoint."""
        return render_recovery_context(match)

    @staticmethod
    def render_checkpoint_context(checkpoint: Checkpoint) -> str:
        """Render fenced continuity metadata without claiming query relevance."""
        return render_recovery_context(
            CheckpointMatch(
                checkpoint=checkpoint,
                score=0.0,
                lexical_score=0.0,
                source_score=0.0,
                project_score=0.0,
                recency_score=0.0,
                matched_terms=(),
            )
        )

    def load_by_id(self, checkpoint_id: str) -> Checkpoint | None:
        """Load a specific checkpoint by its ID."""
        filepath = self.checkpoint_dir / f"{checkpoint_id}.json.gz"
        if not filepath.exists():
            return None
        return self._load_file(filepath)

    def merge_from_peers(self, local_fragments: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Scan for checkpoints from peer instances and merge their fragments.

        Returns the merged fragment list combining local + peer knowledge.
        Uses most-recent-writer-wins conflict resolution.
        """
        all_checkpoints = self._globbed_newest_first("ckpt_*.json.gz")

        merged = list(local_fragments)
        seen_instances = {self.instance_id}

        for cp_path in all_checkpoints:
            loaded = self._load_file(cp_path)
            if loaded is None:
                continue

            peer_id = loaded.metadata.get("instance_id", "")
            if peer_id in seen_instances or peer_id == self.instance_id:
                continue

            seen_instances.add(peer_id)
            # Merge this peer's fragments (one checkpoint per peer, most recent)
            merged = _merge_fragments(merged, loaded.fragments)

        return merged

    def apply_ebbinghaus_decay(
        self, fragments: list[dict[str, Any]], current_tick: int
    ) -> list[dict[str, Any]]:
        """Apply Ebbinghaus forgetting curve to fragment health scores.

        Applies Ebbinghaus forgetting curve decay.
        Fragments with health < 0.05 are evicted.
        """
        result = []
        for frag in fragments:
            dt = max(0, current_tick - frag.get("turn_last_accessed", 0))
            health = math.exp(-_EBBINGHAUS_LAMBDA * dt)
            if health >= 0.05:
                result.append(frag)
        return result

    def list_checkpoints(self) -> list[dict[str, Any]]:
        """List all available checkpoints with metadata."""
        checkpoints = self._globbed_newest_first("ckpt_*.json.gz")

        result = []
        for cp_path in checkpoints:
            try:
                stat = cp_path.stat()
                result.append({
                    "checkpoint_id": cp_path.stem.replace(".json", ""),
                    "path": str(cp_path),
                    "size_bytes": stat.st_size,
                    "created": stat.st_mtime,
                })
            except OSError:
                continue

        return result

    def restore_fragments(self, checkpoint: Checkpoint) -> list[ContextFragment]:
        """Extract ContextFragment objects from a checkpoint."""
        return [_dict_to_fragment(d) for d in checkpoint.fragments]

    def _load_file(self, filepath: Path) -> Checkpoint | None:
        """Load and parse a checkpoint file with schema migration. Returns None if corrupted."""
        try:
            with gzip.open(filepath, "rt", encoding="utf-8") as f:
                data = json.loads(f.read())
        except (EOFError, gzip.BadGzipFile, json.JSONDecodeError, OSError):
            return None

        # Schema migration
        version = data.get("schema_version", 1)
        if version < 2:
            # v1 -> v2: add instance_id to metadata
            if "metadata" not in data:
                data["metadata"] = {}
            if "instance_id" not in data.get("metadata", {}):
                data["metadata"]["instance_id"] = "migrated_v1"

        return Checkpoint(
            checkpoint_id=data["checkpoint_id"],
            timestamp=data["timestamp"],
            current_turn=data["current_turn"],
            fragments=data["fragments"],
            dedup_fingerprints=data.get("dedup_fingerprints", {}),
            co_access_data=data.get("co_access_data", {}),
            metadata=data.get("metadata", {}),
            stats=data.get("stats", {}),
        )

    def _prune_old_checkpoints(self) -> None:
        """Enforce retention for this instance, and reap abandoned peer checkpoints.

        Pruning only ever covered the current instance. Every restart mints a new
        instance id, so the previous run's checkpoints became permanently
        unprunable "peers" and accumulated without bound — an observed dev
        machine held 127 checkpoints / 264 MB with `own_checkpoints: 0`, at ~40 MB
        per write.

        Peers belonging to a *live* process are still left alone (another server
        may legitimately be running). Peers older than `peer_retention_seconds`
        are treated as abandoned by a dead instance and reaped.
        """
        self._prune_pattern(
            f"ckpt_{self.instance_id}_*.json.gz", keep=self.max_checkpoints
        )
        self._enforce_global_cap()
        self._reap_abandoned_peers()

    @staticmethod
    def plan_global_cap_deletions(
        entries: list[tuple[float, Path]],
        *,
        own_prefix: str,
        own_host: str,
        owner_of,
        is_alive,
    ) -> list[Path]:
        """Pure policy: which checkpoints to drop, least valuable first.

        Deliberately I/O-free and side-effect-free so the policy can be tested
        exhaustively without simulating filesystem races. The previous design
        interleaved liveness probes, a `protected` set carrying three different
        meanings, and TWO deletion loops that each maintained their own counter.
        Those counters diverged, and the resulting overcount deleted a live
        peer's only recovery frontier — four consecutive review rounds found a
        new defect in that shape. Ordering the candidates once, here, removes
        the whole class.

        Priority, least valuable first:
          1. peer checkpoints superseded by a newer one from the same peer
          2. frontiers of peers proven dead, oldest first
          3. the newest dead-peer frontier (one restart/crash recovery point,
             given up only under real pressure)
          4. frontiers of peers that are alive or unprovable, oldest first

        A running peer's frontier is its ONLY resume point, so it outranks a
        crashed process's history: every dead frontier is planned before any
        live one. Exempting the newest dead frontier entirely — as the first
        version of this policy did — meant cap pressure destroyed live peers'
        resume points to preserve a dead process's file.

        Never returned: this instance's own checkpoints, and any file whose
        owner cannot be identified — deleting on a guess is the one thing this
        module does not do.
        """
        ordered = sorted(entries, key=lambda item: item[0], reverse=True)
        superseded: list[Path] = []
        dead_frontiers: list[Path] = []
        live_frontiers: list[Path] = []
        seen_peers: set[str] = set()

        for _mtime, checkpoint in ordered:
            if checkpoint.name.startswith(own_prefix):
                continue                      # never ours
            owner = owner_of(checkpoint.name)
            if owner is None:
                continue                      # unknown ownership: never a guess
            owner_id, host_hash, pid = owner
            if owner_id in seen_peers:
                superseded.append(checkpoint)  # a newer one from this peer exists
                continue
            seen_peers.add(owner_id)
            if host_hash != own_host or is_alive(pid):
                live_frontiers.append(checkpoint)
            else:
                dead_frontiers.append(checkpoint)

        # `ordered` is newest-first, so each bucket is too; delete oldest first.
        plan = list(reversed(superseded))
        plan += list(reversed(dead_frontiers[1:]))   # older dead frontiers
        plan += dead_frontiers[:1]                   # newest dead: before any live
        plan += list(reversed(live_frontiers))       # last resort, keeps cap hard
        return plan

    def _enforce_global_cap(self) -> None:
        """Bound total checkpoints across all instances, newest-first.

        Per-instance pruning cannot bound disk: `instance_id` embeds the pid, so
        every restart orphans up to `max_checkpoints` files the next run can
        never match — the reported 127-file / 264 MB condition.

        Policy lives in `plan_global_cap_deletions`; this only executes it, with
        a single counter rule: a file stops counting toward the total when it is
        gone, whether we removed it or a peer did first.
        """
        if self.max_total_checkpoints <= 0:
            return
        try:
            candidates = list(self.checkpoint_dir.glob("ckpt_*.json.gz"))
        except OSError:
            return

        entries: list[tuple[float, Path]] = []
        for checkpoint in candidates:
            try:
                entries.append((checkpoint.stat().st_mtime, checkpoint))
            except OSError:
                continue          # vanished mid-scan; not ours to report
        remaining = len(entries)
        if remaining <= self.max_total_checkpoints:
            return

        plan = self.plan_global_cap_deletions(
            entries,
            own_prefix=f"ckpt_{self.instance_id}_",
            own_host=self.instance_id.split("_", 1)[0],
            owner_of=self._checkpoint_owner,
            is_alive=self._pid_is_alive,
        )

        for checkpoint in plan:
            if remaining <= self.max_total_checkpoints:
                break
            try:
                checkpoint.unlink()
            except FileNotFoundError:
                remaining -= 1    # a peer removed it; it is still gone
                continue
            except OSError:
                continue          # still present (permissions, lock)
            remaining -= 1

        if remaining > self.max_total_checkpoints:
            logger.warning(
                "Checkpoint cap is soft: %d file(s) remain above the configured "
                "cap %d. Remaining files are this instance's own state, files "
                "whose owner could not be identified, or files that could not "
                "be removed (locked or permission-denied); %d deletion(s) were "
                "planned",
                remaining,
                self.max_total_checkpoints,
                len(plan),
            )

    def _globbed_newest_first(self, pattern: str) -> list[Path]:
        """Glob and sort by mtime, tolerating files that vanish mid-scan.

        `sorted(glob(...), key=lambda p: p.stat().st_mtime)` raises
        FileNotFoundError when a path disappears between the glob and the stat.
        That window is now reachable cross-process: the global cap makes one
        instance unlink another instance's checkpoints, so a peer's retention
        pass can delete a file while this instance is enumerating. Readers must
        degrade to "that checkpoint is gone", never raise out of an MCP tool.
        """
        try:
            candidates = list(self.checkpoint_dir.glob(pattern))
        except OSError:
            return []
        dated: list[tuple[tuple[int, int, int, str], Path]] = []
        for path in candidates:
            try:
                stat = path.stat()
            except OSError:
                continue  # vanished under us
            # Some filesystems expose coarse mtimes. Multiple checkpoints saved
            # in one tick then compare equal and glob order decides what
            # ``load_latest`` returns. The checkpoint ID already carries a
            # per-instance sequence, so use it as a deterministic tie-breaker.
            # Keep mtime first so tests/operators that deliberately age files
            # retain the established ordering semantics.
            match = re.search(r"_(\d+)_(\d+)\.json\.gz$", path.name)
            checkpoint_second = int(match.group(1)) if match else 0
            checkpoint_sequence = int(match.group(2)) if match else -1
            dated.append((
                (
                    int(getattr(stat, "st_mtime_ns", stat.st_mtime * 1_000_000_000)),
                    checkpoint_second,
                    checkpoint_sequence,
                    path.name,
                ),
                path,
            ))
        dated.sort(key=lambda item: item[0], reverse=True)
        return [path for _sort_key, path in dated]

    def _prune_pattern(self, pattern: str, keep: int) -> None:
        # Per-file stat guard: a concurrent peer prune must not abort our own
        # retention (see _enforce_global_cap).
        try:
            candidates = list(self.checkpoint_dir.glob(pattern))
        except OSError:
            return
        dated = []
        for p in candidates:
            try:
                dated.append((p.stat().st_mtime, p))
            except OSError:
                continue
        checkpoints = [p for _m, p in sorted(dated, key=lambda i: i[0], reverse=True)]
        for old_cp in checkpoints[keep:]:
            try:
                old_cp.unlink()
            except OSError:
                pass

    @staticmethod
    def _pid_is_alive(pid: int) -> bool:
        """Best-effort liveness probe. Returns True when uncertain (fail-safe)."""
        if pid <= 0:
            return True
        if pid > 0xFFFFFFFF:
            # No OS pid is this large, and the two platforms disagree about it in
            # dangerous ways: POSIX os.kill raises OverflowError, while Windows
            # ctypes silently MASKS the value to pid mod 2**32 under the DWORD
            # argtype and probes an unrelated process — so a corrupted filename
            # could report "dead" and get a live peer's checkpoint deleted.
            # Unknown is the fail-safe answer on both.
            return True
        try:
            if os.name == "nt":
                import ctypes
                from ctypes import wintypes

                # Declare the signatures: the default restype is c_int, which
                # truncates a HANDLE >= 0x80000000 to a negative int and makes
                # the subsequent CloseHandle fail (leaking a process handle per
                # probe). use_last_error captures errno at the call boundary
                # rather than via a second foreign call that can clobber it.
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.OpenProcess.restype = wintypes.HANDLE
                kernel32.OpenProcess.argtypes = (
                    wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
                kernel32.CloseHandle.restype = wintypes.BOOL
                kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)

                handle = kernel32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED
                if handle:
                    kernel32.CloseHandle(handle)
                    return True
                # A NULL handle does NOT mean "dead". ERROR_ACCESS_DENIED (5)
                # means the process is alive but owned by another user or
                # elevated — treating that as dead would delete a running peer's
                # state. Only ERROR_INVALID_PARAMETER (87) means "no such pid".
                return ctypes.get_last_error() != 87
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except OverflowError:
            # os.kill raises OverflowError (NOT OSError) for a pid above
            # INT_MAX, so it escapes the tuple below. Uncaught, it propagates
            # out of _reap_abandoned_peers -> _prune_old_checkpoints -> save(),
            # turning a best-effort prune into a raised exception. Such a pid
            # cannot name a live process, but "unknown" is the fail-safe answer.
            return True
        except (OSError, PermissionError, AttributeError, ValueError):
            return True  # cannot tell — never delete on a guess
        except Exception:
            # Deliberately broad, and only here. ctypes raises ArgumentError
            # (a direct Exception subclass, not OSError/ValueError) for an
            # out-of-range argument, which would otherwise propagate out of
            # _reap_abandoned_peers -> _prune_old_checkpoints -> save() and turn
            # a best-effort prune into a raised exception. A liveness probe must
            # never be able to fail a checkpoint; unknown means "keep it".
            return True

    # Only the auto-generated instance_id is `<12-hex-hosthash>_<pid>`. A
    # caller-supplied id (e.g. "prod_2") would make an arbitrary field be probed
    # as a pid, and a low number is very likely a live unrelated process — or
    # worse, a dead one, deleting a running peer's state.
    _AUTO_ID_RE = re.compile(r"^ckpt_([0-9a-f]{12})_(\d+)_")

    @classmethod
    def _checkpoint_owner(cls, name: str) -> tuple[str, str, int] | None:
        """Return ``(instance_id, host_hash, pid)`` for an auto filename."""
        match = cls._AUTO_ID_RE.match(name)
        if not match:
            return None
        try:
            pid = int(match.group(2))
        except ValueError:
            return None
        host_hash = match.group(1)
        return f"{host_hash}_{pid}", host_hash, pid

    def _peer_pid(self, name: str) -> int:
        """Owning pid from an auto-generated checkpoint name, else 0."""
        owner = self._checkpoint_owner(name)
        return owner[2] if owner is not None else 0

    def _reap_abandoned_peers(self) -> None:
        """Delete peer checkpoints whose owning process is provably gone.

        Opt-in only (see `peer_retention_seconds`). Age alone is NOT liveness: an
        idle-but-running instance stops writing and its checkpoints age. A peer is
        reaped only when it is both older than the TTL *and* its pid is no longer
        alive on this host, and anything uncertain is kept.
        """
        if self.peer_retention_seconds <= 0:
            return  # disabled by default
        cutoff = time.time() - self.peer_retention_seconds
        own_prefix = f"ckpt_{self.instance_id}_"
        try:
            candidates = list(self.checkpoint_dir.glob("ckpt_*.json.gz"))
        except OSError:
            return
        # A pid probe only means anything for peers on THIS host. Checkpoint dirs
        # are shared across containers and NFS homes, where pids are reused in
        # independent namespaces — probing there would judge a live peer dead.
        own_host = self.instance_id.split("_")[0]
        for cp in candidates:
            if cp.name.startswith(own_prefix):
                continue
            try:
                if cp.stat().st_mtime >= cutoff:
                    continue  # recent — a peer may still be running
                parts = cp.name.split("_")
                if len(parts) < 3 or parts[1] != own_host:
                    continue  # different (or unknown) host — never our call
                if self._pid_is_alive(self._peer_pid(cp.name)):
                    continue  # owner is alive; its state is not ours to delete
                cp.unlink()
            except OSError:
                pass  # racing peer or permission issue; never fail a checkpoint

    def stats(self) -> dict:
        checkpoints = list(self.checkpoint_dir.glob("ckpt_*.json.gz"))
        own_checkpoints = [
            cp for cp in checkpoints
            if cp.name.startswith(f"ckpt_{self.instance_id}_")
        ]
        peer_checkpoints = len(checkpoints) - len(own_checkpoints)
        # A file enumerated by the glob above can vanish before we stat it —
        # another instance may be pruning concurrently. get_stats() must not
        # raise FileNotFoundError just because a checkpoint was reaped mid-scan.
        total_size = 0
        for cp in checkpoints:
            try:
                total_size += cp.stat().st_size
            except OSError:
                continue
        return {
            "instance_id": self.instance_id,
            "total_checkpoints": len(checkpoints),
            "own_checkpoints": len(own_checkpoints),
            "peer_checkpoints": peer_checkpoints,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "tool_calls_since_last": self._tool_calls_since_checkpoint,
            "auto_interval": self.auto_interval,
        }
