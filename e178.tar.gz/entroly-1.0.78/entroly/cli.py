"""
Entroly CLI — Zero-friction onboarding for AI coding agents.

Commands:
    entroly optimize    Generate optimized context snapshot for a task
    entroly feedback    Signal outcome quality to improve future context
    entroly go          One command: auto-detect, init, proxy, and dashboard
    entroly init        Auto-detect project + AI tool, generate MCP config
    entroly serve       Start MCP server with auto-indexing
    entroly proxy       Start invisible prompt compiler proxy
    entroly dashboard   Show live value metrics
    entroly health      Analyze codebase health (A-F grade)
    entroly autotune    Optimize hyperparameters
    entroly benchmark   Run competitive comparison
    entroly ingest      Ingest docs for Context Receipts
    entroly select      Select context and write a Context Receipt
    entroly receipt     Render a Context Receipt report
    entroly audit       Render a session-chain audit report
    entroly explain     Explain receipt selection/omission decisions
    entroly simulate    Estimate local token savings without LLM calls
    entroly perf        Measure local optimizer savings/latency without LLM calls
    entroly value       Show an evidence-classified context value receipt
    entroly status      Check if server/proxy is running
    entroly config      Show current configuration
    entroly clean       Clear cached state (checkpoints, index, pull cache)
    entroly telemetry   Manage the local telemetry preference
    entroly uninstall   Guided uninstall with optional structured exit feedback
    entroly demo        Before/after demo showing token savings
    entroly doctor      Diagnose common issues
    entroly digest      Weekly summary of value delivered
    entroly migrate     Auto-migrate config/index to current version
    entroly role        Role-based weight presets (frontend/backend/sre/data)
    entroly completions Generate shell completion scripts
    entroly ravs        RAVS offline evaluation (report)
    entroly witness     Verify or suppress hallucinated factual claims
    entroly cache       Inspect EGSC persistent cache (cross-session)
    entroly unwrap      Safely remove persistent Entroly integration
    entroly capabilities Report installed runtime capabilities offline
"""

from __future__ import annotations

import argparse
import copy
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

try:
    from entroly import __version__
except ImportError:
    __version__ = "1.0.78"

from entroly.config import (
    load_active_tuning_config as _load_active_tuning_config,
    writable_tuning_config_path as _writable_tuning_config_path,
)

# ── Force UTF-8 output on Windows ──
# Windows terminals default to cp1252 which can't encode ✓/✗/─/⚡.
# Reconfigure stdout/stderr to UTF-8 with error replacement so print()
# never raises UnicodeEncodeError.
if sys.platform == "win32":
    for _stream_name in ("stdout", "stderr"):
        _stream = getattr(sys, _stream_name)
        if hasattr(_stream, "reconfigure"):
            try:
                _stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


# ── ANSI colors ──
_COLOR_ENABLED = "NO_COLOR" not in os.environ


class C:
    BOLD = "\033[1m" if _COLOR_ENABLED else ""
    GREEN = "\033[38;5;82m" if _COLOR_ENABLED else ""
    CYAN = "\033[38;5;45m" if _COLOR_ENABLED else ""
    YELLOW = "\033[38;5;220m" if _COLOR_ENABLED else ""
    RED = "\033[38;5;196m" if _COLOR_ENABLED else ""
    GRAY = "\033[38;5;240m" if _COLOR_ENABLED else ""
    RESET = "\033[0m" if _COLOR_ENABLED else ""


def _resolve_entroly_dir() -> Path:
    """Return a writable Entroly data directory.

    MCP hosts, containers, and managed IDE runtimes can expose a read-only
    HOME. A read-only HOME must not make basic commands like ``entroly status``
    or ``entroly --help`` crash before the command handler runs.
    """
    explicit = os.environ.get("ENTROLY_DIR")
    candidates = [Path(explicit).expanduser()] if explicit else [
        Path.home() / ".entroly",
        Path(tempfile.gettempdir()) / "entroly",
    ]
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write_probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            return candidate
        except OSError:
            continue
    return Path(tempfile.gettempdir()) / "entroly"


_ENTROLY_DIR = _resolve_entroly_dir()
_FIRST_RUN_MARKER = _ENTROLY_DIR / ".welcome_shown"


def _free_port(port: int) -> bool:
    """Return whether *port* is available without terminating its current owner."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) != 0


def _is_entroly_service_running(url: str, expected_service: str) -> bool:
    """Return whether *url* exposes the expected Entroly health identity."""
    try:
        import urllib.request
        with urllib.request.urlopen(url, timeout=2) as resp:
            data = json.loads(resp.read())
        return resp.status == 200 and data.get("status") == "ok" and data.get("service") == expected_service
    except Exception:
        return False


def _is_entroly_proxy_running(port: int) -> bool:
    return _is_entroly_service_running(f"http://127.0.0.1:{port}/health", "entroly-proxy")


def _tail_text_file(path: Path, max_chars: int = 3000) -> str:
    """Best-effort tail reader for diagnostics. Never raises."""
    try:
        data = path.read_bytes()
    except OSError:
        return ""
    if len(data) > max_chars:
        data = data[-max_chars:]
    return data.decode("utf-8", errors="replace").strip()


def _stop_process_best_effort(proc: subprocess.Popen, timeout_s: float = 3.0) -> None:
    """Terminate a child process without letting cleanup failures escape."""
    try:
        if proc.poll() is not None:
            return
        proc.terminate()
        proc.wait(timeout=timeout_s)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _check_first_run() -> None:
    """Show a one-time welcome message on first ever invocation.

    Creates ~/.entroly/.welcome_shown as a marker so it only fires once.
    """
    if _FIRST_RUN_MARKER.exists():
        return

    print(f"""
{C.CYAN}{C.BOLD}  Welcome to Entroly{C.RESET} — information-theoretic context optimization
  for AI coding agents.

  {C.BOLD}Prove value locally first — no API key needed:{C.RESET}

    {C.BOLD}Step 1:{C.RESET} {C.CYAN}entroly verify-claims{C.RESET}  Verify SDK, indexing, optimization, recovery
    {C.BOLD}Step 2:{C.RESET} {C.CYAN}entroly simulate{C.RESET}       Estimate savings on this repo without an LLM call

  {C.BOLD}Best setup for subscriptions:{C.RESET}
    {C.CYAN}claude mcp add entroly -- entroly{C.RESET}
    Claude Code stays your client; Entroly adds local compression and retrieval tools.

  {C.BOLD}Proxy mode for API-key users:{C.RESET}
    {C.CYAN}entroly proxy{C.RESET}          Start the local proxy at {C.CYAN}http://localhost:9377{C.RESET}
    {C.CYAN}entroly wrap claude{C.RESET}    Wrap a supported coding agent

  {C.BOLD}Useful commands:{C.RESET}
    {C.CYAN}entroly demo{C.RESET}        Run a before/after comparison showing token savings
    {C.CYAN}entroly status{C.RESET}      Check if server/proxy is running
    {C.CYAN}entroly doctor{C.RESET}      Diagnose common issues
    {C.CYAN}entroly health{C.RESET}      Analyze codebase health (grade A-F)

  {C.GRAY}Documentation: https://github.com/juyterman1000/entroly{C.RESET}
  {C.GRAY}This message appears once. Run entroly --help anytime.{C.RESET}
""", file=sys.stderr)
    try:
        _ENTROLY_DIR.mkdir(parents=True, exist_ok=True)
        _FIRST_RUN_MARKER.write_text("1")
    except OSError:
        pass


def _version_is_newer(candidate: str, current: str) -> bool:
    """True when `candidate` is a strictly newer release than `current`."""
    if not candidate or candidate == current:
        return False
    try:
        from packaging.version import Version
        return Version(candidate) > Version(current)
    except Exception:
        # packaging unavailable: string compare is imperfect but never crashes
        return candidate > current


def _check_for_update() -> None:
    """Check PyPI for a newer version when the user explicitly opts in.

    Prints a one-line notice if a newer version exists. Fails silently
    on network errors — never blocks CLI startup.
    """
    if (
        os.environ.get("ENTROLY_ENABLE_UPDATE_CHECK", "0") != "1"
        or os.environ.get("ENTROLY_DISABLE_UPDATE_CHECK", "0") == "1"
    ):
        return

    cache_file = _ENTROLY_DIR / ".update_check"
    now = __import__("time").time()

    # Only check once per 24 hours
    try:
        if cache_file.exists():
            data = json.loads(cache_file.read_text())
            if now - data.get("ts", 0) < 86400:
                cached = data.get("newer")
                # Re-compare against the version running NOW. The cache records
                # that a newer release existed, but it outlives the upgrade that
                # resolves it -- so replaying it blindly told a user who had just
                # updated "Update available: 1.0.72 -> 1.0.72", on every command,
                # for up to 24 hours.
                if cached and _version_is_newer(cached, __version__):
                    print(
                        f"  {C.YELLOW}Update available:{C.RESET} "
                        f"{__version__} -> {cached}  "
                        f"{C.GRAY}(pip install --upgrade entroly){C.RESET}",
                        file=sys.stderr,
                    )
                return
    except (OSError, json.JSONDecodeError, KeyError):
        pass

    # Non-blocking check in a background thread
    import threading

    def _do_check():
        try:
            import urllib.request
            resp = urllib.request.urlopen(
                "https://pypi.org/pypi/entroly/json", timeout=3
            )
            pypi = json.loads(resp.read())
            latest = pypi.get("info", {}).get("version", __version__)

            # Simple version comparison (works for semver)
            newer = latest if _version_is_newer(latest, __version__) else None

            _ENTROLY_DIR.mkdir(parents=True, exist_ok=True)
            cache_file.write_text(json.dumps({"ts": now, "newer": newer}))

            if newer:
                print(
                    f"  {C.YELLOW}Update available:{C.RESET} "
                    f"{__version__} -> {newer}  "
                    f"{C.GRAY}(pip install --upgrade entroly){C.RESET}",
                    file=sys.stderr,
                )
        except Exception:
            pass  # Never block or error on update checks

    t = threading.Thread(target=_do_check, daemon=True)
    t.start()


def _detect_project_type() -> dict:
    """Detect what kind of project this is."""
    cwd = os.getcwd()
    indicators = {
        "python": ["pyproject.toml", "setup.py", "requirements.txt", "Pipfile"],
        "rust": ["Cargo.toml"],
        "javascript": ["package.json"],
        "typescript": ["tsconfig.json"],
        "go": ["go.mod"],
        "java": ["pom.xml", "build.gradle"],
        "ruby": ["Gemfile"],
    }

    detected = []
    for lang, files in indicators.items():
        for f in files:
            if os.path.exists(os.path.join(cwd, f)):
                detected.append(lang)
                break

    # Detect JS/TS frameworks for richer project context
    frameworks = []
    framework_indicators = {
        "Next.js": ["next.config.js", "next.config.mjs", "next.config.ts"],
        "Angular": ["angular.json"],
        "Nuxt": ["nuxt.config.ts", "nuxt.config.js"],
        "Remix": ["remix.config.js", "remix.config.ts"],
        "Vite": ["vite.config.ts", "vite.config.js", "vite.config.mts"],
        "Svelte": ["svelte.config.js"],
        "Astro": ["astro.config.mjs"],
        "Gatsby": ["gatsby-config.js", "gatsby-config.ts"],
        "Expo": ["app.json", "expo.json"],
    }
    for fw, fw_files in framework_indicators.items():
        for f in fw_files:
            if os.path.exists(os.path.join(cwd, f)):
                frameworks.append(fw)
                break

    # Check package.json for React/Vue/Angular dependencies
    pkg_path = os.path.join(cwd, "package.json")
    if os.path.isfile(pkg_path):
        try:
            with open(pkg_path) as f:
                pkg = json.load(f)
            all_deps = set(pkg.get("dependencies", {}).keys()) | set(pkg.get("devDependencies", {}).keys())
            if "react" in all_deps and "Next.js" not in frameworks and "Remix" not in frameworks:
                frameworks.append("React")
            if "vue" in all_deps and "Nuxt" not in frameworks:
                frameworks.append("Vue")
            if "@angular/core" in all_deps and "Angular" not in frameworks:
                frameworks.append("Angular")
            if "express" in all_deps:
                frameworks.append("Express")
            if "fastify" in all_deps:
                frameworks.append("Fastify")
            if "nest" in all_deps or "@nestjs/core" in all_deps:
                frameworks.append("NestJS")
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    project_name = os.path.basename(cwd)
    return {
        "name": project_name,
        "languages": detected or ["unknown"],
        "primary": detected[0] if detected else "unknown",
        "frameworks": frameworks,
    }


def _detect_ai_tool() -> dict:
    """Detect which AI coding tool is installed."""
    cwd = os.getcwd()
    tools = []

    # Cursor
    if os.path.exists(os.path.join(cwd, ".cursor")):
        tools.append({
            "name": "Cursor",
            "config_path": os.path.join(cwd, ".cursor", "mcp.json"),
            "config_key": "mcpServers",
        })

    # VS Code MCP-compatible assistants (Cline, Roo, Continue, etc.)
    if os.path.exists(os.path.join(cwd, ".vscode")):
        tools.append({
            "name": "VS Code",
            "config_path": os.path.join(cwd, ".vscode", "mcp.json"),
            "config_key": "mcpServers",
        })

    # Windsurf
    if os.path.exists(os.path.join(cwd, ".windsurf")):
        tools.append({
            "name": "Windsurf",
            "config_path": os.path.join(cwd, ".windsurf", "mcp.json"),
            "config_key": "mcpServers",
        })

    # Claude Desktop (global config) — only add if no project-local tool found
    # Avoids overwriting global Claude config when user only uses Cursor/VS Code
    if not tools:
        system = platform.system()
        if system == "Darwin":
            claude_cfg = os.path.expanduser(
                "~/Library/Application Support/Claude/claude_desktop_config.json"
            )
        elif system == "Windows":
            appdata = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
            claude_cfg = os.path.join(appdata, "Claude", "claude_desktop_config.json")
        else:
            claude_cfg = os.path.expanduser("~/.config/claude/claude_desktop_config.json")

        tools.append({
            "name": "Claude Desktop",
            "config_path": claude_cfg,
            "config_key": "mcpServers",
        })

    return {"tools": tools, "primary": tools[0] if tools else None}


def _generate_mcp_config() -> dict:
    """Generate the MCP server config for Entroly."""
    # Use the exact interpreter that is running `entroly wrap cursor`.
    # Cursor/Windsurf/VS Code launch MCP servers outside the user's shell, so
    # `"command": "entroly"` can resolve to a stale global console script or a
    # different virtualenv. `python -m entroly.server` keeps the MCP runtime
    # bound to the installed package environment, including the `mcp` SDK.
    return {
        "entroly": {
            "command": sys.executable,
            "args": ["-m", "entroly.server"],
            "env": {
                "PYTHONIOENCODING": "utf-8",
            },
        }
    }


def _load_config_object(config_path: str) -> dict:
    """Load a JSON configuration as an object, failing closed on bad input."""
    path = Path(config_path)
    if not path.exists():
        return {}
    try:
        with path.open(encoding="utf-8") as handle:
            value = json.load(handle)
    except (UnicodeDecodeError, json.JSONDecodeError, OSError) as exc:
        raise ValueError(f"existing config is not valid UTF-8 JSON: {config_path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"existing config root must be a JSON object: {config_path}")
    return value


def _next_config_backup_path(config_path: Path, suffix: str) -> Path:
    """Return a non-destructive backup path beside *config_path*."""
    candidate = Path(f"{config_path}{suffix}")
    if not candidate.exists():
        return candidate
    for index in range(1, 10_000):
        candidate = Path(f"{config_path}{suffix}.{index}")
        if not candidate.exists():
            return candidate
    raise OSError(f"too many Entroly backups beside {config_path}")


def _backup_config_file(config_path: Path, suffix: str) -> Path:
    """Create and fsync a non-destructive byte-for-byte configuration backup."""
    backup_path = _next_config_backup_path(config_path, suffix)
    try:
        with config_path.open("rb") as source, backup_path.open("xb") as destination:
            shutil.copyfileobj(source, destination)
            destination.flush()
            os.fsync(destination.fileno())
        shutil.copystat(config_path, backup_path, follow_symlinks=False)
        return backup_path
    except BaseException:
        try:
            backup_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _fsync_directory(directory: Path) -> None:
    """Best-effort durability barrier for a completed atomic replacement."""
    if os.name == "nt":
        return
    descriptor = None
    try:
        descriptor = os.open(str(directory), os.O_RDONLY)
        os.fsync(descriptor)
    except OSError:
        # Some filesystems do not allow directory fsync. The file itself was
        # already fsynced; do not turn that platform limitation into data loss.
        pass
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _atomic_write_config(config_path: str, value: dict) -> None:
    """Atomically write a JSON config beside its final destination."""
    path = Path(config_path)
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    existing_mode = None
    if path.exists():
        existing_mode = path.stat().st_mode & 0o777

    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.entroly-",
        suffix=".tmp",
        dir=str(parent),
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        if existing_mode is not None:
            os.chmod(temporary, existing_mode)
        os.replace(temporary, path)
        _fsync_directory(parent)
    except BaseException:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _write_config(tool: dict, dry_run: bool = False) -> str:
    """Merge Entroly into an MCP config with backup and atomic replacement."""
    config_path = tool["config_path"]
    config_key = tool["config_key"]
    existing = _load_config_object(config_path)
    original = copy.deepcopy(existing)

    servers = existing.get(config_key)
    if servers is None:
        servers = {}
        existing[config_key] = servers
    if not isinstance(servers, dict):
        raise ValueError(f"{config_key!r} must be a JSON object in {config_path}")
    servers.update(_generate_mcp_config())

    if dry_run:
        # Never echo unrelated editor preferences, account identifiers, or
        # other MCP server configuration into terminals and CI logs.
        return json.dumps(
            {
                "operation": "merge",
                "config_key": config_key,
                "entry": _generate_mcp_config(),
                "preserves_unrelated_configuration": True,
            },
            indent=2,
            ensure_ascii=False,
        )

    path = Path(config_path)
    if existing == original:
        return str(path)
    if path.exists():
        _backup_config_file(path, ".entroly-backup")
    _atomic_write_config(config_path, existing)
    return config_path


def _remove_entroly_config(tool: dict, dry_run: bool = False) -> tuple[str, str | None]:
    """Remove only Entroly's MCP entry and return (status, backup path)."""
    config_path = tool["config_path"]
    config_key = tool["config_key"]
    path = Path(config_path)
    if not path.exists():
        return "missing", None

    existing = _load_config_object(config_path)
    servers = existing.get(config_key)
    if servers is None:
        return "absent", None
    if not isinstance(servers, dict):
        raise ValueError(f"{config_key!r} must be a JSON object in {config_path}")
    if "entroly" not in servers:
        return "absent", None

    del servers["entroly"]
    if dry_run:
        return json.dumps(
            {
                "operation": "remove",
                "config_key": config_key,
                "entry": "entroly",
                "preserves_unrelated_configuration": True,
            },
            indent=2,
            ensure_ascii=False,
        ), None

    backup = _backup_config_file(path, ".entroly-unwrapped-backup")
    _atomic_write_config(config_path, existing)
    return "removed", str(backup)


def cmd_init(args):
    """entroly init — auto-detect and configure."""
    print(f"""
{C.CYAN}{C.BOLD}  Entroly — Context Optimizer for AI Coding Agents{C.RESET}
""")

    # Detect project
    project = _detect_project_type()
    langs = ', '.join(project['languages'])
    fw = project.get('frameworks', [])
    fw_str = f" + {', '.join(fw)}" if fw else ""
    print(f"  {C.GRAY}Project:{C.RESET}  {C.BOLD}{project['name']}{C.RESET} ({langs}{fw_str})")

    # Detect AI tools
    tools = _detect_ai_tool()

    if not tools["tools"]:
        print(f"\n  {C.YELLOW}No AI tool detected.{C.RESET}")
        print(f"  {C.GRAY}Create a .cursor/, .vscode/, or .windsurf/ directory first.{C.RESET}")
        return

    # Show detected tools
    for tool in tools["tools"]:
        exists = os.path.exists(tool["config_path"])
        status = f"{C.GRAY}(config exists){C.RESET}" if exists else ""
        print(f"  {C.GRAY}AI Tool:{C.RESET}  {C.BOLD}{tool['name']}{C.RESET} {status}")

    print()

    # Write configs
    for tool in tools["tools"]:
        if args.dry_run:
            config = _write_config(tool, dry_run=True)
            print(f"  {C.GRAY}Would merge into {tool['config_path']}:{C.RESET}")
            print(f"  {config}")
        else:
            path = _write_config(tool)
            print(f"  {C.GREEN}Generated{C.RESET} {path}")

    # Count indexable files
    from entroly.auto_index import _git_ls_files, _should_index
    files = _git_ls_files(os.getcwd())
    indexable = [f for f in files if _should_index(f)]
    print(f"  {C.GREEN}Entroly will auto-index {len(indexable)} files on first run{C.RESET}")

    print(f"""
  {C.BOLD}Next:{C.RESET} Restart your AI tool. Entroly is now active.
  {C.GRAY}The MCP server auto-indexes your codebase on startup.{C.RESET}
  {C.GRAY}Call {C.CYAN}entroly_dashboard{C.GRAY} from your AI to see live value metrics.{C.RESET}
""")


def cmd_serve(args):
    """entroly serve — start MCP server with auto-indexing."""
    # Set env so Docker launcher knows to go native
    os.environ["ENTROLY_NO_DOCKER"] = "1"

    if getattr(args, "debug", False):
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s [entroly:%(name)s] %(levelname)s %(message)s",
            stream=sys.stderr,
            force=True,
        )

    # Import and run
    from entroly.server import main
    main()


def cmd_attach(args):
    """Issue, inspect, revoke, or serve a scoped MCP attachment."""
    from entroly.session_attach import (
        AttachmentStore,
        format_command,
        install_attachment,
        parse_ttl,
        serve_attachment,
        uninstall_attachment,
    )

    state_dir = Path(args.state_dir).expanduser() if args.state_dir else _ENTROLY_DIR
    if args.attach_action == "serve":
        serve_attachment(
            grant_id=args.grant_id,
            token_file=args.token_file,
            state_dir=state_dir,
        )
        return 0

    store = AttachmentStore(state_dir)
    if args.attach_action == "create":
        issued = store.create(
            client=args.client,
            project_root=args.project,
            scopes=args.scope,
            ttl_seconds=parse_ttl(args.ttl),
            session_id=args.session,
        )
        if args.install:
            install_attachment(issued, store=store)
        if args.json_output:
            print(json.dumps(issued.public_payload(), indent=2, sort_keys=True))
        else:
            print(f"\n  {C.GREEN}Attachment created:{C.RESET} {issued.grant.grant_id}")
            print(f"  {C.GRAY}Client:{C.RESET} {issued.grant.client}")
            print(f"  {C.GRAY}Project:{C.RESET} {issued.grant.project_root}")
            print(f"  {C.GRAY}Expires:{C.RESET} {time.ctime(issued.grant.expires_at)}")
            print(f"  {C.GRAY}Scopes:{C.RESET} {', '.join(issued.grant.scopes)}")
            if args.install:
                print(f"  {C.GREEN}Client configuration installed.{C.RESET}")
            else:
                print("\n  Run the client configuration command:")
                for command in issued.install_commands:
                    print(f"    {format_command(command)}")
        return 0
    if args.attach_action == "list":
        grants = store.list(include_inactive=args.all)
        payload = [grant.public_payload() for grant in grants]
        if args.json_output:
            print(json.dumps(payload, indent=2, sort_keys=True))
        elif not grants:
            print("No active Entroly attachments.")
        else:
            for grant in grants:
                print(
                    f"{grant.grant_id}  {grant.status:<7}  {grant.client:<8}  "
                    f"{grant.project_root}"
                )
        return 0
    if args.attach_action == "revoke":
        grant = store.revoke(args.grant_id)
        if args.uninstall:
            uninstall_attachment(grant)
        if args.json_output:
            print(json.dumps(grant.public_payload(), indent=2, sort_keys=True))
        else:
            suffix = " and removed its client configuration" if args.uninstall else ""
            print(f"Revoked Entroly attachment {grant.grant_id}{suffix}.")
        return 0
    raise ValueError("choose an attach action: create, list, or revoke")


def cmd_dashboard(args):
    """entroly dashboard — launch live web dashboard at localhost:9378."""
    from entroly.auto_index import auto_index
    from entroly.dashboard import start_dashboard
    from entroly.server import EntrolyEngine

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Value Dashboard{C.RESET}\n")

    engine = EntrolyEngine()
    result = auto_index(engine, force=args.force)

    if result["status"] == "indexed":
        print(f"  {C.GREEN}Indexed {result['files_indexed']} files ({result['total_tokens']:,} tokens) in {result['duration_s']}s{C.RESET}")
    elif result["status"] == "skipped":
        print(f"  {C.GRAY}Using persistent index ({result['existing_fragments']} fragments){C.RESET}")

    # Run an optimize to populate all engine subsystems
    engine.optimize_context(token_budget=128000, query="project overview")

    # Refuse to interfere with an existing service on the dashboard port.
    if not _free_port(args.port):
        print(f"  {C.RED}Port {args.port} is already in use.{C.RESET}")
        print(f"  {C.GRAY}Try: entroly dashboard --port <other-port>{C.RESET}")
        return

    # Start web dashboard
    start_dashboard(engine=engine, port=args.port, daemon=False)
    print(f"\n  {C.GREEN}{C.BOLD}Dashboard live at http://localhost:{args.port}{C.RESET}")
    print(f"  {C.GRAY}Showing: tokens saved, PRISM weights, health grade, SAST, dep graph, knapsack decisions{C.RESET}")
    print(f"  {C.GRAY}Press Ctrl+C to stop{C.RESET}\n")

    # Auto-open in browser
    try:
        import webbrowser
        webbrowser.open(f"http://localhost:{args.port}")
    except Exception:
        pass

    try:
        import time
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n  {C.GRAY}Dashboard stopped.{C.RESET}")


def cmd_health(args):
    """entroly health — analyze codebase health."""
    import json as _json

    from entroly.auto_index import auto_index
    from entroly.server import EntrolyEngine

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Health Analysis{C.RESET}\n")

    engine = EntrolyEngine()
    result = auto_index(engine)

    if result["status"] == "indexed":
        print(f"  {C.GREEN}Indexed {result['files_indexed']} files ({result['total_tokens']:,} tokens){C.RESET}")

    # Run optimize to build dep graph
    engine.optimize_context(token_budget=128000, query="")

    # Get health report
    if engine._use_rust:
        health = _json.loads(engine._rust.analyze_health())
        grade = health.get("health_grade", "?")
        score = health.get("code_health_score", 0)

        grade_colors = {"A": C.GREEN, "B": C.GREEN, "C": C.YELLOW, "D": C.RED, "F": C.RED}
        gc = grade_colors.get(grade, C.GRAY)

        print(f"\n  {C.BOLD}Code Health:{C.RESET}  {gc}{C.BOLD}{grade}{C.RESET} ({score}/100)\n")

        items = [
            ("Clone pairs", health.get("clone_pairs", [])),
            ("Dead symbols", health.get("dead_symbols", [])),
            ("God files", health.get("god_files", [])),
            ("Arch violations", health.get("arch_violations", [])),
            ("Naming issues", health.get("naming_issues", [])),
        ]
        for name, lst in items:
            count = len(lst) if isinstance(lst, list) else 0
            color = C.GREEN if count == 0 else C.YELLOW if count < 5 else C.RED
            sym = "+" if count == 0 else "!"
            print(f"  {color}{sym} {name}: {count}{C.RESET}")
            if count > 0 and args.verbose:
                for item in lst[:5]:
                    detail = item if isinstance(item, str) else str(item)
                    print(f"    {C.GRAY}-> {detail[:80]}{C.RESET}")

        rec = health.get("top_recommendation")
        if rec:
            print(f"\n  {C.YELLOW}{rec}{C.RESET}")

        # Security summary
        sec = _json.loads(engine._rust.security_report())
        total_findings = sec.get("critical_total", 0) + sec.get("high_total", 0)
        if total_findings > 0:
            taint = sec.get("taint_flow_total", 0)
            pat = sec.get("pattern_only_total", 0)
            print(f"\n  {C.RED}{total_findings} security findings ({sec.get('critical_total', 0)} critical, {sec.get('high_total', 0)} high){C.RESET}")
            print(f"    {C.GRAY}{taint} taint-flow (high-confidence) + {pat} pattern-only (review for FPs){C.RESET}")
            if sec.get("most_vulnerable_fragment"):
                print(f"    {C.GRAY}Most vulnerable: {sec['most_vulnerable_fragment']}{C.RESET}")
        else:
            print(f"\n  {C.GREEN}No security vulnerabilities detected{C.RESET}")

    print()


def cmd_autotune(args):
    """entroly autotune — optimize engine hyperparameters."""
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "bench"))

    # Handle --rollback
    if getattr(args, "rollback", False):
        print(f"\n{C.CYAN}{C.BOLD}  Entroly Autotune -- Rollback{C.RESET}\n")
        try:
            from bench.autotune import rollback_config
            config_path = Path(os.path.dirname(__file__)).parent / "bench" / "tuning_config.json"
            result = rollback_config(config_path)
            if result["status"] == "no_backup_found":
                print(f"  {C.RED}No backup found -- nothing to roll back.{C.RESET}\n")
                return 1
            print(f"  {C.GREEN}Restored from:{C.RESET} {result['restored_from']}")
            print(f"  {C.GREEN}{C.BOLD}Rollback complete.{C.RESET} Previous config is now active.\n")
            return 0
        except ImportError:
            print(f"  {C.RED}bench.autotune not available{C.RESET} — autotune requires a "
                  f"source checkout (the bench/ harness is not in the published package).")
            return 1

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Autotune{C.RESET}\n")
    print(f"  {C.GRAY}Running {args.iterations} iterations of mutation-based optimization...{C.RESET}\n")

    try:
        from bench.autotune import autotune
        result = autotune(iterations=args.iterations)
        # composite_score = 0.50·recall + 0.25·precision + 0.25·context_efficiency
        # on bench/cases.json. Range [0, 1]; higher is better.
        print(f"\n  {C.GREEN}{C.BOLD}Best composite score: {result.get('final_score', 0):.4f} / 1.0{C.RESET}")
        print(f"  {C.GRAY}= 0.50·recall + 0.25·precision + 0.25·efficiency on bench/cases.json{C.RESET}")
        print(f"  {C.GRAY}Config saved to bench/tuning_config.json{C.RESET}")
        print(f"  {C.GRAY}To undo: entroly autotune --rollback{C.RESET}\n")
        return 0
    except ImportError:
        # The bench/ harness (autotune.py, cases.json) is a development tool and
        # is NOT shipped in the published pip/npm package — so there is no script
        # to fall back to. The old fallback pointed at site-packages/entroly/../
        # bench/autotune.py, printed "can't open file", and still exited 0.
        # Report clearly and fail instead.
        print(
            f"  {C.RED}autotune is unavailable in this install.{C.RESET} The bench/ "
            f"harness is not included in the published package; clone the repository "
            f"and run autotune from a source checkout."
        )
        return 1
    except Exception as exc:
        logging.getLogger("entroly").debug("autotune command failed", exc_info=True)
        print(f"  {C.RED}Autotune failed:{C.RESET} {exc}")
        return 1


def _should_check_upstream() -> bool:
    """Return whether startup may contact provider hosts for diagnostics."""
    return os.environ.get("ENTROLY_CHECK_UPSTREAM", "0") == "1"


def _check_upstream(config) -> None:
    """Quick connectivity test against upstream LLM APIs.

    Sends a HEAD request with a 3s timeout to catch DNS/firewall/VPN issues
    before the first real request hangs for 120s. Warns but doesn't block.
    """
    import urllib.request
    endpoints = [
        ("OpenAI", config.openai_base_url),
        ("Anthropic", config.anthropic_base_url),
    ]
    for name, base_url in endpoints:
        try:
            req = urllib.request.Request(base_url, method="HEAD")
            urllib.request.urlopen(req, timeout=3)
            print(f"  {C.GREEN}[OK]{C.RESET} {name} API reachable")
        except Exception:
            print(
                f"  {C.YELLOW}[!!]{C.RESET} {name} API unreachable ({base_url})\n"
                f"       {C.GRAY}Requests will still be forwarded — "
                f"the circuit breaker will handle failures.{C.RESET}"
            )


def cmd_proxy(args):
    """entroly proxy — start the invisible prompt compiler proxy."""
    if getattr(args, "debug", False):
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s [entroly:%(name)s] %(levelname)s %(message)s",
            stream=sys.stderr,
            force=True,
        )

    # Gap #28: --bypass flag sets env var consumed by proxy
    if getattr(args, "bypass", False):
        os.environ["ENTROLY_BYPASS"] = "1"

    try:
        from entroly.auto_index import auto_index, start_incremental_watcher
        from entroly.proxy import create_proxy_app
        from entroly.proxy_config import ProxyConfig, resolve_quality
        from entroly.server import EntrolyEngine
    except ImportError as exc:
        missing = getattr(exc, "name", None) or str(exc)
        if missing not in {"httpx", "starlette"}:
            raise
        print(
            f"  {C.RED}Proxy dependency missing:{C.RESET} {missing}\n"
            f"  {C.GRAY}Install proxy support with: python -m pip install 'entroly[proxy]'{C.RESET}",
            file=sys.stderr,
        )
        return 1

    print(f"""
{C.CYAN}{C.BOLD}  Entroly Prompt Compiler Proxy{C.RESET}
{C.GRAY}  Invisible intelligence layer for any AI coding tool{C.RESET}
""")

    # Load config from environment
    config = ProxyConfig.from_env()
    if args.port:
        config.port = args.port
    if args.host:
        config.host = args.host
    if args.quality is not None:
        quality_val = resolve_quality(args.quality)
        config.quality = quality_val
        config._apply_quality_dial(quality_val)
    if getattr(args, "witness", None) is not None:
        config.witness_mode = args.witness
    if getattr(args, "witness_nli", False):
        config.witness_use_nli = True
    if getattr(args, "witness_embed", False):
        config.witness_embed = True
    if getattr(args, "witness_profile", None):
        config.witness_profile = args.witness_profile

    # Initialize engine + auto-index codebase (non-blocking for large repos)
    engine = EntrolyEngine()

    import threading

    _index_ready = threading.Event()
    _index_result = {}

    def _bg_index():
        nonlocal _index_result
        _index_result = auto_index(engine, force=args.force)
        _index_ready.set()

    idx_thread = threading.Thread(target=_bg_index, daemon=True, name="entroly-autoindex")
    idx_thread.start()

    # Wait up to 5s for auto-index. If it takes longer, proceed — the proxy
    # is usable immediately (it just won't have context yet).
    if _index_ready.wait(timeout=5.0):
        result = _index_result
        if result["status"] == "indexed":
            print(f"  {C.GREEN}Indexed {result['files_indexed']} files ({result['total_tokens']:,} tokens) in {result['duration_s']}s{C.RESET}")
        elif result["status"] == "skipped":
            print(f"  {C.GRAY}Using persistent index ({result['existing_fragments']} fragments){C.RESET}")
    else:
        print(f"  {C.YELLOW}Auto-indexing in progress...{C.RESET} Proxy starting now (context available shortly)")

    # Start incremental file watcher so new/modified files are picked up
    start_incremental_watcher(engine)

    # Run a warm-up optimize to populate all engine subsystems
    engine.optimize_context(token_budget=128000, query="project overview")

    # Refuse to interfere with existing services on the proxy or dashboard ports.
    if not _free_port(config.port):
        print(f"  {C.RED}Port {config.port} is already in use.{C.RESET}")
        print(f"  {C.GRAY}Try: entroly proxy --port <other-port>{C.RESET}")
        return
    if not _free_port(9378):
        print(f"  {C.RED}Dashboard port 9378 is already in use.{C.RESET}")
        print(f"  {C.GRAY}Stop the existing service before starting `entroly proxy`.{C.RESET}")
        return

    # Opt-in connectivity probe — useful for diagnosing DNS/firewall/VPN
    # failures without contacting provider hosts during a default startup.
    if _should_check_upstream():
        _check_upstream(config)

    # Create the ASGI app (this also starts the dashboard on :9378)
    app = create_proxy_app(
        engine,
        config,
        start_autotune=getattr(args, "autotune_daemon", False),
    )

    print(f"""
  {C.GREEN}{C.BOLD}Proxy live at http://{config.host}:{config.port}{C.RESET}
  {C.GREEN}{C.BOLD}Dashboard at http://localhost:9378{C.RESET}

  {C.BOLD}To use:{C.RESET} Set your AI tool's API base URL to:
    {C.CYAN}http://localhost:{config.port}/v1{C.RESET}

  {C.GRAY}Every LLM request is intercepted -> optimized -> forwarded.{C.RESET}
  {C.GRAY}Live pipeline latency: http://localhost:9378 — or `entroly status`.{C.RESET}
  {C.GRAY}File watcher active — new/modified files auto-indexed every 120s.{C.RESET}
  {C.GRAY}Press Ctrl+C to stop.{C.RESET}
""")

    try:
        import uvicorn
        uvicorn.run(app, host=config.host, port=config.port, log_level="warning")
    except ImportError:
        print(f"  {C.RED}uvicorn not installed. Install with: pip install uvicorn{C.RESET}")
        print(f"  {C.GRAY}Or run directly: uvicorn entroly.proxy:app --port {config.port}{C.RESET}")
    except KeyboardInterrupt:
        print(f"\n  {C.GRAY}Proxy stopped.{C.RESET}")


def cmd_daemon(args):
    """entroly daemon — start the unified supervisor process."""
    if getattr(args, "debug", False):
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s [entroly:%(name)s] %(levelname)s %(message)s",
            stream=sys.stderr,
            force=True,
        )

    from entroly.daemon import EntrolyDaemon, _install_log_buffer

    _install_log_buffer()

    print(f"""
{C.CYAN}{C.BOLD}  Entroly Daemon — Unified Supervisor{C.RESET}
{C.GRAY}  Single process managing proxy, dashboard, MCP, learning{C.RESET}
""")

    daemon = EntrolyDaemon(
        proxy_port=getattr(args, "proxy_port", 9377),
        dashboard_port=getattr(args, "dashboard_port", 9378),
        mcp_port=getattr(args, "mcp_port", 9379),
        host=getattr(args, "host", "127.0.0.1"),
        enable_proxy=not getattr(args, "no_proxy", False),
        enable_mcp=not getattr(args, "no_mcp", False),
        quality=getattr(args, "quality", "balanced") or "balanced",
    )

    daemon.start()

    proxy_line = (
        f"    Proxy:     http://localhost:{daemon.state.proxy.port}\n"
        if daemon._enable_proxy else
        f"    Proxy:     {C.GRAY}disabled (--no-proxy){C.RESET}\n"
    )
    mcp_line = (
        f"    MCP (SSE): http://localhost:{daemon.state.mcp.port}/sse\n"
        if daemon._enable_mcp else
        f"    MCP (SSE): {C.GRAY}disabled (--no-mcp){C.RESET}\n"
    )
    print(f"""
  {C.GREEN}{C.BOLD}Daemon running{C.RESET}
{proxy_line}    Dashboard: http://localhost:{daemon.state.dashboard.port}
{mcp_line}    Control:   http://localhost:{daemon.state.dashboard.port}/api/control/status

  {C.GRAY}Press Ctrl+C to stop all services.{C.RESET}
""")

    daemon.run_forever()


def cmd_benchmark(args):
    """entroly benchmark — run competitive comparison."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Competitive Benchmark{C.RESET}\n")

    from entroly.auto_index import auto_index
    from entroly.server import EntrolyEngine

    engine = EntrolyEngine()
    auto_index(engine)

    queries = [
        "How does authentication work?",
        "Find security vulnerabilities",
        "Explain the data model",
    ]

    # Get total tokens
    if engine._use_rust:
        stats = engine._rust.stats()
        total = stats.get("session", {}).get("total_tokens_tracked", 0)
    else:
        total = getattr(engine, "_total_token_count", 0)

    if total == 0:
        print(f"  {C.YELLOW}No files indexed. Run from a project directory.{C.RESET}")
        return

    # Honest baseline: a 32K "paste matching files into the prompt" dump,
    # capped at what actually exists. Claiming savings vs. the whole repo
    # (7M+ tokens) is marketing, not measurement.
    baseline = min(total, 32_000)
    budget = getattr(args, "budget", 4096)
    compare_baseline = getattr(args, "compare_baseline", False)
    print(f"  Codebase: {total:,} total tokens  |  Naive baseline: {baseline:,} tokens (32K dump or repo total)\n")
    if compare_baseline:
        print(f"  {C.GRAY}Comparing current selector output against the deterministic 32K baseline.{C.RESET}\n")
    print(f"  {'Query':<45} {'Baseline':>9} {'Entroly':>8} {'Saved':>6}")
    print(f"  {'-'*45} {'-'*9} {'-'*8} {'-'*6}")

    total_saved = 0
    for q in queries:
        engine.advance_turn()
        opt = engine.optimize_context(token_budget=budget, query=q)
        selected = opt.get("selected_fragments", []) or opt.get("selected", [])
        used = sum(f.get("token_count", 0) for f in selected)
        saved = max(baseline - used, 0)
        pct = (saved * 100) // max(baseline, 1)
        total_saved += saved
        print(f"  {q:<45} {baseline:>9,} {used:>7,} {pct:>5}%")

    avg_pct = (total_saved * 100) // max(baseline * len(queries), 1)
    print(f"\n  {C.GREEN}{C.BOLD}Average reduction vs. 32K dump: {avg_pct}%{C.RESET}")
    print(f"  {C.GRAY}Budget: {budget:,} tokens. Selector picks whole fragments; no byte-truncation.{C.RESET}\n")


def cmd_status(args):
    """entroly status — check if server/proxy is running."""
    import urllib.request

    port = args.port or 9377
    if getattr(args, "json_output", False):
        from .runtime_status import runtime_status

        report = runtime_status(port=port)
        print(json.dumps(report, sort_keys=True))
        if getattr(args, "require_running", False) and not report["healthy"]:
            return 1
        return 0

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Status{C.RESET}\n")

    endpoints = [
        ("Proxy", f"http://127.0.0.1:{port}/health", "entroly-proxy"),
        ("Dashboard", "http://127.0.0.1:9378/health", "entroly-dashboard"),
    ]

    proxy_running = False
    for name, url, expected_service in endpoints:
        if _is_entroly_service_running(url, expected_service):
            print(f"  {C.GREEN}[OK]{C.RESET} {name}: {url} -- ok")
            if name == "Proxy":
                proxy_running = True
        else:
            print(f"  {C.RED}[--]{C.RESET} {name}: not running")

    # Show stats if proxy is up
    try:
        if not proxy_running:
            raise RuntimeError("proxy not running")
        resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/stats", timeout=2)
        stats = json.loads(resp.read())
        total = stats.get("requests_total", 0)
        opt = stats.get("requests_optimized", 0)
        rate = stats.get("optimization_rate", "0%")
        breaker = stats.get("circuit_breaker", "closed")
        latency = stats.get("pipeline_latency", {})
        print(f"\n  {C.BOLD}Stats:{C.RESET}")
        print(f"    Requests: {opt}/{total} optimized ({rate})")
        print(f"    Circuit breaker: {breaker}")
        if latency.get("count", 0) > 0:
            print(f"    Pipeline latency: {latency['mean_ms']:.1f}ms avg (+/- {latency['stddev_ms']:.1f}ms)")
    except Exception:
        pass

    # Show engine stats (resonance, coverage, consolidation) if available
    try:
        resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/engine-stats", timeout=2)
        engine_stats = json.loads(resp.read())
        resonance = engine_stats.get("resonance", {})
        consolidation = engine_stats.get("consolidation", {})
        if resonance:
            pairs = resonance.get("tracked_pairs", 0)
            strength = resonance.get("mean_strength", 0.0)
            w_res = resonance.get("w_resonance", 0.0)
            calibrated = resonance.get("is_calibrated", False)
            cal_str = f"{C.GREEN}calibrated{C.RESET}" if calibrated else f"{C.YELLOW}cold-start{C.RESET}"
            print(f"\n  {C.BOLD}Context Resonance:{C.RESET}")
            print(f"    Pairs tracked: {pairs}  |  Mean strength: {strength:.4f}  |  w_resonance: {w_res:.4f}")
            print(f"    Status: {cal_str}")
        if consolidation:
            total_c = consolidation.get("total_consolidations", 0)
            tokens_c = consolidation.get("tokens_saved", 0)
            if total_c > 0:
                print(f"\n  {C.BOLD}Fragment Consolidation (Maxwell's Demon):{C.RESET}")
                print(f"    Consolidated: {total_c} fragments  |  Tokens saved: {tokens_c}")
        causal = engine_stats.get("causal", {})
        if causal:
            traces = causal.get("total_traces", 0)
            tracked = causal.get("tracked_fragments", 0)
            interventional = causal.get("interventional_fragments", 0)
            temporal = causal.get("temporal_links", 0)
            gravity = causal.get("gravity_sources", 0)
            mass = causal.get("mean_causal_mass", 0.0)
            print(f"\n  {C.BOLD}Causal Context Graph:{C.RESET}")
            print(f"    Traces: {traces}  |  Tracked: {tracked}  |  Interventional: {interventional}")
            print(f"    Temporal links: {temporal}  |  Gravity sources: {gravity}  |  Mean mass: {mass:.4f}")
    except Exception:
        pass

    print()


def cmd_config(args):
    """entroly config show — display current configuration."""
    from entroly.proxy_config import QUALITY_PRESETS, ProxyConfig

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Configuration{C.RESET}\n")

    config = ProxyConfig.from_env()

    print(f"  {C.BOLD}Quality Presets:{C.RESET} {', '.join(f'{k}={v}' for k, v in QUALITY_PRESETS.items())}\n")

    # Group settings
    groups = {
        "Network": ["port", "host", "openai_base_url", "anthropic_base_url", "gemini_base_url"],
        "Quality": ["quality", "context_fraction"],
        "Features": [k for k in vars(config) if k.startswith("enable_")],
        "ECDB": [k for k in vars(config) if k.startswith("ecdb_")],
        "IOS": [k for k in vars(config) if k.startswith("ios_")],
        "EGTC": ["fisher_scale", "egtc_alpha", "egtc_gamma", "egtc_epsilon",
                  "trajectory_c_min", "trajectory_lambda"],
    }

    for group_name, keys in groups.items():
        print(f"  {C.BOLD}{group_name}:{C.RESET}")
        for key in keys:
            val = getattr(config, key, None)
            if val is not None:
                print(f"    {C.GRAY}{key}:{C.RESET} {val}")
        print()


def cmd_telemetry(args):
    """Manage explicit-consent, content-blind product health telemetry."""
    from entroly.product_telemetry import (
        disable_and_purge,
        enable,
        flush,
        preview,
        status,
    )

    action = getattr(args, "action", "status")
    json_output = bool(getattr(args, "json_output", False))
    if action == "on":
        report = enable(
            endpoint=getattr(args, "endpoint", None),
            error_events=not bool(getattr(args, "no_error_events", False)),
        )
        if json_output:
            print(json.dumps({"status": report, "schema": preview()}, sort_keys=True))
            return 0
        print(f"  {C.GREEN}Pseudonymous product-health telemetry enabled by explicit consent.{C.RESET}")
        print(
            f"  {C.GRAY}Collected: coarse surface/command outcomes, duration and token-"
            f"reduction buckets, release, OS family, and Python major.minor.{C.RESET}"
        )
        print(
            f"  {C.GRAY}Never collected: prompts, code, paths, filenames, model data, "
            f"exact token/cost amounts, error messages, tracebacks, hostnames, usernames, "
            f"credentials, or IPs.{C.RESET}"
        )
        if report["upload_configured"]:
            print(f"  {C.GRAY}Collector: {report['endpoint_origin']}{C.RESET}")
        else:
            print(
                f"  {C.YELLOW}No collector endpoint is configured; events remain in the "
                f"bounded local queue and nothing is uploaded.{C.RESET}"
            )
        print(f"  {C.GRAY}Withdraw consent and delete local telemetry: entroly telemetry off{C.RESET}")
        return 0
    if action == "off":
        report = disable_and_purge()
        if json_output:
            print(json.dumps(report, sort_keys=True))
            return 0
        print(f"  {C.GREEN}Telemetry disabled; local queue and pseudonymous identity purged.{C.RESET}")
        if report["remote_deletion"] == "deleted":
            print(f"  {C.GREEN}Previously uploaded events for recent monthly pseudonyms were deleted.{C.RESET}")
        elif report["remote_deletion"] in {"error", "blocked"}:
            print(
                f"  {C.YELLOW}Remote deletion could not be confirmed; collector retention "
                f"will expire uploaded aggregates automatically.{C.RESET}"
            )
        return 0
    if action == "preview":
        print(json.dumps(preview(), indent=2, sort_keys=True))
        return 0
    if action == "flush":
        report = flush(force=True)
        if json_output:
            print(json.dumps(report, sort_keys=True))
        else:
            print(f"  Telemetry flush: {report['status']} ({report.get('sent', 0)} sent)")
        return 0 if report["status"] not in {"error", "batch_too_large"} else 1

    report = status()
    if json_output:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0
    label = f"{C.GREEN}enabled{C.RESET}" if report["enabled"] else f"{C.GRAY}disabled (default){C.RESET}"
    print(f"  Pseudonymous product-health telemetry: {label}")
    print(f"  Upload configured: {report['upload_configured']}")
    print(f"  Queued events: {report['queued_events']}")
    print(f"  Local retention: {report['local_retention_days']} days")
    if report.get("endpoint_origin"):
        print(f"  Collector: {report['endpoint_origin']}")
    print(f"  {C.GRAY}Inspect the complete schema: entroly telemetry preview{C.RESET}")
    return 0


def is_telemetry_enabled() -> bool:
    """Check if opt-in telemetry is enabled. Always False by default."""
    try:
        from entroly.product_telemetry import is_enabled

        return is_enabled()
    except Exception:
        return False


def cmd_clean(args):
    """entroly clean — clear cached state (checkpoints, index, pull cache)."""
    entroly_dir = Path.home() / ".entroly"

    if not entroly_dir.exists():
        print(f"  {C.GRAY}Nothing to clean -- {entroly_dir} does not exist.{C.RESET}")
        return

    # Collect what will be removed
    targets = []
    checkpoint_dir = entroly_dir / "checkpoints"
    if checkpoint_dir.exists():
        count = sum(1 for _ in checkpoint_dir.rglob("*") if _.is_file())
        targets.append(("checkpoints", checkpoint_dir, count))

    index_files = list(entroly_dir.rglob("index.json.gz"))
    if index_files:
        targets.append(("index files", None, len(index_files)))

    pull_cache = entroly_dir / ".last_pull_ts"
    if pull_cache.exists():
        targets.append(("Docker pull cache", pull_cache, 1))

    if not targets:
        print(f"  {C.GRAY}Nothing to clean -- no cached state found.{C.RESET}")
        return

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Clean{C.RESET}\n")
    for name, path, count in targets:
        print(f"  {C.YELLOW}{name}:{C.RESET} {count} file(s)")

    if args.yes:
        confirmed = True
    elif not sys.stdin.isatty():
        # Non-interactive (piped/redirected) — skip prompt, default to no
        confirmed = False
    else:
        try:
            answer = input(f"\n  {C.BOLD}Remove all cached state? [y/N]{C.RESET} ").strip().lower()
            confirmed = answer in ("y", "yes")
        except (EOFError, KeyboardInterrupt):
            confirmed = False

    if not confirmed:
        print(f"  {C.GRAY}Aborted.{C.RESET}")
        return

    removed = 0
    # Remove checkpoints directory tree
    if checkpoint_dir.exists():
        shutil.rmtree(checkpoint_dir)
        removed += 1
        print(f"  {C.GREEN}Removed{C.RESET} {checkpoint_dir}")

    # Remove index files (skip those already removed with checkpoints dir)
    for idx_file in index_files:
        if idx_file.exists():
            idx_file.unlink()
            removed += 1
            print(f"  {C.GREEN}Removed{C.RESET} {idx_file}")

    # Remove pull cache
    if pull_cache.exists():
        pull_cache.unlink()
        removed += 1
        print(f"  {C.GREEN}Removed{C.RESET} {pull_cache}")

    print(f"\n  {C.GREEN}{C.BOLD}Cleaned {removed} item(s).{C.RESET} Next run will start fresh.\n")


def cmd_export(args):
    """entroly export — export learned state for sharing (Gap #32)."""
    import time as _time

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Export{C.RESET}\n")

    export_data = {
        "exported_at": _time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "version": __version__,
    }

    # Include tuning config
    active_config = _load_active_tuning_config()
    if active_config is not None:
        tuning_path, tuning_config = active_config
        export_data["tuning_config"] = tuning_config
        print(f"  {C.GREEN}[+]{C.RESET} {tuning_path.name}")

    # Telemetry consent and its pseudonym seed are deliberately machine-local.
    # Team exports must never transfer one person's consent or identity material.

    # Write export file. Positional `output_path` takes precedence over -o/--output.
    chosen = getattr(args, "output_path", None) or args.output
    out_path = Path(chosen) if chosen else Path("entroly_export.json")
    if out_path.parent != Path("."):
        out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(export_data, indent=2) + "\n")
    print(f"\n  {C.GREEN}{C.BOLD}Exported to {out_path}{C.RESET}")
    print(f"  {C.GRAY}Share this file with teammates: entroly import {out_path}{C.RESET}\n")


def cmd_import(args):
    """entroly import — import shared learned state (Gap #32)."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Import{C.RESET}\n")

    import_path = Path(args.file)
    if not import_path.exists():
        print(f"  {C.RED}File not found: {import_path}{C.RESET}")
        return

    try:
        data = json.loads(import_path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        print(f"  {C.RED}Invalid export file: {e}{C.RESET}")
        return

    print(f"  {C.GRAY}From: {data.get('exported_at', 'unknown')} (v{data.get('version', '?')}){C.RESET}")

    # Restore tuning config
    if "tuning_config" in data:
        tuning_path = _writable_tuning_config_path()
        tuning_path.parent.mkdir(parents=True, exist_ok=True)
        tuning_path.write_text(json.dumps(data["tuning_config"], indent=2) + "\n")
        print(f"  {C.GREEN}[+]{C.RESET} tuning_config.json restored to {tuning_path}")

    print(f"\n  {C.GREEN}{C.BOLD}Import complete.{C.RESET} Restart proxy/serve to apply.\n")


def cmd_drift(args):
    """entroly drift — detect weight drift / staleness (Gap #30)."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Drift Detection{C.RESET}\n")

    active_config = _load_active_tuning_config()
    if active_config is None:
        print(f"  {C.GRAY}No tuning_config.json found -- using defaults (no drift possible).{C.RESET}\n")
        return
    tuning_path, config = active_config
    print(f"  {C.GRAY}Config: {tuning_path}{C.RESET}")

    # Default weights for comparison. Keep keys in sync with cmd_doctor and
    # migrate defaults — mismatched keys silently report bogus drift.
    defaults = {"recency": 0.30, "frequency": 0.25, "semantic_sim": 0.25, "entropy": 0.20}
    current = config.get("weights", {})

    total_drift = 0.0
    for key, default_val in defaults.items():
        cur_val = current.get(key, current.get("semantic", default_val) if key == "semantic_sim" else default_val)
        drift = abs(cur_val - default_val)
        total_drift += drift
        indicator = C.GREEN if drift < 0.05 else C.YELLOW if drift < 0.15 else C.RED
        print(f"  {indicator}{key}:{C.RESET} {cur_val:.3f} (default: {default_val:.3f}, drift: {drift:.3f})")

    print(f"\n  {C.BOLD}Total drift:{C.RESET} {total_drift:.3f}")
    if total_drift > 0.3:
        print(f"  {C.RED}Significant drift detected.{C.RESET} Consider resetting:")
        print(f"    {C.CYAN}entroly autotune --rollback{C.RESET}")
    elif total_drift > 0.1:
        print(f"  {C.YELLOW}Moderate drift.{C.RESET} Weights have adapted from defaults.")
    else:
        print(f"  {C.GREEN}Minimal drift.{C.RESET} Weights are close to defaults.")

    # Check config age via file mtime
    import time as _time
    mtime = tuning_path.stat().st_mtime
    age_days = (_time.time() - mtime) / 86400
    if age_days > 30:
        print(f"\n  {C.YELLOW}Config is {age_days:.0f} days old.{C.RESET} Consider re-running autotune.")
    print()


def cmd_profile(args):
    """entroly profile — manage per-project weight profiles (Gap #31)."""
    import hashlib

    profiles_dir = _ENTROLY_DIR / "profiles"

    if args.profile_action == "save":
        # Save current tuning config as a named profile
        active_config = _load_active_tuning_config()
        if active_config is None:
            print(f"  {C.RED}No tuning defaults available to save.{C.RESET}")
            return 1
        tuning_path, config = active_config
        profiles_dir.mkdir(parents=True, exist_ok=True)
        name = args.name or hashlib.sha256(os.getcwd().encode()).hexdigest()[:8]
        profile_path = profiles_dir / f"{name}.json"
        profile_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
        print(f"  {C.GREEN}Profile '{name}' saved{C.RESET} ({profile_path})")
        print(f"  {C.GRAY}Source: {tuning_path}{C.RESET}")

    elif args.profile_action == "load":
        if not args.name:
            print(f"  {C.RED}Specify a profile name: entroly profile load <name>{C.RESET}")
            return 1
        profile_path = profiles_dir / f"{args.name}.json"
        if not profile_path.exists():
            print(f"  {C.RED}Profile '{args.name}' not found.{C.RESET}")
            return 1
        tuning_path = _writable_tuning_config_path()
        tuning_path.parent.mkdir(parents=True, exist_ok=True)
        import shutil
        shutil.copy2(str(profile_path), str(tuning_path))
        print(f"  {C.GREEN}Profile '{args.name}' loaded.{C.RESET} Restart proxy to apply.")
        print(f"  {C.GRAY}Wrote: {tuning_path}{C.RESET}")

    elif args.profile_action == "list":
        if not profiles_dir.exists():
            print(f"  {C.GRAY}No profiles saved yet.{C.RESET}")
            return
        for p in sorted(profiles_dir.glob("*.json")):
            name = p.stem
            size = p.stat().st_size
            print(f"  {C.CYAN}{name}{C.RESET} ({size} bytes)")

    else:
        print("  Usage: entroly profile {save|load|list} [name]")
        return 1


def cmd_batch(args):
    """entroly batch — headless/CI mode for batch optimization (Gap #33)."""
    if not args.json_output:
        print(f"\n{C.CYAN}{C.BOLD}  Entroly Batch Mode{C.RESET}\n")

    from entroly.auto_index import auto_index
    from entroly.server import EntrolyEngine

    engine = EntrolyEngine()
    result = auto_index(engine)

    if result["status"] == "indexed" and not args.json_output:
        print(f"  {C.GREEN}Indexed {result['files_indexed']} files{C.RESET}")
    elif result["status"] == "skipped" and not args.json_output:
        print(f"  {C.GRAY}Using persistent index ({result.get('existing_fragments', 0)} fragments){C.RESET}")

    # Read queries from stdin or file
    import sys as _sys
    if args.input and args.input != "-":
        try:
            with open(args.input) as f:
                queries = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"  {C.RED}File not found: {args.input}{C.RESET}")
            return
        except OSError as e:
            print(f"  {C.RED}Cannot read file: {e}{C.RESET}")
            return
    else:
        queries = [line.strip() for line in _sys.stdin if line.strip()]

    results = []
    for i, query in enumerate(queries, 1):
        engine.advance_turn()
        opt = engine.optimize_context(
            token_budget=args.budget,
            query=query,
        )
        selected = opt.get("selected_fragments", [])
        total_tokens = sum(f.get("token_count", 0) for f in selected)
        results.append({
            "query": query,
            "fragments_selected": len(selected),
            "tokens_used": total_tokens,
            "budget": args.budget,
        })
        if not args.json_output:
            print(f"  [{i}/{len(queries)}] {query[:60]}... -> {len(selected)} fragments, {total_tokens} tokens")

    if args.json_output:
        print(json.dumps(results, indent=2))
    else:
        print(f"\n  {C.GREEN}{C.BOLD}Processed {len(queries)} queries.{C.RESET}\n")

    # CI gate: non-zero exit if any query exceeded the budget
    if getattr(args, "fail_over_budget", False):
        over_budget = [r for r in results if r["tokens_used"] > r["budget"]]
        if over_budget:
            if not args.json_output:
                print(
                    f"  {C.RED}{C.BOLD}✗ {len(over_budget)} of {len(results)} queries "
                    f"exceeded the {args.budget}-token budget.{C.RESET}",
                )
                for r in over_budget[:5]:
                    pct = (r["tokens_used"] / max(r["budget"], 1) - 1) * 100
                    print(
                        f"    {C.RED}- {r['query'][:60]}: "
                        f"{r['tokens_used']:,} tokens (+{pct:.0f}%){C.RESET}",
                    )
            sys.exit(1)


# ── Wrap: One-command agent launcher ─────────────────────────────────


def _check_codebase() -> bool:
    """Check if we're in a directory that looks like a codebase.

    Returns True if codebase detected, False with warning if not.
    """
    cwd = os.getcwd()
    indicators = [
        "pyproject.toml", "setup.py", "requirements.txt", "Pipfile",
        "Cargo.toml", "package.json", "go.mod", "pom.xml", "build.gradle",
        "Gemfile", "tsconfig.json", ".git", "Makefile", "CMakeLists.txt",
    ]
    for f in indicators:
        if os.path.exists(os.path.join(cwd, f)):
            return True

    # Count source files as fallback
    source_exts = {".py", ".js", ".ts", ".rs", ".go", ".java", ".rb", ".c", ".cpp", ".cs"}
    source_count = 0
    for entry in os.listdir(cwd):
        if os.path.isfile(os.path.join(cwd, entry)):
            _, ext = os.path.splitext(entry)
            if ext in source_exts:
                source_count += 1
                if source_count >= 3:
                    return True

    print(f"""
  {C.YELLOW}{C.BOLD}No codebase detected in: {cwd}{C.RESET}

  {C.GRAY}Entroly works best when run from your project directory.
  Navigate to your codebase first:{C.RESET}

    {C.CYAN}cd /path/to/your/project{C.RESET}
    {C.CYAN}entroly go{C.RESET}

  {C.GRAY}Supported: Python, JS/TS, Rust, Go, Java, Ruby, C/C++, and more.{C.RESET}
""")
    return False


# Agent registry. Three integration kinds:
#
#   "cli"  — set env var, exec the binary (zero friction; works today).
#   "mcp"  — write/merge an MCP server entry into the tool's mcp.json
#            (zero friction; user just restarts the IDE).
#   "print"— print a best-effort endpoint/config hint. Used when the schema
#            varies by version or the config lives somewhere we shouldn't
#            auto-mutate.
#
# Path tokens: {cwd} {home} {appdata} {port} are substituted at use time.
_WRAP_AGENTS = {

    # ══════════════════════════════════════════════════════════════════
    # CLI agents (kind=cli) — env-based launch
    # ══════════════════════════════════════════════════════════════════
    "claude": {
        "kind": "cli", "name": "Claude Code",
        "cmd": ["claude"],
        "env_key": "ANTHROPIC_BASE_URL",
        "env_val": "http://localhost:{port}",
        # Proxy mode forwards the client's auth to the PUBLIC API. A pay-as-you-go
        # ANTHROPIC_API_KEY works; a Claude Pro/Max subscription sends a first-party
        # OAuth bearer the public API rejects (upstream 429/401). Detect the missing
        # key up front and route to MCP, which works on subscriptions.
        "api_key_env": "ANTHROPIC_API_KEY",
        "subscription_alt": "claude mcp add entroly -- entroly",
    },
    "codex": {
        "kind": "cli", "name": "OpenAI Codex CLI",
        "cmd": ["codex"],
        "env_key": "OPENAI_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
        "api_key_env": "OPENAI_API_KEY",
    },
    "aider": {
        "kind": "cli", "name": "Aider",
        "cmd": ["aider"],
        "env_key": "OPENAI_API_BASE",
        "env_val": "http://localhost:{port}/v1",
        "api_key_env": "OPENAI_API_KEY",
    },
    "goose": {
        "kind": "cli", "name": "Goose",
        "cmd": ["goose"],
        "env_key": "OPENAI_HOST",
        "env_val": "http://localhost:{port}",
        "extra_env": {"OPENAI_BASE_PATH": "v1/chat/completions"},
        "api_key_env": "OPENAI_API_KEY",
    },
    "openhands": {
        "kind": "cli", "name": "OpenHands CLI",
        "cmd": ["openhands", "--override-with-envs"],
        "env_key": "LLM_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
        "api_key_env": "LLM_API_KEY",
    },
    "copilot": {
        "kind": "cli", "name": "GitHub Copilot CLI (BYOK custom provider)",
        "cmd": ["copilot"],
        "env_key": "COPILOT_PROVIDER_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
        "extra_env": {"COPILOT_PROVIDER_TYPE": "openai"},
        "subscription_alt": "entroly attach create --client copilot --project . --ttl 4h --install",
    },
    "gemini": {
        "kind": "cli", "name": "Gemini CLI",
        "cmd": ["gemini"],
        "env_key": "GOOGLE_GEMINI_BASE_URL",
        "env_val": "http://localhost:{port}/v1beta",
        "api_key_env": "GEMINI_API_KEY",
    },
    "qwen": {
        "kind": "cli", "name": "Qwen Code",
        "cmd": ["qwen"],
        "env_key": "OPENAI_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
    },
    "opencode": {
        "kind": "cli", "name": "OpenCode",
        "cmd": ["opencode"],
        "env_key": "OPENAI_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
    },
    "crush": {
        "kind": "cli", "name": "Charm CRUSH",
        "cmd": ["crush"],
        "env_key": "OPENAI_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
    },
    "hermes": {
        "kind": "cli", "name": "Hermes",
        "cmd": ["hermes"],
        "env_key": "OPENAI_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
    },
    "pi": {
        "kind": "cli", "name": "Pi Coding Agent",
        "cmd": ["pi"],
        "env_key": "OPENAI_BASE_URL",
        "env_val": "http://localhost:{port}/v1",
    },
    "ollama": {
        "kind": "cli", "name": "Ollama (via OpenAI-compat client)",
        "cmd": ["ollama"],
        "env_key": "OLLAMA_HOST",
        "env_val": "http://localhost:{port}",
    },

    # ══════════════════════════════════════════════════════════════════
    # IDE agents with MCP support (kind=mcp) — auto-merge mcp.json
    # ══════════════════════════════════════════════════════════════════
    "cursor": {
        "kind": "mcp", "name": "Cursor",
        "config_path": "{cwd}/.cursor/mcp.json",
        "post_hint": "Restart Cursor to pick up the MCP server. Or open Settings → Models → Override OpenAI Base URL → http://localhost:{port}/v1 for proxy mode.",
    },
    "windsurf": {
        "kind": "mcp", "name": "Windsurf",
        "config_path": "{cwd}/.windsurf/mcp.json",
        "post_hint": "Restart Windsurf. Cascade will auto-discover the entroly tools.",
    },
    "vscode": {
        "kind": "mcp", "name": "VS Code MCP clients",
        "config_path": "{cwd}/.vscode/mcp.json",
        "post_hint": "Reload VS Code. MCP-compatible clients will pick this up.",
    },
    "claude-desktop": {
        "kind": "mcp", "name": "Claude Desktop",
        "config_path_macos": "{home}/Library/Application Support/Claude/claude_desktop_config.json",
        "config_path_windows": "{appdata}/Claude/claude_desktop_config.json",
        "config_path_linux": "{home}/.config/claude/claude_desktop_config.json",
        "post_hint": "Quit and relaunch Claude Desktop.",
    },
    "claude-code": {
        "kind": "mcp", "name": "Claude Code (MCP mode)",
        "config_path": "{cwd}/.mcp.json",
        "post_hint": "Restart Claude Code or run `/mcp` to verify the Entroly server. Use `entroly wrap claude` for proxy-mode wrapping instead.",
    },
    "zed": {
        "kind": "mcp", "name": "Zed",
        "config_path_macos": "{home}/.config/zed/settings.json",
        "config_path_windows": "{appdata}/Zed/settings.json",
        "config_path_linux": "{home}/.config/zed/settings.json",
        "config_key": "context_servers",
        "post_hint": "Restart Zed. Configure Assistant to use entroly tools.",
    },

    # ══════════════════════════════════════════════════════════════════
    # IDEs / extensions (kind=print) — copy-paste snippets
    # We don't auto-write because schemas drift across versions or live in
    # OS-specific paths we shouldn't blindly mutate.
    # ══════════════════════════════════════════════════════════════════
    "grok": {
        "kind": "print", "name": "Grok CLI",
        "config_label": "~/.grok/config.toml",
        "key_path": "[model.entroly] custom model",
        "url": "http://localhost:{port}/v1",
        "snippet_toml": "[model.entroly]\nmodel = \"grok-4.5\"\nbase_url = \"http://localhost:{port}/v1\"\nname = \"Grok via Entroly\"\nenv_key = \"XAI_API_KEY\"\napi_backend = \"chat_completions\"",
        "post_hint": "Start Entroly with ENTROLY_OPENAI_BASE set to the intended xAI/OpenAI-compatible upstream. Default signed-in Grok inference is not intercepted by this custom-model route.",
    },
    "vibe": {
        "kind": "print", "name": "Mistral Vibe",
        "config_label": "./.vibe/config.toml or ~/.vibe/config.toml",
        "key_path": "[[providers]] and [[models]]",
        "url": "http://localhost:{port}/v1",
        "snippet_toml": "active_model = \"entroly-model\"\n\n[[providers]]\nname = \"entroly\"\napi_base = \"http://localhost:{port}/v1\"\napi_key_env_var = \"OPENAI_API_KEY\"\napi_style = \"openai\"\nbackend = \"generic\"\n\n[[models]]\nname = \"gpt-4o\"\nprovider = \"entroly\"\nalias = \"entroly-model\"",
    },
    "omp": {
        "kind": "print", "name": "Oh My Pi",
        "config_label": "~/.omp/agent/models.yml",
        "key_path": "providers.entroly",
        "url": "http://localhost:{port}/v1",
        "snippet_yaml": "providers:\n  entroly:\n    baseUrl: http://localhost:{port}/v1\n    api: openai-completions\n    apiKey: OPENAI_API_KEY\n    models:\n      - id: gpt-4o\n        name: GPT-4o via Entroly\n        contextWindow: 128000\n        maxTokens: 16384",
        "post_hint": "Choose the model/provider that matches the upstream configured behind Entroly. Do not assume an existing OAuth credential is valid for a custom proxy.",
    },
    "zcode": {
        "kind": "print", "name": "ZCode",
        "config_label": "ZCode provider settings",
        "key_path": "Custom OpenAI-compatible Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "cline": {
        "kind": "print", "name": "Cline (VS Code extension)",
        "config_label": "VS Code Settings → Extensions → Cline",
        "key_path": "API Provider: OpenAI Compatible · Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "roo": {
        "kind": "print", "name": "Roo Code (VS Code extension)",
        "config_label": "Roo → Provider → OpenAI Compatible",
        "key_path": "Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "continue": {
        "kind": "print", "name": "Continue (VS Code / JetBrains extension)",
        "config_label": "~/.continue/config.json",
        "key_path": ".models[].apiBase",
        "url": "http://localhost:{port}/v1",
        "snippet_json": '{\n  "models": [{ "title": "Entroly", "provider": "openai", "model": "gpt-4o", "apiBase": "http://localhost:{port}/v1" }]\n}',
    },
    "cody": {
        "kind": "print", "name": "Sourcegraph Cody",
        "config_label": "Cody Settings → Custom Endpoint",
        "key_path": "Endpoint URL",
        "url": "http://localhost:{port}/v1",
    },
    "amp": {
        "kind": "print", "name": "Sourcegraph Amp",
        "config_label": "Amp Settings → Custom OpenAI Endpoint",
        "key_path": "Endpoint URL",
        "url": "http://localhost:{port}/v1",
    },
    "kiro": {
        "kind": "print", "name": "Kiro",
        "config_label": "Settings → AI",
        "key_path": "Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "qoder": {
        "kind": "print", "name": "Qoder",
        "config_label": "Settings → Model Provider",
        "key_path": "Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "trae": {
        "kind": "print", "name": "Trae",
        "config_label": "Settings → AI Provider",
        "key_path": "Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "antigravity": {
        "kind": "print", "name": "Antigravity",
        "config_label": "Settings → AI",
        "key_path": "API Endpoint",
        "url": "http://localhost:{port}/v1",
    },
    "amazonq": {
        "kind": "print", "name": "Amazon Q Developer",
        "config_label": "Q Developer Settings",
        "key_path": "Custom Endpoint",
        "url": "http://localhost:{port}/v1",
    },
    "verdent": {
        "kind": "print", "name": "Verdent",
        "config_label": "Settings → Model",
        "key_path": "Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "jetbrains": {
        "kind": "print", "name": "JetBrains AI Assistant (PyCharm/IntelliJ/WebStorm/GoLand/Rider/RubyMine/PhpStorm/CLion)",
        "config_label": "Settings → Tools → AI Assistant → Models → Custom",
        "key_path": "Server URL",
        "url": "http://localhost:{port}/v1",
    },
    "neovim": {
        "kind": "print", "name": "Neovim (avante.nvim / codecompanion.nvim / gp.nvim)",
        "config_label": "plugin spec",
        "key_path": "openai.endpoint  /  anthropic.endpoint",
        "url": "http://localhost:{port}/v1",
        "snippet_lua": 'require("avante").setup({ provider = "openai", openai = { endpoint = "http://localhost:{port}/v1" } })',
    },
    "emacs": {
        "kind": "print", "name": "Emacs (gptel / aider.el / chatgpt-shell)",
        "config_label": "init.el",
        "key_path": "(setq gptel-api-host ...)",
        "url": "http://localhost:{port}/v1",
        "snippet_elisp": '(setq gptel-api-host "localhost:{port}")\n(setq gptel-stream t)',
    },
    "sublime": {
        "kind": "print", "name": "Sublime Text (Codemp / OpenAI plugin)",
        "config_label": "Preferences → Package Settings → OpenAI → Settings",
        "key_path": '"api_base"',
        "url": "http://localhost:{port}/v1",
    },
    "helix": {
        "kind": "print", "name": "Helix (helix-gpt / helix-ai)",
        "config_label": "languages.toml",
        "key_path": "[[language]] → ai-server",
        "url": "http://localhost:{port}/v1",
    },
    "tabby": {
        "kind": "print", "name": "Tabby",
        "config_label": "~/.tabby/config.toml",
        "key_path": "[model.completion.http]",
        "url": "http://localhost:{port}/v1",
    },
    "twinny": {
        "kind": "print", "name": "Twinny (VS Code)",
        "config_label": "Twinny Settings → Provider",
        "key_path": "API Hostname / Path",
        "url": "http://localhost:{port}/v1",
    },
    "fittencode": {
        "kind": "print", "name": "Fitten Code",
        "config_label": "Settings → Server",
        "key_path": "Base URL",
        "url": "http://localhost:{port}/v1",
    },
    "tabnine": {
        "kind": "print", "name": "Tabnine Enterprise",
        "config_label": "Tabnine Settings → Server",
        "key_path": "Self-hosted endpoint",
        "url": "http://localhost:{port}/v1",
    },
    "supermaven": {
        "kind": "print", "name": "Supermaven",
        "config_label": "Supermaven Settings",
        "key_path": "Custom endpoint",
        "url": "http://localhost:{port}/v1",
    },
}


def _wrap_agent_names() -> str:
    """Human-readable supported-agent list for argparse help."""
    return ", ".join(sorted(_WRAP_AGENTS))


def _resolve_agent_config_path(spec: dict) -> str | None:
    """Pick the right config_path for the host OS.

    Supports either a single `config_path` (cross-platform with token substitution)
    or per-OS `config_path_macos` / `config_path_windows` / `config_path_linux`.
    Tokens substituted: {cwd}, {home}, {appdata}.
    """
    sys_name = platform.system()
    if "config_path" in spec:
        path = spec["config_path"]
    elif sys_name == "Darwin" and "config_path_macos" in spec:
        path = spec["config_path_macos"]
    elif sys_name == "Windows" and "config_path_windows" in spec:
        path = spec["config_path_windows"]
    elif "config_path_linux" in spec:
        path = spec["config_path_linux"]
    else:
        return None

    appdata = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
    return path.format(
        cwd=os.getcwd(),
        home=os.path.expanduser("~"),
        appdata=appdata,
    )


def _wrap_via_mcp(spec: dict, port: int, dry_run: bool = False) -> bool:
    """Auto-merge an entroly MCP server entry into the IDE's mcp.json.

    Returns True on success. The proxy is NOT started — MCP integration uses
    `entroly serve` (stdio), which the IDE spawns itself. With dry_run=True,
    prints the merged config that WOULD be written and makes no changes.
    """
    config_path = _resolve_agent_config_path(spec)
    if not config_path:
        print(f"  {C.RED}No config path defined for {spec['name']} on {platform.system()}.{C.RESET}")
        return False

    tool = {
        "config_path": config_path,
        "config_key": spec.get("config_key", "mcpServers"),
    }

    if dry_run:
        try:
            preview = _write_config(tool, dry_run=True)
        except (OSError, PermissionError, ValueError) as e:
            print(f"  {C.RED}Could not read {config_path}: {e}{C.RESET}")
            return False
        print(f"  {C.YELLOW}[dry-run]{C.RESET} would merge into {config_path}:")
        for ln in preview.splitlines():
            print(f"    {ln}")
        print()
        return True

    try:
        written = _write_config(tool)
    except (OSError, PermissionError, ValueError) as e:
        print(f"  {C.RED}Could not write {config_path}: {e}{C.RESET}")
        return False

    print(f"  {C.GREEN}✓ MCP server registered{C.RESET}")
    print(f"  {C.GRAY}  Wrote: {written}{C.RESET}")
    backup = written + ".entroly-backup"
    if os.path.exists(backup):
        print(f"  {C.GRAY}  Backup: {backup}{C.RESET}")

    hint = spec.get("post_hint", "Restart your IDE to pick up the new MCP server.")
    print(f"\n  {C.BOLD}Next:{C.RESET} {hint.format(port=port)}\n")
    return True


def _wrap_via_print(spec: dict, port: int) -> None:
    """Print a best-effort config hint. Proxy is already running."""
    url = spec.get("url", "http://localhost:{port}/v1").format(port=port)
    label = spec.get("config_label", "your IDE settings")
    key_path = spec.get("key_path", "Base URL")

    print(f"\n  {C.BOLD}{spec['name']} — paste this:{C.RESET}\n")
    print(f"  {C.GRAY}File / location:{C.RESET}  {label}")
    print(f"  {C.GRAY}Field:{C.RESET}           {key_path}")
    print(f"  {C.GRAY}Value:{C.RESET}           {C.CYAN}{url}{C.RESET}")

    # Render any language-specific snippet with {port} substituted.
    # NOTE: Use str.replace, not str.format — snippets contain literal `{` `}`
    # (JSON objects, Lua tables, etc.) that .format() would misinterpret as
    # placeholders, e.g. KeyError on `{ "models": [...] }` in the continue config.
    for snippet_key in ("snippet_json", "snippet_lua", "snippet_elisp", "snippet_yaml", "snippet_toml"):
        snippet = spec.get(snippet_key)
        if snippet:
            lang = snippet_key.replace("snippet_", "")
            print(f"\n  {C.GRAY}Or paste this {lang} block:{C.RESET}")
            print()
            for line in snippet.replace("{port}", str(port)).splitlines():
                print(f"      {line}")

    print(
        f"\n  {C.GRAY}If your installed {spec['name']} supports this custom endpoint, "
        f"requests sent through that endpoint should route through Entroly.{C.RESET}\n"
    )
    post_hint = spec.get("post_hint")
    if post_hint:
        print(f"  {C.YELLOW}Boundary:{C.RESET} {post_hint.format(port=port)}\n")


def _resolved_wrap_env(spec: dict, port: int) -> dict[str, str]:
    """Resolve the complete explicit environment contract for a CLI wrapper."""
    values = {spec["env_key"]: spec["env_val"].format(port=port)}
    for key, value in spec.get("extra_env", {}).items():
        values[str(key)] = str(value).format(port=port)
    return values


def _split_wrap_agent_args(
    agent_args: list[str] | None,
) -> tuple[list[str], list[str], bool]:
    """Split Entroly options from client arguments at the first ``--``.

    ``argparse.REMAINDER`` can return Entroly options followed by the separator,
    for example ``["--port", "9377", "--", "-p", "hello"]``. Entroly may
    recover known wrapper options only from the left side. The separator itself
    is consumed, and the right side is forwarded byte-for-byte as argv tokens.

    When there is no separator, the same mutable list is returned for wrapper
    parsing and client launch so recovered Entroly flags are removed before the
    remaining tokens are forwarded.
    """
    values = list(agent_args or ())
    if "--" in values:
        index = values.index("--")
        return values[:index], values[index + 1 :], True
    return values, values, False


def _start_proxy_if_needed(port: int) -> bool:
    """Start the proxy daemon if it isn't already listening on `port`."""
    if _is_entroly_proxy_running(port):
        print(f"  {C.GREEN}Proxy already running at http://localhost:{port}{C.RESET}")
        return True
    if not _free_port(port):
        print(f"  {C.RED}Port {port} is occupied by a non-Entroly service.{C.RESET}")
        print(f"  {C.GRAY}Choose another port with: entroly wrap <agent> --port <other-port>{C.RESET}\n")
        return False

    print(f"  {C.GRAY}Starting proxy on port {port}...{C.RESET}")
    proxy_cmd = [sys.executable, "-m", "entroly.cli", "proxy", "--port", str(port)]
    log_path: Path | None = _ENTROLY_DIR / f"wrap-proxy-{port}.log"
    try:
        _ENTROLY_DIR.mkdir(parents=True, exist_ok=True)
        log_fh = log_path.open("wb")
    except OSError:
        log_fh = subprocess.DEVNULL
        log_path = None

    try:
        if hasattr(log_fh, "write"):
            log_fh.write(f"\n--- entroly wrap proxy start port={port} ---\n".encode("utf-8"))
            log_fh.flush()
        try:
            proc = subprocess.Popen(proxy_cmd, stdout=log_fh, stderr=subprocess.STDOUT)
        except OSError as e:
            print(f"  {C.RED}Could not start proxy process:{C.RESET} {e}")
            if log_path is not None:
                print(f"  {C.GRAY}Proxy log: {log_path}{C.RESET}")
            print(f"  {C.GRAY}Try: entroly proxy --port {port} in another terminal to reproduce interactively.{C.RESET}\n")
            return False
    finally:
        if hasattr(log_fh, "close"):
            log_fh.close()
    import time as _time
    # Poll for up to 30s (150 × 0.2s). The proxy loads a persistent index before
    # uvicorn binds the port — on machines with large indexes this can take 10–15s.
    for _ in range(150):
        _time.sleep(0.2)
        if _is_entroly_proxy_running(port):
            print(f"  {C.GREEN}Proxy running at http://localhost:{port}{C.RESET}")
            return True
        if proc.poll() is not None:
            print(f"  {C.RED}Proxy exited before becoming healthy (exit {proc.returncode}).{C.RESET}")
            if log_path is not None:
                print(f"  {C.GRAY}Proxy log: {log_path}{C.RESET}")
                tail = _tail_text_file(log_path)
                if tail:
                    print(f"\n{tail}\n")
            print(f"  {C.GRAY}Try: entroly proxy --port {port} in another terminal to reproduce interactively.{C.RESET}\n")
            return False
    print(f"  {C.RED}Proxy failed to start on port {port} within 30s.{C.RESET}")
    if log_path is not None:
        print(f"  {C.GRAY}Proxy log: {log_path}{C.RESET}")
        tail = _tail_text_file(log_path)
        if tail:
            print(f"\n{tail}\n")
    _stop_process_best_effort(proc)
    print(f"  {C.GRAY}Try: entroly proxy --port {port} in another terminal to see the error.{C.RESET}\n")
    return False


# ── Preflight + watchdog for CLI wraps (gh#44) ───────────────────────
#
# Some CLIs silently ignore the OPENAI_BASE_URL override we set, so the
# proxy never sees their traffic and the dashboard stays empty — the
# user just sees "nothing is tracked" with no explanation.
#
# Defense in depth, fail-open:
#   • Preflight  — predictive. Inspects the tool's own auth/config and
#                  prints likely causes + exact fixes BEFORE launch.
#                  Never blocks: a wrong heuristic must not break a
#                  working `wrap`. Read-only; never raises.
#   • Watchdog   — empirical ground truth. Snapshots the proxy's request
#                  counter around the session; if the agent exits having
#                  sent the proxy zero requests, prints the remediation.
#                  Catches every cause, including ones not enumerated.
#
# Codex schema verified against openai/codex source (auth.rs AuthDotJson,
# config-reference): auth.json keys are `auth_mode` (canonical),
# `OPENAI_API_KEY`, `tokens`; the config key is `forced_login_method`
# (values chatgpt|api), and `model_provider` defaults to "openai".


def _read_codex_config(codex_home: Path) -> dict:
    """Best-effort parse of ~/.codex/config.toml. Never raises."""
    cfg_path = codex_home / "config.toml"
    if not cfg_path.exists():
        return {}
    try:
        raw = cfg_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}
    # Prefer a real TOML parser (py3.11+ stdlib `tomllib`, or `tomli`).
    for mod_name in ("tomllib", "tomli"):
        try:
            import importlib
            return importlib.import_module(mod_name).loads(raw)
        except ModuleNotFoundError:
            continue
        except Exception:
            return {}  # malformed TOML — treat as unknown, don't crash
    # py3.10 without tomli: scrape only the two top-level scalars we need.
    import re
    out: dict = {}
    for key in ("model_provider", "forced_login_method"):
        m = re.search(rf'^\s*{key}\s*=\s*"([^"]+)"', raw, re.MULTILINE)
        if m:
            out[key] = m.group(1)
    return out


def _codex_preflight(port: int) -> list[str]:
    """Predict why `entroly wrap codex` might not reach the proxy.

    Returns a list of human-readable warning blocks (may be empty).
    Advisory only — the watchdog is the authority on whether traffic
    actually flowed.

    Dominant cause (gh#44): Codex signed in with a ChatGPT account talks
    to chatgpt.com directly and *ignores OPENAI_BASE_URL entirely*, so
    the proxy never sees a request. Secondary cause: a custom
    `model_provider` in config.toml shadowing the built-in `openai`
    provider that the env var targets.
    """
    out: list[str] = []
    codex_home = Path(os.environ.get("CODEX_HOME") or (Path.home() / ".codex"))

    api_key_set = bool(os.environ.get("OPENAI_API_KEY"))
    chatgpt_mode = False
    auth_path = codex_home / "auth.json"
    if auth_path.exists():
        try:
            auth = json.loads(auth_path.read_text(encoding="utf-8", errors="replace"))
            if auth.get("OPENAI_API_KEY"):
                api_key_set = True
            # `auth_mode` is the canonical signal codex itself routes on;
            # fall back to token presence for older codex builds that
            # predate the field.
            mode = str(auth.get("auth_mode") or "").lower()
            if "chatgpt" in mode:
                chatgpt_mode = True
            elif not mode and auth.get("tokens") and not auth.get("OPENAI_API_KEY"):
                chatgpt_mode = True
        except (OSError, ValueError):
            pass

    cfg = _read_codex_config(codex_home)
    if cfg.get("forced_login_method") == "chatgpt":
        chatgpt_mode = True

    if chatgpt_mode and not api_key_set:
        out.append(
            "Codex appears to be signed in with a ChatGPT account. In that\n"
            "    mode Codex talks to chatgpt.com directly and IGNORES\n"
            "    OPENAI_BASE_URL, so the proxy / dashboard will see nothing.\n"
            "    Fix — switch Codex to API-key auth:\n"
            "      1) codex logout\n"
            "      2) set OPENAI_API_KEY=sk-...   (your OpenAI API key)\n"
            "      3) re-run: entroly wrap codex"
        )

    provider = cfg.get("model_provider")
    if provider and provider != "openai":
        out.append(
            f'Codex config.toml sets model_provider = "{provider}".\n'
            '    OPENAI_BASE_URL only redirects the built-in "openai"\n'
            "    provider, so this one bypasses the proxy. Fix one of:\n"
            f"      • point [model_providers.{provider}].base_url at\n"
            f"        http://localhost:{port}/v1 in ~/.codex/config.toml, or\n"
            '      • run: codex --config model_provider="openai"'
        )

    return out


def _copilot_preflight(port: int) -> list[str]:
    """Explain the BYOK boundary without claiming subscription interception."""
    del port
    if os.environ.get("COPILOT_MODEL"):
        return []
    return [
        "Copilot custom-provider mode needs COPILOT_MODEL to identify the model "
        "sent to the configured BYOK provider. Set it before launching, for "
        "example COPILOT_MODEL=gpt-4o. For a signed-in Copilot subscription, "
        "use the scoped MCP attachment instead; Entroly does not claim to "
        "intercept GitHub-hosted subscription inference."
    ]


_PREFLIGHT = {"codex": _codex_preflight, "copilot": _copilot_preflight}


def _proxy_request_count(port: int) -> int | None:
    """Total requests the proxy has handled, or None if unreachable.

    Used as empirical ground truth by the post-launch watchdog: a zero
    delta across a wrapped session means the agent never routed through
    us, regardless of *why*.
    """
    import urllib.request
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/stats", timeout=2
        ) as r:
            return int(json.loads(r.read()).get("requests_total", 0))
    except Exception:
        return None


def _wrap_watchdog_report(agent: str, spec: dict, port: int,
                          before: int | None) -> None:
    """After a wrapped agent exits, tell the user if we saw zero traffic.

    `before` is the request count captured just before launch. If we
    can't measure (proxy stats unreachable), stay silent rather than
    cry wolf.
    """
    after = _proxy_request_count(port)
    if before is None or after is None or after > before:
        return  # traffic flowed (or we can't tell) — nothing to warn about

    print(
        f"\n  {C.RED}⚠ {spec['name']} sent the proxy 0 requests this "
        f"session.{C.RESET}\n"
        f"  {C.GRAY}That means nothing was tracked and the dashboard "
        f"will be empty.{C.RESET}"
    )
    # Re-show the targeted preflight guidance even if it didn't fire
    # pre-launch (state may have differed, or the cause is unenumerated).
    # The agent already ran — a diagnostic must never crash the exit path.
    try:
        hints = _PREFLIGHT.get(agent, lambda _p: [])(port)
    except Exception:
        hints = []
    if hints:
        for h in hints:
            print(f"  {C.YELLOW}→ {h}{C.RESET}")
    else:
        print(
            f"  {C.GRAY}Likely the tool ignored {spec['env_key']}="
            f"{spec['env_val'].format(port=port)} (custom endpoint not\n"
            f"  supported, or auth that pins it to the vendor backend). "
            f"Verify {spec['name']} honors that variable.{C.RESET}"
        )


def cmd_wrap(args):
    """entroly wrap <agent> — integrate Entroly with an AI coding tool.

    Three integration paths, picked automatically per agent:
      • CLI agents (claude, codex, aider, …)  — start proxy, set env, exec.
      • IDEs with MCP support (cursor, …)      — auto-merge mcp.json.
      • Other IDEs (zed, neovim, …)            — print copy-paste snippet.

    Run `entroly wrap` with no agent to see the full list.
    """
    if not getattr(args, "agent", None):
        by_kind: dict = {"cli": [], "mcp": [], "print": []}
        for k, s in _WRAP_AGENTS.items():
            by_kind.setdefault(s.get("kind", "print"), []).append(k)
        print(f"\n{C.CYAN}{C.BOLD}  Entroly Wrap — supported tools{C.RESET}\n")
        print(f"  {C.GRAY}CLI (env-wrap):{C.RESET}  {', '.join(sorted(by_kind['cli']))}")
        print(f"  {C.GRAY}MCP (auto):{C.RESET}      {', '.join(sorted(by_kind['mcp']))}")
        print(f"  {C.GRAY}Other:{C.RESET}           {', '.join(sorted(by_kind['print']))}\n")
        return

    agent = args.agent.lower()
    if agent not in _WRAP_AGENTS:
        print(f"\n  {C.RED}Unknown agent: {agent}{C.RESET}")
        # Group supported agents by kind for readability
        by_kind: dict = {"cli": [], "mcp": [], "print": []}
        for k, s in _WRAP_AGENTS.items():
            by_kind.setdefault(s.get("kind", "print"), []).append(k)
        print(f"\n  {C.BOLD}Supported agents:{C.RESET}")
        print(f"  {C.GRAY}CLI (env-wrap):{C.RESET}  {', '.join(sorted(by_kind['cli']))}")
        print(f"  {C.GRAY}MCP (auto):{C.RESET}      {', '.join(sorted(by_kind['mcp']))}")
        print(f"  {C.GRAY}Other:{C.RESET}           {', '.join(sorted(by_kind['print']))}\n")
        return

    spec = _WRAP_AGENTS[agent]
    kind = spec.get("kind", "cli")

    # MCP-mode integrations don't need a project codebase nor the proxy —
    # they only patch a config file. Skip the codebase check for them.
    if kind != "mcp" and not _check_codebase():
        if not getattr(args, 'force', False):
            return

    wrapper_args, agent_args, explicit_separator = _split_wrap_agent_args(
        args.agent_args
    )

    port = args.port
    # argparse.REMAINDER may swallow Entroly's own --port after the agent name.
    # Only the left side of an explicit separator belongs to Entroly.
    if port is None and "--port" in wrapper_args:
        idx = wrapper_args.index("--port")
        if idx + 1 < len(wrapper_args):
            try:
                port = int(wrapper_args[idx + 1])
                wrapper_args.pop(idx)
                wrapper_args.pop(idx)
            except ValueError:
                pass
    port = port or 9377

    # Recover Entroly's --dry-run only from the wrapper side of the separator.
    dry_run = bool(getattr(args, "dry_run", False))
    if "--dry-run" in wrapper_args:
        dry_run = True
        wrapper_args.remove("--dry-run")

    suffix = f"  {C.YELLOW}[dry-run]{C.RESET}" if dry_run else ""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Wrap — {spec['name']}{C.RESET}{suffix}\n")

    # ── kind=mcp ───────────────────────────────────────────────────────
    if kind == "mcp":
        return 0 if _wrap_via_mcp(spec, port, dry_run=dry_run) else 1

    # ── kind=print ─────────────────────────────────────────────────────
    if kind == "print":
        if dry_run:
            print(f"  {C.GRAY}[dry-run] would start the proxy on :{port} and print "
                  f"{spec['name']} setup instructions. No changes made.{C.RESET}\n")
            return 0
        if not _start_proxy_if_needed(port):
            return 1
        _wrap_via_print(spec, port)
        return 0

    # ── kind=cli (default) ─────────────────────────────────────────────
    # Proxy mode forwards the client's auth header to the provider's PUBLIC API.
    # If the provider API key isn't in the environment, the user is almost
    # certainly on a subscription login (e.g. Claude Pro/Max OAuth) — proxying
    # that forwards a first-party bearer to the public API and returns a confusing
    # upstream 429/401. Route them to a path that actually works rather than
    # launching a doomed session. `--force` overrides for advanced setups.
    # --force can be swallowed into agent_args by argparse.REMAINDER (like --port
    # / --dry-run above); recover it so the escape hatch works and it isn't passed
    # on to the wrapped agent.
    force_flag = bool(getattr(args, "force", False))
    if "--force" in wrapper_args:
        force_flag = True
        wrapper_args.remove("--force")
    key_env = spec.get("api_key_env")
    if key_env and not os.environ.get(key_env) and not force_flag:
        print(f"  {C.GRAY}No {key_env} set — this proxy path has no explicit provider credential.{C.RESET}\n")
        alt = spec.get("subscription_alt")
        if alt:
            print(f"  {C.BOLD}Best setup for a signed-in or subscription session — the MCP integration:{C.RESET}")
            print(f"    {C.CYAN}{alt}{C.RESET}")
            print(f"  {C.GRAY}(Your agent stays the client; Entroly adds scoped context tools.){C.RESET}\n")
        print(f"  {C.BOLD}See your savings right now — no API call needed:{C.RESET}")
        print(f"    {C.CYAN}entroly simulate{C.RESET}\n")
        print(f"  {C.GRAY}Prefer proxy mode? Set a pay-as-you-go key: "
              f"`export {key_env}=...`, then re-run.{C.RESET}\n")
        if dry_run:
            return 0
        return 1

    if dry_run:
        resolved_env = _resolved_wrap_env(spec, port)
        env_text = ", ".join(f"{key}={value}" for key, value in resolved_env.items())
        launch = " ".join(spec["cmd"] + agent_args)
        print(f"  {C.GRAY}[dry-run] would start the proxy on :{port}, set "
              f"{env_text}, and launch "
              f"`{launch}`. No changes made.{C.RESET}\n")
        return 0
    if not _start_proxy_if_needed(port):
        return 1

    env = os.environ.copy()
    resolved_env = _resolved_wrap_env(spec, port)
    env.update(resolved_env)
    for key, value in resolved_env.items():
        print(f"  {C.GRAY}Set {key}={value}{C.RESET}")
    print(
        f"  {C.YELLOW}Use only if {spec['name']} supports custom endpoints and your account/provider terms permit proxying.{C.RESET}"
    )

    # Preflight (gh#44): advisory only — predict likely silent-bypass
    # causes and print the fix. Never blocks: a wrong heuristic must not
    # break an otherwise-working wrap. The watchdog below is the
    # authority on whether traffic actually flowed.
    preflight = _PREFLIGHT.get(agent)
    if preflight:
        try:
            hints = preflight(port)
        except Exception:
            hints = []  # diagnostics must never disrupt a working setup
        for h in hints:
            print(f"\n  {C.YELLOW}! Heads-up: {h}{C.RESET}")

    print(f"  {C.GREEN}Launching {spec['name']}...{C.RESET}\n")

    # Auto-open dashboard
    try:
        import webbrowser
        webbrowser.open("http://localhost:9378")
    except Exception:
        pass

    # Ground-truth baseline for the post-session watchdog.
    req_before = _proxy_request_count(port)

    try:
        import shutil
        agent_cmd = spec["cmd"] + agent_args
        # On Windows, npm installs .cmd files which subprocess doesn't automatically resolve
        executable = shutil.which(agent_cmd[0])
        if executable is None:
            raise FileNotFoundError()

        agent_cmd[0] = executable
        # Never retry through ``shell=True``.  ``agent_args`` are supplied by
        # the caller, and cmd.exe metacharacters are not made safe by
        # ``subprocess.list2cmdline``.  If a Windows .cmd/.ps1 shim cannot be
        # executed directly, the outer OSError handler prints the exact manual
        # launch instructions instead of trading convenience for command
        # injection risk.
        subprocess.run(agent_cmd, env=env, check=False)
    except FileNotFoundError:
        print(f"\n  {C.RED}{spec['name']} not found.{C.RESET}")
        print(f"  {C.GRAY}Install it first, then run: entroly wrap {agent}{C.RESET}\n")
        return 1
    except KeyboardInterrupt:
        print(f"\n  {C.GRAY}{spec['name']} stopped.{C.RESET}")
    except OSError as e:
        # Direct launch failed (permissions, unsupported Windows shim, etc.).
        # The proxy is already running, so guide the user to finish manually
        # instead of crashing with a raw [WinError 5].
        print(f"\n  {C.RED}Could not launch {spec['name']}:{C.RESET} {e}")
        print(
            f"  {C.GRAY}The proxy is running on :{port}. Launch {spec['name']} "
            f"manually with {spec['env_key']}={spec['env_val'].format(port=port)}{C.RESET}\n"
        )
        return 1

    # Empirical check: did the agent actually route through the proxy?
    _wrap_watchdog_report(agent, spec, port, req_before)



def cmd_unwrap(args):
    """entroly unwrap <agent> — reverse persistent Entroly integration safely."""
    agent = getattr(args, "agent", None)
    if not agent:
        persistent = sorted(
            name for name, spec in _WRAP_AGENTS.items() if spec.get("kind") == "mcp"
        )
        print(f"\n{C.CYAN}{C.BOLD}  Entroly Unwrap — persistent integrations{C.RESET}\n")
        print(f"  {C.GRAY}{', '.join(persistent)}{C.RESET}\n")
        return 0

    agent = agent.lower()
    spec = _WRAP_AGENTS.get(agent)
    if spec is None:
        print(f"\n  {C.RED}Unknown agent: {agent}{C.RESET}\n")
        return 1

    kind = spec.get("kind", "cli")
    if kind != "mcp":
        print(f"\n  {C.GREEN}No persistent Entroly config to remove for {spec['name']}.{C.RESET}")
        if kind == "cli":
            print(f"  {C.GRAY}CLI wrapping uses process-scoped environment variables only.{C.RESET}\n")
        else:
            print(f"  {C.GRAY}This integration only printed setup instructions; it wrote no files.{C.RESET}\n")
        return 0

    config_path = _resolve_agent_config_path(spec)
    if not config_path:
        print(f"  {C.RED}No config path defined for {spec['name']} on {platform.system()}.{C.RESET}")
        return 1
    tool = {
        "config_path": config_path,
        "config_key": spec.get("config_key", "mcpServers"),
    }
    dry_run = bool(getattr(args, "dry_run", False))
    try:
        status, backup = _remove_entroly_config(tool, dry_run=dry_run)
    except (OSError, PermissionError, ValueError) as exc:
        print(f"  {C.RED}Could not update {config_path}: {exc}{C.RESET}")
        return 1

    if dry_run and status not in {"missing", "absent", "removed"}:
        print(f"  {C.YELLOW}[dry-run]{C.RESET} would write {config_path}:")
        for line in status.splitlines():
            print(f"    {line}")
        print()
        return 0
    if status == "missing":
        print(f"  {C.GRAY}No config file exists at {config_path}; nothing to remove.{C.RESET}\n")
        return 0
    if status == "absent":
        print(f"  {C.GRAY}Entroly is not registered in {config_path}.{C.RESET}\n")
        return 0

    print(f"  {C.GREEN}✓ Entroly MCP entry removed{C.RESET}")
    print(f"  {C.GRAY}  Wrote: {config_path}{C.RESET}")
    if backup:
        print(f"  {C.GRAY}  Backup: {backup}{C.RESET}")
    print()
    return 0


# ── Learn: Failure pattern analysis ──────────────────────────────────


def cmd_learn(args):
    """entroly learn — analyze session for failure patterns."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Learn — Failure Pattern Analysis{C.RESET}\n")

    import urllib.request
    port = args.port or 9377

    try:
        resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/stats", timeout=2)
        stats = json.loads(resp.read())
        feedback = stats.get("implicit_feedback", {})
    except Exception:
        feedback = {}

    if not feedback:
        print(f"  {C.YELLOW}No feedback data available.{C.RESET}")
        print(f"  {C.GRAY}Run the proxy and make some requests first.{C.RESET}\n")
        return

    confusion = feedback.get("confusion_detections", 0)
    confidence = feedback.get("confidence_detections", 0)
    rephrases = feedback.get("rephrase_detections", 0)
    total = feedback.get("total_assessed", 0)
    trend = feedback.get("quality_trend", "stable")

    print(f"  {C.BOLD}Session Analysis:{C.RESET}")
    print(f"    Total assessed:     {total}")
    print(f"    Confident:          {C.GREEN}{confidence}{C.RESET}")
    print(f"    Confused:           {C.RED if confusion > 0 else C.GRAY}{confusion}{C.RESET}")
    print(f"    Rephrases (retries):{C.YELLOW if rephrases > 0 else C.GRAY} {rephrases}{C.RESET}")
    print(f"    Quality trend:      {C.GREEN if trend == 'stable' else C.RED}{trend}{C.RESET}")

    if total > 0:
        success_rate = (confidence / total) * 100
        print(f"    Success rate:       {success_rate:.0f}%")

    # Learnings are thresholded observations from this session, not advice.
    # We write the raw counts so the user (or their agent) can decide what to do.
    learnings: list[str] = []
    if total > 5:
        if confusion > total * 0.3:
            learnings.append(
                f"Confusion on {confusion}/{total} requests ({confusion*100//total}%). "
                f"Above the 30% threshold — consider `entroly proxy --quality max` or increasing budget."
            )
        if rephrases > total * 0.2:
            learnings.append(
                f"Rephrases detected on {rephrases}/{total} requests ({rephrases*100//total}%). "
                f"Above the 20% threshold — inspect dropped fragments at /explain."
            )
        if trend == "declining":
            learnings.append(
                f"Quality trend: declining (confident={confidence}/{total})."
            )
    if total <= 5:
        learnings.append(f"Only {total} requests assessed — need >5 for reliable signal.")

    print(f"\n  {C.BOLD}Observations:{C.RESET}")
    for msg in learnings or ["No thresholds crossed."]:
        print(f"    {C.YELLOW}• {msg}{C.RESET}")

    if getattr(args, "apply", False) and learnings and total > 5:
        for fname in ["CLAUDE.md", "AGENTS.md"]:
            fpath = Path.cwd() / fname
            if fpath.exists():
                existing = fpath.read_text(encoding="utf-8", errors="replace")
                if "## Entroly Learnings" not in existing:
                    import time as _time
                    stamp = _time.strftime("%Y-%m-%d")
                    section = f"\n\n## Entroly Learnings ({stamp}, n={total})\n\n"
                    section += "\n".join(f"- {msg}" for msg in learnings) + "\n"
                    fpath.write_text(existing + section, encoding="utf-8")
                    print(f"\n  {C.GREEN}Written learnings to {fname}{C.RESET}")
                else:
                    print(f"\n  {C.GRAY}{fname} already has learnings section — remove the old one to refresh.{C.RESET}")
                break

    print()


def _recommend_quality(project: dict, file_count: int) -> str:
    """Recommend a starting quality preset from project characteristics.

    The heuristic has an information-theoretic basis, not a measured one —
    treat it as a starting point and run `entroly autotune` to calibrate.

    Size thresholds (5000 / 2000 / 500 files) are unvalidated defaults that
    trade pipeline latency for selection fidelity.
    """
    lang = project.get("primary", "unknown")
    langs = project.get("languages", [])

    # Larger codebases blow the latency budget on deeper presets; favor speed.
    if file_count > 5000:
        return "speed"
    if file_count > 2000:
        return "fast"

    # Heterogeneous repos mix semantic distributions (e.g. C infra + TS UI);
    # a single retrieval pass over mixed embeddings benefits from more effort.
    if len(langs) >= 3:
        return "quality"

    # Typed signatures act as compressed semantic metadata: a Rust fn's
    # `-> Result<Session, AuthError>` encodes intent the retriever can use
    # without reading the body. Dynamic languages lack that, so retrieval
    # precision at a fixed budget improves more from deeper analysis.
    if lang in ("rust", "go", "java"):
        return "balanced"
    if lang in ("python", "javascript", "typescript"):
        return "quality" if file_count > 500 else "balanced"

    return "balanced"


def cmd_go(args):
    """entroly go — one command to rule them all: init + proxy + dashboard."""
    print(f"""
{C.CYAN}{C.BOLD}  ⚡ Entroly Go{C.RESET} — full setup in one command
""")

    # Step 0: Codebase check
    if not _check_codebase():
        if not getattr(args, 'force', False):
            return

    # Step 1: Detect project
    project = _detect_project_type()
    langs = ', '.join(project['languages'])
    fw = project.get('frameworks', [])
    fw_str = f" + {', '.join(fw)}" if fw else ""
    print(f"  {C.GRAY}Project:{C.RESET}  {C.BOLD}{project['name']}{C.RESET} ({langs}{fw_str})")

    # Step 2: Auto-detect AI tools and write configs
    tools = _detect_ai_tool()
    if tools["tools"]:
        for tool in tools["tools"]:
            try:
                path = _write_config(tool)
                print(f"  {C.GREEN}Configured{C.RESET} {tool['name']} ({path})")
            except Exception as e:
                print(f"  {C.YELLOW}Skipped{C.RESET} {tool['name']}: {e}")
    else:
        print(f"  {C.GRAY}No AI tool detected -- proxy mode works with any tool{C.RESET}")

    # Step 3: Initialize engine + auto-index
    from entroly.auto_index import auto_index, start_incremental_watcher
    from entroly.proxy import create_proxy_app
    from entroly.proxy_config import ProxyConfig, resolve_quality
    from entroly.server import EntrolyEngine

    engine = EntrolyEngine()
    result = auto_index(engine, force=getattr(args, "force", False))

    file_count = 0
    if result["status"] == "indexed":
        file_count = result["files_indexed"]
        print(f"  {C.GREEN}Indexed {file_count} files ({result['total_tokens']:,} tokens) in {result['duration_s']}s{C.RESET}")
    elif result["status"] == "skipped":
        file_count = result.get("existing_fragments", 0)
        print(f"  {C.GRAY}Using persistent index ({file_count} fragments){C.RESET}")

    # Step 4: Smart quality recommendation
    config = ProxyConfig.from_env()
    recommended = _recommend_quality(project, file_count)
    quality_val = resolve_quality(getattr(args, "quality", None) or recommended)
    config.quality = quality_val
    config._apply_quality_dial(quality_val)
    if args.port:
        config.port = args.port

    print(f"  {C.CYAN}Quality:{C.RESET}  {recommended} (auto-detected for {file_count} files)")

    # Start file watcher
    start_incremental_watcher(engine)

    # Warm up engine
    engine.optimize_context(token_budget=128000, query="project overview")

    # Refuse to interfere with existing services on the proxy or dashboard ports.
    if not _free_port(config.port):
        print(f"  {C.RED}Port {config.port} is already in use.{C.RESET}")
        print(f"  {C.GRAY}Try: entroly go --port <other-port>{C.RESET}")
        return
    if not _free_port(9378):
        print(f"  {C.RED}Dashboard port 9378 is already in use.{C.RESET}")
        print(f"  {C.GRAY}Stop the existing service before starting `entroly go`.{C.RESET}")
        return

    # Start proxy + dashboard
    app = create_proxy_app(engine, config)

    print(f"""
  {C.GREEN}{C.BOLD}Ready!{C.RESET}

  {C.GREEN}Proxy:{C.RESET}      http://localhost:{config.port}/v1
  {C.GREEN}Dashboard:{C.RESET}  http://localhost:9378

  {C.BOLD}Point your AI tool's API base URL to the proxy URL above.{C.RESET}
  {C.GRAY}Every request: intercepted → optimized → forwarded. Live latency on the dashboard.{C.RESET}
  {C.GRAY}Press Ctrl+C to stop.{C.RESET}
""")

    # Auto-open dashboard
    try:
        import webbrowser
        webbrowser.open("http://localhost:9378")
    except Exception:
        pass

    try:
        import uvicorn
        uvicorn.run(app, host=config.host, port=config.port, log_level="warning")
    except ImportError:
        print(f"  {C.RED}uvicorn not installed. Install with: pip install uvicorn{C.RESET}")
    except KeyboardInterrupt:
        print(f"\n  {C.GRAY}Entroly stopped.{C.RESET}")


def cmd_demo(args):
    """Run the bounded no-key demo through the shared simulation path.

    ``demo``, ``simulate``, and ``perf`` must measure the same indexed
    surface. A separate auto-index path previously bypassed the file cap
    and could spend minutes ingesting a large repository before printing.
    """
    report = _run_local_simulation(args)
    if getattr(args, "json", False):
        print(json.dumps(report, indent=2))
        return

    _print_local_simulation(
        report,
        title="Entroly Demo",
        include_perf=False,
    )
    if report["files_indexed"] == 0:
        return

    from entroly.value_tracker import estimate_cost

    per_query_saved = report["total_tokens_saved"] // max(
        len(report["queries"]), 1
    )
    print(
        f"  {C.BOLD}Per-query savings{C.RESET} "
        f"(current input rates, {per_query_saved:,} tokens saved/query):"
    )
    for model in ("gpt-4o", "claude-sonnet-4", "gemini-2.5-pro"):
        cost = estimate_cost(per_query_saved, model)
        print(
            f"    {C.CYAN}{model:25s}{C.RESET} "
            f"${cost:.4f}/query"
        )
    print(
        f"  {C.GRAY}Multiply by your actual request volume. "
        f"We don't know what that is.{C.RESET}"
    )

    recommended = _recommend_quality(
        _detect_project_type(), report["files_indexed"]
    )
    print(f"""
    {C.GREEN}{C.BOLD}Get started:{C.RESET}
      {C.CYAN}entroly go{C.RESET}                One command: init + proxy + dashboard
      {C.CYAN}entroly proxy --quality {recommended}{C.RESET}  Start optimizing
  """)

def _simulation_queries(args) -> list[str]:
    queries = getattr(args, "query", None) or []
    if isinstance(queries, str):
        queries = [queries]
    cleaned = [q.strip() for q in queries if q and q.strip()]
    if cleaned:
        return cleaned
    return [
        "How does the authentication flow work?",
        "Find and fix potential SQL injection vulnerabilities",
        "Explain the module structure and dependency graph",
    ]


def _load_local_simulation_engine(max_files: int | None = None):
    from entroly import auto_index as auto_index_module
    from entroly.server import EntrolyEngine

    old_max_files = auto_index_module.MAX_FILES
    if max_files and max_files > 0:
        auto_index_module.MAX_FILES = max(1, int(max_files))
    engine = EntrolyEngine()
    try:
        index = auto_index_module.auto_index(engine)
        if index["status"] == "indexed":
            return engine, index["files_indexed"], index["total_tokens"], index["status"]
        if index["status"] == "skipped":
            files_indexed = index.get("existing_fragments", 0)
            if getattr(engine, "_use_rust", False):
                stats = engine._rust.stats()
                total_tokens = stats.get("session", {}).get("total_tokens_tracked", 0)
            else:
                total_tokens = getattr(engine, "_total_token_count", 0)
                # Keep user-facing savings arithmetic in the same token unit on
                # cold and warm paths. _total_token_count is a lexical retrieval
                # statistic in the pure-Python engine, not context-budget tokens.
                total_tokens = index.get("total_tokens", total_tokens)
            return engine, files_indexed, int(total_tokens or 0), index["status"]
        return engine, 0, 0, index["status"]
    finally:
        auto_index_module.MAX_FILES = old_max_files


def _run_local_simulation(args) -> dict:
    max_files = int(getattr(args, "max_files", 100) or 0)
    engine, files_indexed, total_tokens, index_status = _load_local_simulation_engine(max_files)
    budget = int(getattr(args, "budget", 4096) or 4096)
    queries = _simulation_queries(args)
    baseline = int(getattr(args, "baseline", 0) or 0)
    explicit_baseline = baseline > 0
    if baseline <= 0:
        baseline = min(total_tokens, 32_000)

    # A project smaller than the budget has nothing to drop, so every query
    # reports "0.0% fewer; 0 tokens saved". That is arithmetically right and
    # tells a first-time user nothing -- it reads as "this tool does nothing",
    # which is the most common first run and the worst possible first
    # impression. Say what actually happened, and still demonstrate selection
    # by squeezing the budget until it binds.
    fits_entirely = (not explicit_baseline) and total_tokens <= budget

    rows = []
    total_saved = 0
    latencies_ms: list[float] = []
    for query in queries:
        engine.advance_turn()
        t0 = time.perf_counter()
        result = engine.optimize_context(token_budget=budget, query=query)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        selected = result.get("selected_fragments", [])
        selected_tokens = sum(int(f.get("token_count", 0) or 0) for f in selected)
        saved = max(0, baseline - selected_tokens) if selected else 0
        total_saved += saved
        latencies_ms.append(elapsed_ms)
        rows.append(
            {
                "query": query,
                "selected_fragments": len(selected),
                "selected_tokens": selected_tokens,
                "baseline_tokens": baseline,
                "tokens_saved": saved,
                "reduction_pct": round(saved * 100 / max(baseline, 1), 2),
                "latency_ms": round(elapsed_ms, 2),
                "top_sources": [
                    str(f.get("source", f.get("id", "?"))) for f in selected[:5]
                ],
            }
        )

    latencies_sorted = sorted(latencies_ms)
    p95_idx = min(len(latencies_sorted) - 1, int(len(latencies_sorted) * 0.95)) if latencies_sorted else 0
    return {
        "mode": "local_no_llm",
        "index_status": index_status,
        "files_indexed": files_indexed,
        "repo_tokens_indexed": total_tokens,
        "budget": budget,
        "budget_narrowed_to_demonstrate": fits_entirely,
        "max_files": max_files,
        "baseline_tokens_per_query": baseline,
        "queries": rows,
        "total_tokens_saved": total_saved,
        "average_reduction_pct": round(
            total_saved * 100 / max(baseline * len(rows), 1), 2
        ),
        "latency_ms": {
            "min": round(min(latencies_ms), 2) if latencies_ms else 0.0,
            "p95": round(latencies_sorted[p95_idx], 2) if latencies_sorted else 0.0,
            "max": round(max(latencies_ms), 2) if latencies_ms else 0.0,
        },
        "limitations": [
            "No LLM call was made; quality is not judged here.",
            "Savings are estimated against the stated local baseline, not your provider bill.",
            "Provider cache discounts, output tokens, and retries are excluded.",
        ],
    }


def _print_local_simulation(report: dict, *, title: str, include_perf: bool) -> None:
    print(f"\n{C.CYAN}{C.BOLD}  {title}{C.RESET} -- local, no LLM calls\n")
    if report["files_indexed"] == 0:
        print(f"  {C.YELLOW}No files found to index. Run this inside a project directory.{C.RESET}\n")
        return
    print(
        f"  {C.GREEN}Indexed {report['files_indexed']} files "
        f"({report['repo_tokens_indexed']:,} estimated tokens){C.RESET}"
    )
    print(
        f"  {C.BOLD}Baseline:{C.RESET} {report['baseline_tokens_per_query']:,} "
        f"tokens/query  {C.BOLD}Budget:{C.RESET} {report['budget']:,} tokens"
    )
    print()
    for row in report["queries"]:
        print(f"    {C.CYAN}Q:{C.RESET} {row['query'][:80]}")
        print(
            f"       {row['selected_fragments']} fragments, "
            f"{row['selected_tokens']:,} tokens "
            f"({row['reduction_pct']:.1f}% fewer; "
            f"{row['tokens_saved']:,} tokens saved)"
        )
        if include_perf:
            print(f"       latency: {row['latency_ms']:.2f} ms")
        top = ", ".join(Path(s).name for s in row["top_sources"][:3]) or "none"
        print(f"       {C.GRAY}top: {top}{C.RESET}\n")

    avg = report["average_reduction_pct"]
    # Gate on "did we actually save nothing", NOT merely on "the repo fits in
    # the budget". A 2,623-token project fits inside a 4,096-token budget and
    # still reduced context 42-98%, because the resolution ladder demotes
    # lower-ranked files to skeletons even when nothing has to be dropped.
    # Gating on fit alone printed "there is nothing to save yet" directly under
    # "1,104 tokens saved".
    nothing_saved = report.get("budget_narrowed_to_demonstrate") and avg <= 0.0
    if nothing_saved:
        # A project smaller than the budget has nothing to drop, so every query
        # honestly reports 0.0%. Printing that bare number is the most common
        # first run and reads as "this tool does nothing". Say what actually
        # happened and where the value appears, rather than manufacturing a
        # demo by squeezing the budget until something gets cut.
        print(
            f"  {C.GREEN}{C.BOLD}Your project already fits in one request.{C.RESET} "
            f"{C.GRAY}({report['repo_tokens_indexed']:,} tokens vs a "
            f"{report['budget']:,}-token budget){C.RESET}"
        )
        print(
            f"  {C.GRAY}Nothing needed dropping, so there is nothing to save yet. "
            f"Entroly starts paying off once a codebase outgrows the context "
            f"window — on a 680k-token repo it cut context 87.6%.{C.RESET}"
        )
        print(
            f"  {C.GRAY}Try it on a larger repo, or force selection here with "
            f"{C.RESET}--budget 30{C.GRAY}.{C.RESET}"
        )
    else:
        print(f"  {C.GREEN}{C.BOLD}Average reduction: {avg:.1f}%{C.RESET}")
    if include_perf:
        lat = report["latency_ms"]
        print(
            f"  {C.BOLD}Local optimize latency:{C.RESET} "
            f"min {lat['min']:.2f} ms, p95 {lat['p95']:.2f} ms, max {lat['max']:.2f} ms"
        )
    print(f"  {C.GRAY}{'; '.join(report['limitations'])}{C.RESET}\n")


# `compress` and `recover` live in their own module: they are the only
# commands that touch the codec recovery contract, and keeping them apart
# keeps that contract reviewable on its own.
from .cli_recover import cmd_compress, cmd_recover  # noqa: E402


def cmd_simulate(args):
    """entroly simulate -- local no-LLM savings estimate for this repo."""
    report = _run_local_simulation(args)
    if getattr(args, "json", False):
        print(json.dumps(report, indent=2))
        return
    _print_local_simulation(report, title="Entroly Simulate", include_perf=False)


def cmd_perf(args):
    """entroly perf -- local no-LLM savings and optimizer latency."""
    report = _run_local_simulation(args)
    if getattr(args, "json", False):
        print(json.dumps(report, indent=2))
        return
    _print_local_simulation(report, title="Entroly Perf", include_perf=True)


def cmd_value(args):
    """entroly value -- show measured value without mixing evidence classes."""
    from entroly.value_tracker import get_tracker

    receipt = get_tracker().get_value_receipt()
    if getattr(args, "json_output", False):
        print(json.dumps(receipt, indent=2, sort_keys=True))
        return

    provider = receipt["provider_path"]
    local = receipt["local_operations"]
    legacy = receipt["legacy_unclassified"]
    trust = receipt["trust_signals"]
    pricing = receipt["pricing"]

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Context Value Receipt{C.RESET}\n")
    print(f"  {C.BOLD}Provider-bound requests{C.RESET}")
    print(
        f"    Observed: {provider['requests_observed']:,}  |  "
        f"Optimized: {provider['requests_optimized']:,}"
    )
    print(
        f"    Input tokens reduced: "
        f"{C.GREEN}{provider['input_tokens_reduced']:,}{C.RESET}"
    )
    print(
        "    Modeled input cost avoided: "
        f"{C.GREEN}${provider['modeled_input_cost_avoided_usd']:.4f}{C.RESET}"
    )
    print(f"    Active days with provider traffic: {provider['active_days']:,}\n")
    if provider["unpriced_requests"]:
        print(
            f"    {C.YELLOW}Unpriced provider traffic: "
            f"{provider['unpriced_requests']:,} requests / "
            f"{provider['unpriced_input_tokens']:,} reduced tokens. "
            f"Add an explicit catalog rate to price them.{C.RESET}\n"
        )

    print(f"  {C.BOLD}Local-only optimization{C.RESET}")
    print(
        f"    Operations: {local['operations']:,}  |  "
        f"Tokens reduced: {local['tokens_reduced']:,}"
    )
    print(
        f"    Dollar savings claimed: {C.GREEN}$0.0000{C.RESET} "
        f"{C.GRAY}(delivery to a paid provider is not observable){C.RESET}\n"
    )

    print(f"  {C.BOLD}Trust and routing signals{C.RESET}")
    print(
        "    Unsupported claims blocked: "
        f"{trust['unsupported_claims_blocked']:,}"
    )
    print(
        f"    RAVS routing decisions: {trust['routing_decisions']:,}  |  "
        "Modeled routing cost avoided: "
        f"${trust['modeled_routing_cost_avoided_usd']:.4f}\n"
    )

    if legacy["operations"] or legacy["tokens_reduced"]:
        print(f"  {C.YELLOW}{C.BOLD}Legacy history kept, not claimed{C.RESET}")
        print(
            f"    {legacy['operations']:,} operations / "
            f"{legacy['tokens_reduced']:,} tokens predate source classification."
        )
        print("    They are excluded from provider savings and dollar claims.\n")

    print(
        f"  {C.GRAY}Pricing: {pricing.get('source', 'bundled')} rates, "
        f"as of {pricing.get('as_of', 'unknown')}. Dollar values are modeled "
        f"from measured token reduction; they are not provider invoices.{C.RESET}"
    )
    if provider["requests_observed"] == 0:
        print(
            f"  {C.YELLOW}No provider-bound request has been measured yet.{C.RESET}"
        )
        print(
            "  Run `entroly simulate` for a no-key local estimate, then use a "
            "supported proxy path to measure provider-bound value."
        )
    print()



def cmd_share(args):
    """entroly share — generate a shareable Context Report Card."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Share{C.RESET} -- generate your Context Report Card\n")

    from entroly.auto_index import auto_index
    from entroly.server import EntrolyEngine
    from entroly.value_tracker import estimate_cost, get_tracker

    engine = EntrolyEngine()
    result = auto_index(engine)

    if result["status"] == "indexed":
        files_indexed = result["files_indexed"]
        total_tokens_raw = result["total_tokens"]
    elif result["status"] == "skipped":
        files_indexed = result.get("existing_fragments", 0)
        if engine._use_rust:
            stats = engine._rust.stats()
            total_tokens_raw = stats.get("session", {}).get("total_tokens_tracked", 0)
        else:
            total_tokens_raw = getattr(engine, "_total_token_count", 0)
    else:
        print(f"  {C.YELLOW}No files found. Run from a project directory.{C.RESET}\n")
        return

    if files_indexed == 0:
        print(f"  {C.YELLOW}No files found. Run from a project directory.{C.RESET}\n")
        return

    print(f"  {C.GREEN}Indexed {files_indexed} files ({total_tokens_raw:,} tokens){C.RESET}")

    # Run sample queries to compute real stats
    sample_queries = [
        "How does the authentication flow work?",
        "Find and fix potential SQL injection vulnerabilities",
        "Explain the module structure and dependency graph",
    ]

    # Honest baseline for *token reduction* (headline only): a 32K "paste matching
    # files until the window fills" dump, capped at what actually exists. Comparing
    # against total_tokens_raw (7M+ for AutoGPT) is marketing, not measurement.
    BUDGET = 4096
    BUDGET_RELAXED = 8192  # 2× for stability measurement
    BASELINE_PER_QUERY = min(total_tokens_raw, 32_000)

    # --- Context Score: geometric mean of three defined quantities per query ---
    # Stability(q) = Jaccard(selection@B, selection@2B). A well-ordered selector
    #                 puts its most important items first; doubling budget adds,
    #                 doesn't replace. Random selection → ~0.
    # Coverage(q)  = fraction of non-stopword query terms present in selected
    #                content. Sanity check: is the selection actually about q?
    # Respect(q)   = 1 iff tokens_used <= B. Budget is a hard contract.
    # ContextScore = 100 * (∏_q Stability·Coverage·Respect)^(1/(3N))
    # No floors, no arbitrary caps. Bad on any axis → low score.
    import re as _re
    _STOPWORDS = {"how","does","do","the","a","an","is","are","what","why","when",
                  "where","and","or","but","to","of","in","on","for","with","by",
                  "it","this","that","these","those","be","will","can","could",
                  "would","should","you","your","i","we","my","our"}
    def _coverage(q: str, frags: list) -> float:
        terms = {w.lower() for w in _re.findall(r"[a-zA-Z_]{3,}", q)
                 if w.lower() not in _STOPWORDS}
        if not terms:
            return 1.0
        blob = " ".join(f.get("content", "") for f in frags).lower()
        return sum(1 for t in terms if t in blob) / len(terms)
    def _ids(frags: list) -> set:
        return {f.get("id") or f.get("source", "") for f in frags}
    def _jaccard(a: set, b: set) -> float:
        if not a and not b:
            return 1.0
        return len(a & b) / max(len(a | b), 1)

    total_saved = 0
    query_results = []
    stabilities: list[float] = []
    coverages: list[float] = []
    respects: list[float] = []

    for query in sample_queries:
        engine.advance_turn()
        opt_b = engine.optimize_context(token_budget=BUDGET, query=query)
        sel_b = opt_b.get("selected_fragments", [])
        engine.advance_turn()
        opt_2b = engine.optimize_context(token_budget=BUDGET_RELAXED, query=query)
        sel_2b = opt_2b.get("selected_fragments", [])

        tokens_used = sum(f.get("token_count", 0) for f in sel_b)
        saved = max(0, BASELINE_PER_QUERY - tokens_used)
        total_saved += saved
        pct = (saved * 100) // max(BASELINE_PER_QUERY, 1)

        stabilities.append(_jaccard(_ids(sel_b), _ids(sel_2b)))
        coverages.append(_coverage(query, sel_b))
        respects.append(1.0 if tokens_used <= BUDGET else 0.0)

        query_results.append({
            "query": query,
            "fragments": len(sel_b),
            "tokens": tokens_used,
            "saved_pct": pct,
        })

    avg_pct = (total_saved * 100) // max(BASELINE_PER_QUERY * len(sample_queries), 1)

    # Geometric mean. A single 0 on any axis zeros the score — by design.
    import math as _math
    factors = stabilities + coverages + respects
    if any(f <= 0 for f in factors):
        context_score = 0
    else:
        log_sum = sum(_math.log(f) for f in factors)
        context_score = int(round(100 * _math.exp(log_sum / len(factors))))
    context_score = max(0, min(100, context_score))

    avg_stability = sum(stabilities) / len(stabilities)
    avg_coverage = sum(coverages) / len(coverages)
    avg_respect = sum(respects) / len(respects)
    # Per-query $ at today's GPT-4o rate — no fake 100-req/day multiplier.
    per_query_savings_usd = estimate_cost(total_saved // len(sample_queries), "gpt-4o")

    # Detect project name
    project_name = Path.cwd().name

    # Pull lifetime stats if available
    tracker = get_tracker()
    lifetime = tracker.get_lifetime()
    lifetime_tokens = lifetime.get("provider_tokens_saved", 0)
    lifetime_cost = lifetime.get("provider_cost_avoided_usd", 0.0)
    lifetime_requests = lifetime.get("provider_requests_optimized", 0)

    # Honest per-query tokens shown instead of "AI sees ALL".
    avg_selected_frags = sum(qr["fragments"] for qr in query_results) // max(len(query_results), 1)
    avg_tokens_used = sum(qr["tokens"] for qr in query_results) // max(len(query_results), 1)

    # Generate HTML report
    html = _generate_report_html(
        project_name=project_name,
        files=files_indexed,
        total_tokens=total_tokens_raw,
        avg_reduction=avg_pct,
        context_score=context_score,
        per_query_savings_usd=per_query_savings_usd,
        avg_stability=avg_stability,
        avg_coverage=avg_coverage,
        avg_respect=avg_respect,
        avg_selected_frags=avg_selected_frags,
        avg_tokens_used=avg_tokens_used,
        query_results=query_results,
        lifetime_tokens=lifetime_tokens,
        lifetime_cost=lifetime_cost,
        lifetime_requests=lifetime_requests,
    )

    out_path = Path(args.output) if hasattr(args, "output") and args.output else Path("entroly-report.html")
    if out_path.parent != Path("."):
        out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")

    print(f"\n  {C.GREEN}{C.BOLD}Context Report Card{C.RESET}")
    print("  ┌─────────────────────────────────────────────────────┐")
    print(f"  │  {C.BOLD}PROJECT:{C.RESET}  {project_name:<42s}│")
    print(f"  │  {C.BOLD}CONTEXT SCORE:{C.RESET}  {C.GREEN}{context_score}/100{C.RESET}  "
          f"{C.GRAY}(stab·cov·respect)^⅓{C.RESET}      │")
    print(f"  │    {C.GRAY}stability {avg_stability:.2f}  coverage {avg_coverage:.2f}  respect {avg_respect:.2f}{C.RESET}   │")
    print(f"  │  {C.BOLD}PER-QUERY:{C.RESET}  ~{avg_selected_frags} frags, {avg_tokens_used:,} tokens (from {files_indexed:,} files)")
    print(f"  │  {C.BOLD}TOKENS vs 32K DUMP:{C.RESET}  {C.GREEN}{avg_pct}%{C.RESET} smaller")
    print(f"  │  {C.BOLD}MODELED / QUERY:{C.RESET}  {C.GREEN}${per_query_savings_usd:.4f}{C.RESET} (32K baseline, GPT-4o rate)   │")
    print("  └─────────────────────────────────────────────────────┘")
    print(f"\n  {C.GREEN}Report saved:{C.RESET} {out_path.resolve()}")
    print(f"\n  {C.CYAN}Share it!{C.RESET} Post your Context Score on Twitter/LinkedIn.")
    print(f"  {C.GRAY}\"My codebase scores {context_score}/100 on Entroly. What's yours?\"{C.RESET}\n")


def _generate_report_html(
    project_name: str,
    files: int,
    total_tokens: int,
    avg_reduction: int,
    context_score: int,
    per_query_savings_usd: float,
    avg_stability: float,
    avg_coverage: float,
    avg_respect: float,
    avg_selected_frags: int,
    avg_tokens_used: int,
    query_results: list,
    lifetime_tokens: int = 0,
    lifetime_cost: float = 0.0,
    lifetime_requests: int = 0,
) -> str:
    """Generate a beautiful, shareable HTML report card."""
    # Build query rows
    query_rows = ""
    for qr in query_results:
        query_rows += f"""
        <div class="qr">
          <div class="qr-query">{qr['query']}</div>
          <div class="qr-stats">
            <span class="qr-frags">{qr['fragments']} fragments</span>
            <span class="qr-tokens">{qr['tokens']:,} tokens</span>
            <span class="qr-saved">{qr['saved_pct']}% saved</span>
          </div>
        </div>"""

    # Score color
    if context_score >= 80:
        score_color = "#34d399"
    elif context_score >= 60:
        score_color = "#fbbf24"
    else:
        score_color = "#f87171"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entroly Context Report — {project_name}</title>
<meta name="description" content="{project_name} scores {context_score}/100 on Entroly Context Score. {avg_reduction}% token reduction, {files:,} files optimized.">
<meta property="og:title" content="{project_name} — Context Score {context_score}/100">
<meta property="og:description" content="{avg_reduction}% smaller than a 32K naive dump. {files:,} files indexed, ~{avg_selected_frags} selected per query. Powered by Entroly.">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="{project_name} — Context Score {context_score}/100 | Entroly">
<meta name="twitter:description" content="Context Score {context_score}/100 (stability·coverage·respect)^⅓. ~{avg_tokens_used:,} tokens/query from {files:,} files.">
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#09090b;color:#fafafa;font-family:'Inter',system-ui,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:24px}}
.card{{background:#18181b;border:1px solid #27272a;border-radius:20px;max-width:560px;width:100%;overflow:hidden;box-shadow:0 25px 80px rgba(0,0,0,0.5)}}
.header{{background:linear-gradient(135deg,#312e81,#1e1b4b);padding:32px;text-align:center;position:relative;overflow:hidden}}
.header::before{{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle,rgba(129,140,248,0.1) 0%,transparent 50%);animation:pulse 4s ease-in-out infinite}}
@keyframes pulse{{0%,100%{{transform:scale(1)}}50%{{transform:scale(1.05)}}}}
.logo{{font-weight:800;font-size:14px;letter-spacing:2px;text-transform:uppercase;color:#818cf8;margin-bottom:8px}}
.project{{font-size:24px;font-weight:800;letter-spacing:-0.5px;margin-bottom:4px}}
.subtitle{{color:#a1a1aa;font-size:13px}}
.score-section{{padding:32px;text-align:center;border-bottom:1px solid #27272a}}
.score-ring{{width:140px;height:140px;margin:0 auto 16px;position:relative}}
.score-ring svg{{transform:rotate(-90deg)}}
.score-ring .bg{{stroke:#27272a;fill:none;stroke-width:8}}
.score-ring .fg{{fill:none;stroke-width:8;stroke-linecap:round;stroke:{score_color};stroke-dasharray:{context_score * 4.4} 440;transition:stroke-dasharray 1.5s ease}}
.score-num{{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:42px;font-weight:900;color:{score_color}}}
.score-label{{color:#a1a1aa;font-size:13px;font-weight:500}}
.stats{{display:grid;grid-template-columns:1fr 1fr 1fr;border-bottom:1px solid #27272a}}
.stat{{padding:20px;text-align:center;border-right:1px solid #27272a}}
.stat:last-child{{border-right:none}}
.stat-val{{font-size:22px;font-weight:800;color:#34d399}}
.stat-label{{font-size:11px;color:#a1a1aa;text-transform:uppercase;letter-spacing:1px;margin-top:4px}}
.queries{{padding:24px}}
.queries h3{{font-size:13px;color:#a1a1aa;text-transform:uppercase;letter-spacing:1px;margin-bottom:16px}}
.qr{{background:#09090b;border:1px solid #27272a;border-radius:10px;padding:14px;margin-bottom:10px}}
.qr-query{{font-size:13px;font-weight:600;margin-bottom:8px}}
.qr-stats{{display:flex;gap:12px;font-size:12px}}
.qr-frags{{color:#818cf8}}
.qr-tokens{{color:#a1a1aa}}
.qr-saved{{color:#34d399;font-weight:700}}
.footer{{padding:20px 32px;text-align:center;border-top:1px solid #27272a}}
.footer p{{font-size:12px;color:#a1a1aa}}
.footer a{{color:#818cf8;text-decoration:none;font-weight:600}}
.cta{{display:inline-block;background:#818cf8;color:#fff;padding:10px 24px;border-radius:8px;font-weight:700;font-size:13px;text-decoration:none;margin-top:12px}}
.cta:hover{{opacity:0.9}}
.lifetime{{padding:16px 32px;border-bottom:1px solid #27272a;display:flex;justify-content:center;gap:24px;font-size:12px;color:#71717a}}
.lifetime strong{{color:#a1a1aa}}
</style>
</head>
<body>
<div class="card">
  <div class="header">
    <div class="logo">Entroly Context Report</div>
    <div class="project">{project_name}</div>
    <div class="subtitle">Generated with entroly share</div>
  </div>

  <div class="score-section">
    <div class="score-ring">
      <svg viewBox="0 0 160 160" width="140" height="140">
        <circle class="bg" cx="80" cy="80" r="70"/>
        <circle class="fg" cx="80" cy="80" r="70"/>
      </svg>
      <div class="score-num">{context_score}</div>
    </div>
    <div class="score-label">CONTEXT SCORE</div>
  </div>

  <div class="stats">
    <div class="stat">
      <div class="stat-val">{avg_selected_frags:,}</div>
      <div class="stat-label">Frags / Query<br><span style="font-size:10px;text-transform:none">of {files:,} indexed</span></div>
    </div>
    <div class="stat">
      <div class="stat-val">{avg_tokens_used:,}</div>
      <div class="stat-label">Tokens / Query<br><span style="font-size:10px;text-transform:none">{avg_reduction}% &lt; 32K dump</span></div>
    </div>
    <div class="stat">
      <div class="stat-val">${per_query_savings_usd:.4f}</div>
      <div class="stat-label">Modeled / Query<br><span style="font-size:10px;text-transform:none">32K baseline · GPT-4o rate</span></div>
    </div>
  </div>

  <div class="stats" style="grid-template-columns:1fr 1fr 1fr">
    <div class="stat">
      <div class="stat-val" style="color:#a1a1aa;font-size:18px">{avg_stability:.2f}</div>
      <div class="stat-label">Stability<br><span style="font-size:10px;text-transform:none">Jaccard(S@B, S@2B)</span></div>
    </div>
    <div class="stat">
      <div class="stat-val" style="color:#a1a1aa;font-size:18px">{avg_coverage:.2f}</div>
      <div class="stat-label">Coverage<br><span style="font-size:10px;text-transform:none">query terms hit</span></div>
    </div>
    <div class="stat">
      <div class="stat-val" style="color:#a1a1aa;font-size:18px">{avg_respect:.2f}</div>
      <div class="stat-label">Respect<br><span style="font-size:10px;text-transform:none">tokens ≤ budget</span></div>
    </div>
  </div>

  {"<div class='lifetime'><span>Provider-bound: <strong>" + f"{lifetime_tokens:,}" + "</strong> input tokens reduced</span><span><strong>" + f"${lifetime_cost:,.2f}" + "</strong> modeled cost avoided</span><span><strong>" + f"{lifetime_requests:,}" + "</strong> requests</span></div>" if lifetime_requests > 0 else ""}

  <div class="queries">
    <h3>Sample Queries</h3>
    {query_rows}
  </div>

  <div class="footer">
    <p>My codebase scores <strong>{context_score}/100</strong> on Entroly. What's yours?</p>
    <a href="https://github.com/juyterman1000/entroly" class="cta">Get Your Score</a>
    <p style="margin-top:12px"><a href="https://github.com/juyterman1000/entroly">github.com/juyterman1000/entroly</a></p>
  </div>
</div>
</body>
</html>"""


def cmd_capabilities(args):
    """entroly capabilities — report installed surfaces without network access."""
    from .runtime_capabilities import render_capabilities_text, runtime_capabilities

    report = runtime_capabilities()
    if getattr(args, "json_output", False):
        print(json.dumps(report, sort_keys=True))
    else:
        print("\n" + render_capabilities_text(report) + "\n")
    return 0


def cmd_doctor(args):
    """entroly doctor — diagnose common issues (Gap #52)."""
    if getattr(args, "json_output", False):
        from .runtime_doctor import runtime_doctor

        report = runtime_doctor(
            data_dir=_ENTROLY_DIR,
            port=args.port or 9377,
        )
        print(json.dumps(report, sort_keys=True))
        return 0 if report["healthy"] else 1

    print(f"\n{C.CYAN}{C.BOLD}  Entroly Doctor{C.RESET}\n")

    checks_passed = 0
    checks_total = 0
    # Counted separately so the summary can never report a red failure as a
    # pass. A diagnostic that always prints "N/N passed" cannot be trusted or
    # used as a gate. Only states in which entroly cannot work count as
    # failures (non-zero exit); advisories that need attention but leave the
    # tool usable are warnings, so `entroly doctor` stays usable as a CI gate
    # without going red on a healthy install.
    checks_failed = 0
    checks_warned = 0

    # 1. Check Python version
    checks_total += 1
    py_ver = platform.python_version()
    if sys.version_info >= (3, 10):
        print(f"  {C.GREEN}+{C.RESET} Python {py_ver}")
        checks_passed += 1
    else:
        print(f"  {C.RED}x{C.RESET} Python {py_ver} (need >=3.10)")
        checks_failed += 1

    # 2. Check Rust engine
    checks_total += 1
    from .native_status import QCCR_SYMBOLS, native_status
    native = native_status(QCCR_SYMBOLS)
    if native.ok:
        version = f" {native.version}" if native.version else ""
        print(f"  {C.GREEN}+{C.RESET} Rust engine (entroly-core{version}) loaded")
        checks_passed += 1
    elif not native.available:
        print(
            f"  {C.GRAY}-{C.RESET} Optional Rust acceleration not installed "
            f"{C.GRAY}— pure-Python engine is active{C.RESET}"
        )
        print(
            f"    {C.GRAY}Enable when wanted: python -m pip install "
            f"\"entroly[native]\"{C.RESET}"
        )
        checks_passed += 1
    else:
        print(f"  {C.RED}x{C.RESET} Installed Rust engine is stale or incomplete "
              f"{C.GRAY}— pure-Python fallback remains available{C.RESET}")
        if native.version:
            print(f"    {C.GRAY}Loaded version: {native.version}{C.RESET}")
        if native.path:
            print(f"    {C.GRAY}Loaded from: {native.path}{C.RESET}")
        if native.missing_symbols:
            print(f"    {C.GRAY}Missing symbols: {', '.join(native.missing_symbols)}{C.RESET}")
        # Prebuilt abi3 wheels (py>=3.10, incl. 3.14) ship for
        # mac/linux/windows. The usual failure is pip reusing a stale
        # cache or being too old to match the wheel, then falling back
        # to compiling an ancient sdist. Bust the cache + upgrade pip
        # first — that fixes it without any compile.
        print(f"    {C.GRAY}Fix:  python -m pip install --no-cache-dir -U pip && "
              f"python -m pip install --no-cache-dir -U \"entroly-core>=1.0.78\"{C.RESET}")
        print(f"    {C.GRAY}(If pip still compiles from source and fails on "
              f"a new Python, your pip is too old to{C.RESET}")
        print(f"    {C.GRAY} match the abi3 wheel — upgrading pip is the "
              f"fix, not a different Python.){C.RESET}")
        # Not a failure: the message above states the pure-Python fallback
        # remains available, so entroly still works, and this is the normal state
        # in a source checkout between a Rust edit and `maturin develop
        # --release`. But it must still be COUNTED — incrementing nothing left
        # passed+failed+warned < total, so the summary read "7/8 checks passed"
        # with no failure and no warning, and the degraded install passed every
        # gate. That is the same false-green this split-counter scheme exists to
        # prevent.
        checks_warned += 1

    # 3. Check config validity
    checks_total += 1
    tuning_path = Path(__file__).parent / "tuning_config.json"
    if tuning_path.exists():
        try:
            with open(tuning_path) as f:
                tc = json.load(f)
            weights = tc.get("weights", {})
            w_sum = sum(weights.values()) if weights else 0
            if abs(w_sum - 1.0) < 0.01:
                print(f"  {C.GREEN}+{C.RESET} Config valid (weights sum={w_sum:.3f})")
                checks_passed += 1
            else:
                print(f"  {C.YELLOW}!{C.RESET} Config: weights sum={w_sum:.3f} (expected ~1.0)")
                checks_passed += 1  # warning, not failure
        except Exception as e:
            print(f"  {C.RED}x{C.RESET} Config error: {e}")
            checks_failed += 1
    else:
        print(f"  {C.GREEN}+{C.RESET} Config: using defaults (no tuning_config.json)")
        checks_passed += 1

    # 4. Check proxy reachability
    checks_total += 1
    port = getattr(args, "port", None) or 9377
    if _is_entroly_proxy_running(port):
        print(f"  {C.GREEN}+{C.RESET} Proxy reachable at localhost:{port}")
        checks_passed += 1
    else:
        print(f"  {C.GRAY}-{C.RESET} Proxy not running (localhost:{port})")
        checks_passed += 1  # not running is OK for doctor

    # 5. Check index freshness
    checks_total += 1
    entroly_dir = Path.home() / ".entroly"
    checkpoint_dir = entroly_dir / "checkpoints"
    if checkpoint_dir.exists():
        checkpoint_files = list(checkpoint_dir.glob("*.json*"))
        if checkpoint_files:
            newest = max(f.stat().st_mtime for f in checkpoint_files)
            import time as _time
            age_hours = (_time.time() - newest) / 3600
            if age_hours < 24:
                print(f"  {C.GREEN}+{C.RESET} Index fresh ({age_hours:.1f}h old)")
            else:
                print(f"  {C.YELLOW}!{C.RESET} Index stale ({age_hours:.0f}h old -- consider re-indexing)")
            checks_passed += 1
        else:
            print(f"  {C.GRAY}-{C.RESET} No index found (will be created on first run)")
            checks_passed += 1
    else:
        print(f"  {C.GRAY}-{C.RESET} No checkpoints directory")
        checks_passed += 1

    # 6. Check weight drift
    checks_total += 1
    if tuning_path.exists():
        try:
            with open(tuning_path) as f:
                tc = json.load(f)
            defaults = {"recency": 0.30, "frequency": 0.25, "semantic": 0.25, "entropy": 0.20}
            weights = tc.get("weights", defaults)
            drift = sum(abs(weights.get(k, v) - v) for k, v in defaults.items())
            if drift < 0.1:
                print(f"  {C.GREEN}+{C.RESET} Weights near defaults (drift={drift:.3f})")
                checks_passed += 1
            elif drift < 0.3:
                print(f"  {C.YELLOW}!{C.RESET} Weights drifted (drift={drift:.3f})")
                checks_passed += 1  # warning, still usable
            else:
                # Advisory, not a broken install: heavy drift is produced by the
                # supported `entroly autotune` doing its job, and the message
                # itself only suggests a rollback. It must not be counted as a
                # pass (it needs attention), but it must not fail the command
                # either, or every autotuned machine fails `entroly doctor`.
                print(f"  {C.YELLOW}!{C.RESET} Weights heavily drifted ({drift:.3f}) -- consider autotune --rollback")
                checks_warned += 1
        except Exception as e:
            # Never pass silently: an unreadable weights file is a real problem
            # and previously produced no output at all.
            print(f"  {C.RED}x{C.RESET} Weight drift unreadable: {e}")
            checks_failed += 1
    else:
        print(f"  {C.GREEN}+{C.RESET} Weights: defaults (no drift)")
        checks_passed += 1

    # 7. Check Docker (optional)
    checks_total += 1
    try:
        import subprocess
        result = subprocess.run(
            ["docker", "info"], capture_output=True, timeout=5
        )
        if result.returncode == 0:
            print(f"  {C.GREEN}+{C.RESET} Docker available")
        else:
            print(f"  {C.GRAY}-{C.RESET} Docker not running (optional)")
        checks_passed += 1
    except (FileNotFoundError, subprocess.TimeoutExpired):
        print(f"  {C.GRAY}-{C.RESET} Docker not installed (optional)")
        checks_passed += 1

    # 8. Check hallucination verifier stack
    checks_total += 1
    try:
        from entroly.verifiers import trace_provenance, forge_loop  # noqa: F401
        print(f"  {C.GREEN}+{C.RESET} Hallucination verifiers (BIPT + FORGE) loaded")
        checks_passed += 1
    except ImportError as e:
        print(f"  {C.YELLOW}!{C.RESET} Hallucination verifiers not available ({e})")
        checks_passed += 1  # optional, not a failure

    summary = f"\n  {C.BOLD}{checks_passed}/{checks_total} checks passed"
    if checks_failed:
        summary += f", {C.RED}{checks_failed} failed{C.RESET}{C.BOLD}"
    if checks_warned:
        summary += f", {C.YELLOW}{checks_warned} warning(s){C.RESET}"
    print(summary + C.RESET)

    # ── Privacy Audit Mode ──────────────────────────────────────
    if getattr(args, "privacy", False):
        print(f"\n{C.CYAN}{C.BOLD}  Privacy Audit{C.RESET}\n")
        print(f"  {C.GRAY}Scanning Entroly source for external network calls...{C.RESET}\n")

        import re as _re

        pkg_dir = Path(__file__).parent
        privacy_passed = 0
        privacy_total = 0

        # 1. Check for Entroly-owned external servers
        privacy_total += 1
        entroly_domains = []
        for py_file in pkg_dir.rglob("*.py"):
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
                for m in _re.finditer(r'entroly\.(com|io|dev|cloud|app)', content):
                    entroly_domains.append((py_file.name, m.group()))
            except OSError:
                pass
        if not entroly_domains:
            print(f"  {C.GREEN}+{C.RESET} No Entroly-owned external servers contacted")
            privacy_passed += 1
        else:
            print(f"  {C.RED}x{C.RESET} Found Entroly domain references: {entroly_domains}")

        # 2. Check for analytics/telemetry SDKs
        privacy_total += 1
        analytics_sdks = [
            "sentry", "mixpanel", "segment", "amplitude", "posthog",
            "datadog", "newrelic", "bugsnag", "rollbar", "logrocket",
        ]
        found_sdks = []
        for py_file in pkg_dir.rglob("*.py"):
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore").lower()
                for sdk in analytics_sdks:
                    if f"import {sdk}" in content or f"from {sdk}" in content:
                        found_sdks.append((py_file.name, sdk))
            except OSError:
                pass
        if not found_sdks:
            print(f"  {C.GREEN}+{C.RESET} No analytics/telemetry SDKs imported")
            privacy_passed += 1
        else:
            print(f"  {C.RED}x{C.RESET} Found analytics SDKs: {found_sdks}")

        # 3. Check hallucination detection is fully local
        privacy_total += 1
        halu_modules = ["witness.py", "ece.py", "epr.py", "spectral.py"]
        halu_external = []
        for mod_name in halu_modules:
            for py_file in pkg_dir.rglob(mod_name):
                try:
                    content = py_file.read_text(encoding="utf-8", errors="ignore")
                    if "urllib" in content or "httpx" in content or "requests." in content:
                        # Check if it's actually importing for HTTP calls
                        if _re.search(r'(urlopen|httpx\.(get|post)|requests\.(get|post))', content):
                            halu_external.append(py_file.name)
                except OSError:
                    pass
        witness_nli = os.environ.get("ENTROLY_WITNESS_NLI", "0") == "1"
        if not halu_external and not witness_nli:
            print(f"  {C.GREEN}+{C.RESET} Hallucination detection uses local deterministic paths by default")
            privacy_passed += 1
        elif not halu_external and witness_nli:
            print(f"  {C.YELLOW}!{C.RESET} WITNESS NLI is ON -- selected evidence/claims may be sent to OpenAI")
            privacy_passed += 1
        else:
            print(f"  {C.RED}x{C.RESET} Hallucination modules with external calls: {halu_external}")

        # 4. Check federation is OFF by default
        privacy_total += 1
        fed_default = os.environ.get("ENTROLY_FEDERATION", "0")
        if fed_default != "1":
            print(f"  {C.GREEN}+{C.RESET} Federation is OFF by default (ENTROLY_FEDERATION={fed_default})")
            privacy_passed += 1
        else:
            print(f"  {C.YELLOW}!{C.RESET} Federation is ON (ENTROLY_FEDERATION=1) — DP-noised weights may be shared")

        # 4b. Check RAVS model routing is opt-in
        privacy_total += 1
        ravs_router = os.environ.get("ENTROLY_RAVS_ROUTER", "0")
        if ravs_router != "1":
            print(f"  {C.GREEN}+{C.RESET} RAVS model routing is OFF by default (ENTROLY_RAVS_ROUTER={ravs_router})")
            privacy_passed += 1
        else:
            print(f"  {C.YELLOW}!{C.RESET} RAVS model routing is ON -- routed requests may use a different model")
            privacy_passed += 1

        # 5. Check escalation mode
        privacy_total += 1
        esc_mode = os.environ.get("ENTROLY_ESCALATION_MODE", "observe")
        if esc_mode == "observe":
            print(f"  {C.GREEN}+{C.RESET} Escalation mode: observe (no extra API calls)")
            privacy_passed += 1
        elif esc_mode == "active":
            print(f"  {C.YELLOW}!{C.RESET} Escalation mode: active (flagged requests re-issued to YOUR API)")
            privacy_passed += 1  # still goes to user's own API
        else:
            print(f"  {C.GREEN}+{C.RESET} Escalation mode: {esc_mode}")
            privacy_passed += 1

        # 6. Check for secret detection
        privacy_total += 1
        try:
            from entroly.proxy import _SECRET_PATTERNS
            print(f"  {C.GREEN}+{C.RESET} Secret detection active (API keys, passwords, tokens redacted from logs)")
            privacy_passed += 1
        except ImportError:
            print(f"  {C.YELLOW}!{C.RESET} Secret detection not available")
            privacy_passed += 1

        # 7. Check local data storage
        privacy_total += 1
        entroly_data = Path.cwd() / ".entroly"
        if entroly_data.exists():
            data_files = list(entroly_data.rglob("*"))
            data_size = sum(f.stat().st_size for f in data_files if f.is_file())
            print(f"  {C.GREEN}+{C.RESET} Local data: {len(data_files)} files "
                  f"({data_size // 1024}KB) in .entroly/ (delete to clear)")
        else:
            print(f"  {C.GREEN}+{C.RESET} No local data stored yet (.entroly/ not created)")
        privacy_passed += 1

        # 8. Verify PRIVACY.md exists. This is a SOURCE-repo document that is
        # not shipped in the pip/npm package, so when it's absent (the normal
        # case for an installed package) the check is SKIPPED — not counted as
        # passed. Counting a missing file as a pass produced the contradictory
        # "PRIVACY.md not found ... VERIFIED 9/9".
        privacy_md = Path(__file__).parent.parent / "PRIVACY.md"
        if privacy_md.exists():
            privacy_total += 1
            print(f"  {C.GREEN}+{C.RESET} PRIVACY.md present in repository")
            privacy_passed += 1
        else:
            print(f"  {C.GRAY}-{C.RESET} PRIVACY.md not in this install "
                  f"(expected for the pip/npm package; see the source repo) — skipped")

        # Summary
        if privacy_passed == privacy_total:
            print(f"\n  {C.GREEN}{C.BOLD}PRIVACY VERIFIED: {privacy_passed}/{privacy_total} checks passed{C.RESET}")
            print(f"  {C.GREEN}No Entroly-owned phone-home path detected.{C.RESET}")
            print(f"  {C.GRAY}Configured cloud LLM providers still receive optimized prompt content sent through the proxy.{C.RESET}")
            print()
            # A clean privacy audit must not mask a failed diagnostic check.
            return 1 if checks_failed else 0
        print(f"\n  {C.YELLOW}{C.BOLD}PRIVACY: {privacy_passed}/{privacy_total} checks passed{C.RESET}")
        print(f"  {C.YELLOW}Review the warnings above.{C.RESET}")
        print()
        return 1

    # Signal failure to the dispatcher so `entroly doctor` can gate automation
    # instead of always exiting 0.
    return 1 if checks_failed else 0



def cmd_digest(args):
    """entroly digest — show weekly summary of entroly's value (Gap #44)."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Weekly Digest{C.RESET}\n")


    # Try to get stats from running proxy
    port = getattr(args, "port", None) or 9377
    stats = None
    try:
        import urllib.request
        resp = urllib.request.urlopen(f"http://localhost:{port}/stats", timeout=2)
        if resp.status == 200:
            stats = json.loads(resp.read())
    except Exception:
        pass

    if stats:
        total = stats.get("requests_total", 0)
        optimized = stats.get("requests_optimized", 0)
        tokens = stats.get("tokens", {})
        saved = tokens.get("saved_total", 0)
        savings_pct = tokens.get("savings_pct", "N/A")
        outcomes = stats.get("outcomes", {})
        error_rate = outcomes.get("error_rate", 0)
        latency = stats.get("pipeline_latency", {})
        mean_ms = latency.get("mean_ms", 0)

        print(f"  {C.BOLD}Requests:{C.RESET} {total:,} total, {optimized:,} optimized")
        print(f"  {C.BOLD}Tokens saved:{C.RESET} {saved:,} ({savings_pct})")
        from entroly.value_tracker import estimate_cost
        est_cost = estimate_cost(saved, "gpt-4o")
        print(
            f"  {C.BOLD}Modeled API input cost avoided:{C.RESET} "
            f"${est_cost:.2f} {C.GRAY}(provider-bound tokens at the "
            f"bundled GPT-4o input rate; not an invoice){C.RESET}"
        )
        print(f"  {C.BOLD}Pipeline latency:{C.RESET} {mean_ms:.1f}ms avg")
        if error_rate > 0:
            color = C.RED if error_rate > 0.1 else C.YELLOW
            print(f"  {C.BOLD}Error rate:{C.RESET} {color}{error_rate:.1%}{C.RESET}")
        else:
            print(f"  {C.BOLD}Error rate:{C.RESET} {C.GREEN}0%{C.RESET}")
    else:
        # Fall back to checkpoint/stats file
        stats_file = Path.home() / ".entroly" / "session_stats.json"
        if stats_file.exists():
            try:
                with open(stats_file) as f:
                    data = json.load(f)
                total_saved = data.get("total_tokens_saved", 0)
                total_opt = data.get("total_optimizations", 0)
                print(f"  {C.BOLD}Sessions recorded:{C.RESET} {total_opt:,} optimizations")
                print(f"  {C.BOLD}Tokens saved (lifetime):{C.RESET} {total_saved:,}")
            except Exception:
                print(f"  {C.YELLOW}No stats available.{C.RESET} Start the proxy to begin tracking.")
        else:
            print(f"  {C.YELLOW}No stats available.{C.RESET} Start the proxy to begin tracking.")
    print()


def cmd_migrate(args):
    """entroly migrate — auto-migrate config/index to new format (Gap #53)."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Migration Check{C.RESET}\n")

    from entroly import __version__ as current_version

    entroly_dir = Path.home() / ".entroly"
    version_file = entroly_dir / ".version"

    # Check stored version
    stored_version = None
    if version_file.exists():
        try:
            stored_version = version_file.read_text().strip()
        except OSError:
            pass

    if stored_version == current_version:
        print(f"  {C.GREEN}+{C.RESET} Already on version {current_version}. No migration needed.\n")
        return

    if stored_version:
        print(f"  Upgrading from {C.YELLOW}{stored_version}{C.RESET} to {C.GREEN}{current_version}{C.RESET}\n")
    else:
        print(f"  First run of version {C.GREEN}{current_version}{C.RESET}\n")

    migrated = 0

    # Check tuning_config.json schema
    tuning_path = Path(__file__).parent / "tuning_config.json"
    if tuning_path.exists():
        try:
            with open(tuning_path) as f:
                tc = json.load(f)
            # Ensure all required sections exist
            changed = False
            if "weights" not in tc:
                tc["weights"] = {"recency": 0.30, "frequency": 0.25, "semantic": 0.25, "entropy": 0.20}
                changed = True
            if "decay" not in tc:
                tc["decay"] = {"half_life": 15, "min_relevance": 0.05}
                changed = True
            if "knapsack" not in tc:
                tc["knapsack"] = {"exploration_rate": 0.10}
                changed = True
            if changed:
                with open(tuning_path, "w") as f:
                    json.dump(tc, f, indent=2)
                print(f"  {C.GREEN}+{C.RESET} Migrated tuning_config.json (added missing sections)")
                migrated += 1
            else:
                print(f"  {C.GREEN}+{C.RESET} tuning_config.json: schema up to date")
        except Exception as e:
            print(f"  {C.RED}x{C.RESET} tuning_config.json error: {e}")
    else:
        print(f"  {C.GREEN}+{C.RESET} No tuning_config.json (using defaults)")

    # Check checkpoint format
    checkpoint_dir = entroly_dir / "checkpoints"
    if checkpoint_dir.exists():
        old_checkpoints = list(checkpoint_dir.glob("*.json"))
        gz_checkpoints = list(checkpoint_dir.glob("*.json.gz"))
        if old_checkpoints and not gz_checkpoints:
            print(f"  {C.YELLOW}!{C.RESET} Found {len(old_checkpoints)} uncompressed checkpoints")
            print(f"       Run {C.CYAN}entroly clean{C.RESET} + re-index for compressed format")
        else:
            print(f"  {C.GREEN}+{C.RESET} Checkpoints: format OK ({len(gz_checkpoints)} compressed)")
    else:
        print(f"  {C.GREEN}+{C.RESET} No checkpoints to migrate")

    # Write version marker
    try:
        entroly_dir.mkdir(parents=True, exist_ok=True)
        version_file.write_text(current_version)
        print(f"\n  {C.GREEN}{C.BOLD}Migration complete.{C.RESET} "
              f"({migrated} item{'s' if migrated != 1 else ''} migrated)\n")
    except OSError:
        pass


def cmd_role(args):
    """entroly role — role-based weight presets for different developer types (Gap #49)."""
    print(f"\n{C.CYAN}{C.BOLD}  Entroly Role Presets{C.RESET}\n")

    # Starting-point presets. The rationale under each is an information-
    # theoretic argument, not a measurement — run `entroly autotune` after
    # applying to calibrate against bench/cases.json for your codebase.
    roles = {
        "frontend": {
            "description": "Frontend developer (React, Vue, CSS)",
            "weights": {"recency": 0.25, "frequency": 0.30, "semantic": 0.30, "entropy": 0.15},
            "note": "Component reuse is a repetition pattern — frequency captures it; "
                    "semantic similarity finds the right component class at retrieval.",
        },
        "backend": {
            "description": "Backend developer (API, database, services)",
            "weights": {"recency": 0.30, "frequency": 0.20, "semantic": 0.25, "entropy": 0.25},
            "note": "Backend work spans heterogeneous subsystems (HTTP, DB, auth, queues); "
                    "entropy diversifies selection across them rather than collapsing into one.",
        },
        "sre": {
            "description": "SRE / DevOps (infra, CI/CD, monitoring)",
            "weights": {"recency": 0.35, "frequency": 0.15, "semantic": 0.20, "entropy": 0.30},
            "note": "Infra state drifts fast (recency) and configs come from many distinct "
                    "sources — k8s, Terraform, GHA, Dockerfiles — (entropy).",
        },
        "data": {
            "description": "Data engineer / ML (SQL, pipelines, notebooks)",
            "weights": {"recency": 0.20, "frequency": 0.30, "semantic": 0.30, "entropy": 0.20},
            "note": "Pipelines reuse table/column/schema names heavily; frequency picks up "
                    "the repetition, semantic matches the right transform or model.",
        },
        "fullstack": {
            "description": "Full-stack developer (balanced across all areas)",
            "weights": {"recency": 0.25, "frequency": 0.25, "semantic": 0.25, "entropy": 0.25},
            "note": "Uniform priors when workload mix is unknown — maximum-entropy default.",
        },
    }

    # Support both `entroly role list` and `entroly role --preset backend`
    preset = getattr(args, "preset", None)
    if preset:
        # --preset is shorthand for "apply <name>"
        action = "apply"
        args.name = preset
    else:
        action = getattr(args, "role_action", "list")

    if action == "list":
        for name, info in roles.items():
            w = info["weights"]
            print(f"  {C.CYAN}{name:12s}{C.RESET} {info['description']}")
            print(f"               R={w['recency']:.2f}  F={w['frequency']:.2f}  "
                  f"S={w['semantic']:.2f}  E={w['entropy']:.2f}")
            print(f"               {C.GRAY}{info['note']}{C.RESET}\n")
        print(f"  {C.GRAY}Rationales are information-theoretic starting points, not measurements.{C.RESET}")
        print(f"  {C.GRAY}Run {C.CYAN}entroly autotune{C.GRAY} after applying to calibrate on your codebase.{C.RESET}")
        print(f"  Apply with: {C.CYAN}entroly role apply <name>{C.RESET}\n")

    elif action == "apply":
        name = getattr(args, "name", None)
        if not name or name not in roles:
            valid = ", ".join(roles.keys())
            print(f"  {C.RED}Unknown role.{C.RESET} Valid: {valid}")
            return
        role = roles[name]
        active_config = _load_active_tuning_config()
        tc = dict(active_config[1]) if active_config is not None else {}
        tc["weights"] = role["weights"]
        tuning_path = _writable_tuning_config_path()
        tuning_path.parent.mkdir(parents=True, exist_ok=True)
        with open(tuning_path, "w", encoding="utf-8") as f:
            json.dump(tc, f, indent=2)
        print(f"  {C.GREEN}Applied '{name}' role preset:{C.RESET}")
        w = role["weights"]
        print(f"    R={w['recency']:.2f}  F={w['frequency']:.2f}  "
              f"S={w['semantic']:.2f}  E={w['entropy']:.2f}")
        print(f"    {C.GRAY}Wrote {tuning_path}{C.RESET}")
        print(f"    {C.GRAY}{role['note']}{C.RESET}")
        print(f"    {C.GRAY}Run {C.CYAN}entroly autotune{C.GRAY} to calibrate on your codebase.{C.RESET}\n")


def cmd_completions(args):
    """entroly completions {bash|zsh|fish} — output shell completion script."""
    shell = args.shell
    commands = [
        "init", "go", "serve", "proxy", "dashboard", "value", "health",
        "autotune", "benchmark", "simulate", "perf", "status", "config", "clean",
        "telemetry", "export", "import", "drift", "profile",
        "batch", "wrap", "unwrap", "capabilities", "learn", "share", "demo",
        "doctor", "digest", "migrate", "role", "completions",
        "optimize", "ingest", "select", "receipt", "explain",
        "feedback", "compile", "verify", "sync",
        "search", "docs", "finetune", "witness",
    ]
    cmd_list = " ".join(commands)

    if shell == "bash":
        print(f"""# entroly bash completion -- add to ~/.bashrc:
#   eval "$(entroly completions bash)"
_entroly_completions() {{
    local cur="${{COMP_WORDS[COMP_CWORD]}}"
    if [ "$COMP_CWORD" -eq 1 ]; then
        COMPREPLY=($(compgen -W "{cmd_list} --help --version" -- "$cur"))
    elif [ "${{COMP_WORDS[1]}}" = "proxy" ]; then
        COMPREPLY=($(compgen -W "--port --host --quality --force --help" -- "$cur"))
    elif [ "${{COMP_WORDS[1]}}" = "completions" ]; then
        COMPREPLY=($(compgen -W "bash zsh fish" -- "$cur"))
    elif [ "${{COMP_WORDS[1]}}" = "init" ]; then
        COMPREPLY=($(compgen -W "--dry-run --help" -- "$cur"))
    fi
}}
complete -F _entroly_completions entroly""")
    elif shell == "zsh":
        print(f"""# entroly zsh completion -- add to ~/.zshrc:
#   eval "$(entroly completions zsh)"
_entroly() {{
    local -a commands
    commands=({cmd_list})
    _arguments '1:command:($commands)' '*::arg:->args'
    case $words[1] in
        proxy) _arguments '--port[Proxy port]:port' '--host[Bind host]:host' '--quality[Quality 0-1]:quality' '--force[Force re-index]' ;;
        completions) _arguments '1:shell:(bash zsh fish)' ;;
        init) _arguments '--dry-run[Preview only]' ;;
    esac
}}
compdef _entroly entroly""")
    elif shell == "fish":
        print(f"""# entroly fish completion -- save to ~/.config/fish/completions/entroly.fish
complete -c entroly -n '__fish_use_subcommand' -a '{cmd_list}' -d 'Entroly commands'
complete -c entroly -n '__fish_seen_subcommand_from proxy' -l port -d 'Proxy port'
complete -c entroly -n '__fish_seen_subcommand_from proxy' -l host -d 'Bind host'
complete -c entroly -n '__fish_seen_subcommand_from proxy' -l quality -d 'Quality 0-1'
complete -c entroly -n '__fish_seen_subcommand_from completions' -a 'bash zsh fish'""")
    else:
        print(f"Unknown shell: {shell}. Supported: bash, zsh, fish", file=sys.stderr)
        sys.exit(1)


def cmd_optimize(args):
    """entroly optimize — generate an optimized context snapshot for a specific task.

    Indexes the codebase and selects files under a token budget using the
    knapsack approximation (0/1 DP when feasible, density-greedy otherwise —
    not exact optimum; knapsack is NP-hard). Outputs a markdown snapshot
    suitable for injection into a subagent prompt.
    """
    from entroly.auto_index import auto_index
    from entroly.server import EntrolyEngine

    task = getattr(args, "task", "") or ""
    budget = getattr(args, "budget", 8192)
    output_format = getattr(args, "format", "markdown")
    quiet = getattr(args, "quiet", False)

    if not quiet:
        print(f"\n{C.CYAN}{C.BOLD}  Entroly Optimize{C.RESET}", file=sys.stderr)
        if task:
            print(f"  Task: {C.GREEN}{task}{C.RESET}", file=sys.stderr)
        print(f"  Budget: {budget:,} tokens\n", file=sys.stderr)

    engine = EntrolyEngine()
    result = auto_index(engine)

    if result["status"] == "indexed":
        files_indexed = result["files_indexed"]
        total_tokens = result["total_tokens"]
        if not quiet:
            print(f"  Indexed {C.GREEN}{files_indexed}{C.RESET} files ({total_tokens:,} tokens)\n", file=sys.stderr)
    elif result["status"] == "skipped":
        existing = result.get("existing_fragments", 0)
        if existing == 0:
            print(f"  {C.YELLOW}No files found.{C.RESET} Run from a project directory.", file=sys.stderr)
            return
        files_indexed = existing
        if not quiet:
            print(f"  Using persistent index: {C.GREEN}{files_indexed}{C.RESET} fragments\n", file=sys.stderr)
    else:
        print(f"  {C.YELLOW}No files found.{C.RESET} Run from a project directory.", file=sys.stderr)
        return

    engine.advance_turn()
    selector = getattr(args, "selector", "auto")
    # "auto" — QCCR when a query is present (sentence-level extractive wins
    # head-to-head in quality_eval on code-retrieval tasks); fall back to
    # knapsack when there's no query to condition on.
    if selector == "auto":
        # QCCR and DOPT need the Rust fragment export API. The default CLI
        # install intentionally works without entroly-core, so the Python
        # fallback must choose the selector that has a native Python path.
        selector = "qccr" if task and getattr(engine, "_use_rust", False) else "knapsack"
    if selector in ("dopt", "qccr"):
        if not getattr(engine, "_use_rust", False):
            print(
                f"  {C.YELLOW}Selector {selector!r} requires the native entroly-core engine; "
                f"falling back to knapsack.{C.RESET}",
                file=sys.stderr,
            )
            opt = engine.optimize_context(token_budget=budget, query=task)
            selected = opt.get("selected_fragments", []) or opt.get("selected", [])
        else:
            # Query-aware re-selection over the full fragment store, bypassing
            # recall() (which caps at ~25 items and biases toward stale stubs).
            #   dopt — file-level BM25 with log-det diversity (experimental)
            #   qccr — sentence-level query-conditioned extractive summarization
            #          with MMR diversity; emits synthetic per-file excerpts.
            candidates = [dict(f) for f in engine._rust.export_fragments()]
            exclude_patterns = getattr(args, "exclude", []) or []
            if exclude_patterns:
                candidates = [
                    c for c in candidates
                    if not any(p in (c.get("source") or "") for p in exclude_patterns)
                ]
            if selector == "qccr":
                from entroly.qccr import select as qccr_select
                selected = qccr_select(candidates, token_budget=budget, query=task)
            else:
                from entroly.dopt_selector import select as dopt_select
                selected = dopt_select(candidates, token_budget=budget, query=task)
            opt = {
                "selected_fragments": selected,
                "total_tokens": sum(f.get("token_count") or (len(f.get("content", "")) // 4) for f in selected),
                "recommended_budget": budget,
                "task_type": "",
            }
    else:
        opt = engine.optimize_context(token_budget=budget, query=task)
        selected = opt.get("selected_fragments", []) or opt.get("selected", [])

    # Deduplicate fragments by source path
    seen_sources = set()
    deduped = []
    for f in selected:
        src = f.get("source", "")
        if src not in seen_sources:
            seen_sources.add(src)
            deduped.append(f)
    selected = deduped
    # Source of truth for tokens_used is the engine's own accounting
    # (opt["total_tokens"]). It reflects the resolution-aware cost the
    # knapsack actually charged against the budget. Summing per-fragment
    # token_count in Python can drift by a handful of tokens because
    # Reference/Skeleton/Belief variants report different costs than the
    # knapsack internally charges.
    tokens_used = opt.get("total_tokens", sum(f.get("token_count", 0) for f in selected))
    recommended_budget = opt.get("recommended_budget", budget)
    task_type = opt.get("task_type", "")

    if not quiet:
        print(f"  Selected {C.GREEN}{len(selected)}{C.RESET} fragments ({tokens_used:,} tokens)\n", file=sys.stderr)
        if recommended_budget > budget and task_type:
            print(
                f"  {C.YELLOW}Note:{C.RESET} task classified as {C.CYAN}{task_type}{C.RESET} — "
                f"a wider budget of {C.GREEN}{recommended_budget:,}{C.RESET} is recommended for best coverage.\n"
                f"  Pass {C.GREEN}--budget {recommended_budget}{C.RESET} to opt in.\n",
                file=sys.stderr,
            )

    if output_format == "json":
        import json as _json
        output = {
            "task": task,
            "budget": budget,
            "tokens_used": tokens_used,
            "fragments": [
                {
                    "source": f.get("source", ""),
                    "token_count": f.get("token_count", 0),
                    "content": f.get("content", f.get("preview", "")),
                }
                for f in selected
            ],
        }
        print(_json.dumps(output, indent=2))
    else:
        # Markdown output — designed for injection into agent prompts
        lines = []
        lines.append("# Codebase Context Snapshot")
        lines.append("")
        if task:
            lines.append(f"**Task:** {task}")
        lines.append(f"**Files:** {len(selected)} | **Tokens:** {tokens_used:,} / {budget:,}")
        lines.append("")
        for frag in selected:
            source = frag.get("source", "unknown")
            tc = frag.get("token_count", 0)
            content = frag.get("content", "") or frag.get("preview", "")
            # If content is truncated (ends with ...), read full file from disk
            if content.endswith("...") and source:
                file_path = source.replace("file:", "") if source.startswith("file:") else source
                resolved = Path(file_path)
                if not resolved.is_absolute():
                    resolved = Path.cwd() / resolved
                try:
                    content = resolved.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    pass  # keep truncated preview as fallback
            # Detect language from file extension
            ext = source.rsplit(".", 1)[-1] if "." in source else ""
            lang_map = {
                "py": "python", "rs": "rust", "js": "javascript",
                "ts": "typescript", "go": "go", "rb": "ruby",
                "java": "java", "c": "c", "cpp": "cpp", "h": "c",
                "toml": "toml", "yaml": "yaml", "yml": "yaml",
                "json": "json", "md": "markdown", "sh": "bash",
            }
            lang = lang_map.get(ext, "")
            lines.append(f"## `{source}` ({tc} tokens)")
            lines.append(f"```{lang}")
            lines.append(content.rstrip())
            lines.append("```")
            lines.append("")
        print("\n".join(lines))

    # Save last optimization for feedback command
    state_file = Path.home() / ".entroly" / "last_optimize.json"
    try:
        state_file.parent.mkdir(parents=True, exist_ok=True)
        import json as _json
        with open(state_file, "w") as f:
            _json.dump({
                "fragment_ids": [fr.get("id", fr.get("fragment_id", "")) for fr in selected],
                "task": task,
                "tokens_used": tokens_used,
            }, f)
    except Exception:
        pass


def cmd_ingest(args):
    """entroly ingest PATH - build a local multi-document Context Receipt index."""
    from entroly.context_receipts import ingest_documents
    from entroly.context_receipts.ingest import read_documents_from_path, supported_documents_hint
    from entroly.context_receipts.store import DEFAULT_INDEX, write_json

    docs = read_documents_from_path(args.path)
    if not docs:
        print(f"  {C.RED}No supported documents found.{C.RESET} {supported_documents_hint()}", file=sys.stderr)
        return 1
    index = ingest_documents(
        docs,
        chunk_tokens=args.chunk_tokens,
        overlap_tokens=args.overlap_tokens,
        prefer_rust=not args.python,
    )
    out = Path(args.out) if args.out else DEFAULT_INDEX
    write_json(out, index)
    print(f"  {C.GREEN}Indexed {len(index['documents'])} document(s), {len(index['chunks'])} chunk(s).{C.RESET}")
    print(f"  Index: {out}")


def cmd_select(args):
    """entroly select - produce a machine-readable Context Receipt and Markdown report."""
    from entroly.context_receipts import ingest_documents, markdown_report, select_from_index
    from entroly.context_receipts.ingest import read_documents_from_path
    from entroly.context_receipts.store import (
        DEFAULT_INDEX,
        default_receipt_path,
        default_report_path,
        read_json,
        set_latest_receipt,
        write_json,
        write_text,
    )

    if args.docs:
        docs = read_documents_from_path(args.docs)
        if not docs:
            print(f"  {C.RED}No supported documents found in {args.docs!r}.{C.RESET}", file=sys.stderr)
            return 1
        index = ingest_documents(
            docs,
            chunk_tokens=args.chunk_tokens,
            overlap_tokens=args.overlap_tokens,
            prefer_rust=not args.python,
        )
    else:
        index_path = Path(args.index) if args.index else DEFAULT_INDEX
        if not index_path.exists():
            print(
                f"  {C.RED}No Context Receipt index found at {index_path}.{C.RESET} "
                "Run `entroly ingest ./docs` first or pass `--docs ./docs`.",
                file=sys.stderr,
            )
            return 1
        index = read_json(index_path)

    receipt = select_from_index(
        index,
        query=args.query,
        token_budget=args.budget,
        prefer_rust=not args.python,
    )
    receipt_path = Path(args.receipt) if args.receipt else default_receipt_path(receipt["receipt_id"])
    report_path = Path(args.report) if args.report else default_report_path(receipt["receipt_id"])
    write_json(receipt_path, receipt)
    write_text(report_path, markdown_report(receipt, prefer_rust=not args.python))
    set_latest_receipt(receipt_path)
    selected = len(receipt.get("selected_context", []))
    omitted = len(receipt.get("omitted_context", []))
    warnings = len(receipt.get("warnings", []))
    print(f"  {C.GREEN}Context Receipt {receipt['receipt_id']} created.{C.RESET}")
    print(f"  Selected: {selected} chunk(s); omitted tracked: {omitted}; warnings: {warnings}")
    print(f"  JSON: {receipt_path}")
    print(f"  Report: {report_path}")


def cmd_receipt(args):
    """entroly receipt RECEIPT_JSON - render or normalize a Context Receipt."""
    from entroly.context_receipts import markdown_report
    from entroly.context_receipts.store import read_json, write_text

    receipt = read_json(args.receipt_path)
    if args.json:
        print(json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False))
        return
    report = markdown_report(receipt, prefer_rust=not args.python)
    if args.out:
        write_text(args.out, report)
        print(f"  {C.GREEN}Wrote report:{C.RESET} {args.out}")
    else:
        print(report, end="")


def cmd_context_commit(args):
    """Create or verify a portable Context Commit artifact."""
    from entroly.context_commit import create_context_commit, verify_context_commit
    from entroly.context_receipts.ingest import (
        read_documents_from_path,
        supported_documents_hint,
    )
    from entroly.context_receipts.store import read_json, write_json

    if args.verify:
        commit = read_json(args.verify)
        result = verify_context_commit(commit)
        print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
        return 0 if result.valid else 1

    if not args.path or not args.query:
        print(
            f"  {C.RED}PATH and --query are required when creating a Context Commit.{C.RESET}",
            file=sys.stderr,
        )
        return 2
    docs = read_documents_from_path(args.path)
    if not docs:
        print(
            f"  {C.RED}No supported documents found.{C.RESET} "
            f"{supported_documents_hint()}",
            file=sys.stderr,
        )
        return 1
    commit = create_context_commit(
        docs,
        query=args.query,
        token_budget=args.budget,
        chunk_tokens=args.chunk_tokens,
        overlap_tokens=args.overlap_tokens,
        parent_commit_id=args.parent,
        prefer_rust=not args.python,
    )
    verification = verify_context_commit(commit)
    if not verification.valid:
        print(
            f"  {C.RED}Context Commit self-verification failed:{C.RESET} "
            + ", ".join(verification.errors),
            file=sys.stderr,
        )
        return 1
    output = (
        Path(args.out)
        if args.out
        else Path(".entroly") / "context-commits" / f"{commit['commit_id']}.json"
    )
    write_json(output, commit)
    if args.json:
        print(json.dumps(commit, indent=2, sort_keys=True, ensure_ascii=False))
    else:
        print(f"  {C.GREEN}Context Commit {commit['commit_id']} created.{C.RESET}")
        print(
            "  Selected: {selected}; omitted and recoverable: {omitted}; engine: {engine}".format(
                selected=verification.selected_chunks,
                omitted=verification.omitted_chunks,
                engine=commit["engine"]["implementation"],
            )
        )
        print(f"  JSON: {output}")
    return 0


def _proof_runtime_from_args(args):
    from entroly.proof_guided_runtime import ProofGuidedRuntime

    state_dir = (
        Path(args.state_dir).expanduser()
        if getattr(args, "state_dir", None)
        else _ENTROLY_DIR / "proof-guided"
    )
    return ProofGuidedRuntime(
        state_dir,
        context_risk_mode=(
            "audit" if getattr(args, "allow_high_risk", False) else "block_high"
        ),
        prefer_rust=not getattr(args, "python", False),
    )


def _proof_prepare(runtime, args):
    from entroly.context_receipts.ingest import (
        read_documents_from_path,
        supported_documents_hint,
    )

    documents = read_documents_from_path(args.path)
    if not documents:
        raise ValueError(
            f"no supported documents found in {args.path!r}; "
            f"{supported_documents_hint()}"
        )
    return runtime.prepare(
        documents,
        query=args.query,
        token_budget=args.budget,
        max_rounds=args.max_rounds,
        recovery_token_budget=args.recovery_budget,
        max_chunks_per_round=args.max_chunks_per_round,
        profile=args.profile,
        chunk_tokens=args.chunk_tokens,
        overlap_tokens=args.overlap_tokens,
        idempotency_key=args.idempotency_key,
    )


def _proof_model_output(args) -> str:
    if args.output is not None and args.output_file is not None:
        raise ValueError("use only one of --output or --output-file")
    if args.output is not None:
        return args.output
    if args.output_file is not None:
        return Path(args.output_file).read_text(encoding="utf-8")
    if sys.stdin.isatty():
        raise ValueError("provide --output, --output-file, or pipe model text on stdin")
    return sys.stdin.read()


def _run_explicit_model_command(command_text: str, request: dict, timeout: float) -> str:
    """Run an operator-supplied command without a shell or hidden credentials."""
    import shlex

    command = shlex.split(command_text, posix=os.name != "nt")
    if not command:
        raise ValueError("--model-command cannot be empty")
    completed = subprocess.run(
        command,
        input=json.dumps(request, ensure_ascii=False),
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    if completed.returncode != 0:
        diagnostic = " ".join(completed.stderr.split())[:400]
        raise RuntimeError(
            f"model command exited {completed.returncode}: "
            f"{diagnostic or 'no stderr was returned'}"
        )
    output = completed.stdout
    try:
        decoded = json.loads(output)
    except json.JSONDecodeError:
        decoded = None
    if isinstance(decoded, dict) and isinstance(decoded.get("output"), str):
        output = decoded["output"]
    if not output.strip():
        raise RuntimeError("model command returned an empty output")
    return output


def cmd_proof(args):
    """Run or advance the durable proof-guided context protocol."""
    runtime = _proof_runtime_from_args(args)
    if args.proof_action == "prepare":
        result = _proof_prepare(runtime, args)
    elif args.proof_action == "advance":
        result = runtime.advance(
            args.session_id,
            model_output=_proof_model_output(args),
            idempotency_key=args.idempotency_key,
        )
    elif args.proof_action == "inspect":
        result = runtime.inspect(args.session_id)
    elif args.proof_action == "run":
        result = _proof_prepare(runtime, args)
        while result["status"] == "awaiting_model":
            model_output = _run_explicit_model_command(
                args.model_command,
                result["request"],
                args.model_timeout,
            )
            result = runtime.advance(
                result["session_id"],
                model_output=model_output,
                idempotency_key=(
                    f"cli-round-{result['revision']}-"
                    f"{result['session_id']}"
                ),
            )
    else:  # pragma: no cover - argparse enforces the action
        raise ValueError(f"unknown proof action: {args.proof_action}")

    if args.proof_action == "run" and not args.json_output:
        if result.get("final_output"):
            print(result["final_output"])
        else:
            print(
                f"Proof-guided run stopped with status {result['status']}; "
                "inspect the JSON receipt with `entroly proof inspect`.",
                file=sys.stderr,
            )
        return 0 if result.get("converged") else 3
    print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


def _load_session_taint(path: str | None, chain_path: Path):
    from entroly.session_intelligence import HallucinationTaintTracker

    candidates: list[Path] = []
    if path:
        candidates.append(Path(path))
    else:
        candidates.extend([
            chain_path.with_name("session_taint.json"),
            chain_path.with_name("taint.json"),
        ])
    for candidate in candidates:
        if candidate.exists():
            return HallucinationTaintTracker.read_json(candidate)
    return None


def _session_budget_summary(chain, *, input_price_per_million: float = 0.0) -> dict:
    rows: list[dict] = []
    total_budget = None
    closing_reserve = None
    estimated_cost = 0.0
    consumed_tokens = 0
    for link in chain.links:
        decision = dict(link.budget_decision or {})
        allocated = max(0, int(decision.get("allocated_budget") or 0))
        token_budget = max(0, int(link.token_budget or 0))
        consumed = allocated or token_budget
        cost = (
            round((consumed / 1_000_000.0) * input_price_per_million, 6)
            if input_price_per_million > 0
            else 0.0
        )
        rows.append(
            {
                "turn_index": link.turn_index,
                "receipt_id": link.receipt_id,
                "query": link.query,
                "policy": str(decision.get("policy") or ""),
                "allocated_budget": allocated,
                "token_budget": token_budget,
                "consumed_tokens": consumed,
                "remaining_budget": max(0, int(decision.get("remaining_budget") or 0)),
                "reserved_closing_budget": max(
                    0,
                    int(decision.get("reserved_closing_budget") or 0),
                ),
                "reason": str(decision.get("reason") or ""),
                "estimated_input_cost_usd": cost,
            }
        )
        consumed_tokens += consumed
        estimated_cost += cost
        if not decision:
            continue
        if decision.get("total_budget") is not None:
            total_budget = int(decision["total_budget"])
        if decision.get("reserved_closing_budget") is not None:
            closing_reserve = int(decision["reserved_closing_budget"])
    peak_turn = None
    if rows:
        peak_turn = max(rows, key=lambda row: (row["consumed_tokens"], row["turn_index"]))
    return {
        "consumed_tokens": consumed_tokens,
        "total_budget": total_budget,
        "closing_reserve_tokens": closing_reserve,
        "estimated_input_cost_usd": round(estimated_cost, 6),
        "input_price_per_million": input_price_per_million,
        "peak_turn": peak_turn,
        "turns": rows,
    }


def _session_taint_summary(tracker) -> dict:
    if tracker is None:
        return {"entities": 0, "propagated_turns": 0, "suspects": []}
    suspects = [suspect.as_dict() for suspect in tracker.suspects.values()]
    suspects.sort(key=lambda item: (item["origin_turn"], item["entity"]))
    return {
        "entities": len(suspects),
        "propagated_turns": sum(
            len(item.get("propagated_turns", [])) for item in suspects
        ),
        "suspects": suspects,
    }


def _article_12_evidence_level(chain, integrity: dict, budget: dict) -> str:
    """Return the audit evidence completeness level, not a compliance verdict."""
    if not integrity.get("valid"):
        return "needs_review"
    links = list(chain.links)
    if not links:
        return "minimal"
    has_timestamp = any(getattr(link, "created_at", None) is not None for link in links)
    has_query = any(bool((getattr(link, "query", "") or "").strip()) for link in links)
    has_budget_decision = any(bool(row.get("policy")) for row in budget.get("turns", []))
    if has_timestamp and has_query and has_budget_decision:
        return "full"
    if has_timestamp and (has_query or has_budget_decision):
        return "partial"
    return "minimal"


def _format_session_audit(
    chain,
    tracker=None,
    *,
    json_output: bool = False,
    input_price_per_million: float = 0.0,
    max_turns: int = 20,
) -> str:
    integrity = chain.verify_integrity()
    budget = _session_budget_summary(
        chain,
        input_price_per_million=max(0.0, float(input_price_per_million or 0.0)),
    )
    taint = _session_taint_summary(tracker)
    chain_hash = chain.chain_hash()
    status = "VALID" if integrity["valid"] else "INVALID"
    evidence_level = _article_12_evidence_level(chain, integrity, budget)
    summary = {
        "session_id": chain.session_id,
        "turns": len(chain.links),
        "chain_integrity": status,
        "chain_hash": chain_hash,
        "integrity_issues": integrity["issues"],
        "budget": budget,
        "taint": taint,
        "article_12_logging_evidence": evidence_level,
    }
    if json_output:
        return json.dumps(summary, indent=2, sort_keys=True)

    budget_line = f"{budget['consumed_tokens']:,}"
    if budget["total_budget"] is not None:
        budget_line += f" / {budget['total_budget']:,}"
    else:
        budget_line += " tokens"
    if budget["closing_reserve_tokens"] is not None:
        budget_line += f" (closing reserve: {budget['closing_reserve_tokens']:,})"

    lines = [
        f"Session: {chain.session_id}",
        (
            f"Turns: {len(chain.links)}  |  Chain integrity: {status}  |  "
            f"Chain hash: {chain_hash}"
        ),
        (
            "Taint events: "
            f"{taint['entities']} entities, "
            f"{taint['propagated_turns']} propagated turn references"
        ),
        f"Budget consumed: {budget_line}",
        (
            "Article 12 logging evidence: "
            f"{summary['article_12_logging_evidence'].upper()}"
        ),
    ]
    if budget["estimated_input_cost_usd"] > 0:
        lines.append(
            "Estimated input cost: "
            f"${budget['estimated_input_cost_usd']:.6f} "
            f"@ ${budget['input_price_per_million']:.4f}/1M input tokens"
        )
    peak = budget.get("peak_turn")
    if peak:
        lines.append(
            "Budget hotspot: "
            f"turn {peak['turn_index']} used {peak['consumed_tokens']:,} tokens"
            + (f" for {peak['query']!r}" if peak.get("query") else "")
        )
    if integrity["issues"]:
        lines.append("")
        lines.append("Integrity issues:")
        lines.extend(f"- {issue}" for issue in integrity["issues"])

    if budget["turns"]:
        shown_turns = len(budget["turns"]) if int(max_turns) < 0 else max(0, int(max_turns))
        lines.append("")
        lines.append("Turn budget ledger:")
        for row in budget["turns"][:shown_turns]:
            query = row["query"] or "(no query recorded)"
            line = (
                f"- Turn {row['turn_index']}: {row['consumed_tokens']:,} tokens"
                f" | receipt {row['receipt_id']}"
            )
            if row["policy"]:
                line += f" | policy {row['policy']}"
            if row["estimated_input_cost_usd"] > 0:
                line += f" | est. ${row['estimated_input_cost_usd']:.6f}"
            line += f" | {query}"
            lines.append(line)
        remaining = len(budget["turns"]) - shown_turns
        if remaining > 0:
            lines.append(f"- ... {remaining} more turn(s). Re-run with --max-turns -1 for all.")

    if taint["suspects"]:
        lines.append("")
        lines.append("Context poisoning trail:")
        for suspect in taint["suspects"]:
            labels = ", ".join(suspect.get("labels", [])) or "flagged"
            lines.append(
                f"Turn {suspect['origin_turn']}  WITNESS flagged: "
                f"{suspect['entity']} (risk: {suspect['risk']:.2f}, "
                f"labels: {labels})"
            )
            propagated = suspect.get("propagated_turns", [])
            if propagated:
                turn_list = ", ".join(str(turn) for turn in propagated)
                lines.append(
                    f"Turns {turn_list}  -> propagation detected "
                    f"({len(propagated)} turn references)"
                )
    else:
        lines.append("")
        lines.append("No taint tracker evidence supplied or no suspect entities recorded.")

    return "\n".join(lines)


def cmd_audit(args):
    """entroly audit SESSION_CHAIN_JSON - render a session-chain audit report."""
    from entroly.session_intelligence import SessionReceiptChain

    chain_path = Path(args.session_chain)
    if not chain_path.exists():
        print(f"Session chain not found: {chain_path}", file=sys.stderr)
        return 1
    try:
        chain = SessionReceiptChain.read_json(chain_path)
    except json.JSONDecodeError as exc:
        print(
            f"Session chain is not valid JSON: {chain_path} "
            f"(line {exc.lineno}, column {exc.colno})",
            file=sys.stderr,
        )
        return 1
    except (KeyError, TypeError, ValueError) as exc:
        print(f"Session chain schema mismatch: {chain_path}: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"Could not read session chain: {chain_path}: {exc}", file=sys.stderr)
        return 1

    try:
        tracker = _load_session_taint(getattr(args, "taint", None), chain_path)
    except json.JSONDecodeError as exc:
        print(
            f"Taint tracker is not valid JSON "
            f"(line {exc.lineno}, column {exc.colno})",
            file=sys.stderr,
        )
        return 1
    except (KeyError, TypeError, ValueError) as exc:
        print(f"Taint tracker schema mismatch: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"Could not read taint tracker: {exc}", file=sys.stderr)
        return 1

    try:
        report = _format_session_audit(
            chain,
            tracker,
            json_output=bool(getattr(args, "json", False)),
            input_price_per_million=float(
                getattr(args, "input_price_per_million", 0.0) or 0.0
            ),
            max_turns=int(getattr(args, "max_turns", 20)),
        )
    except (KeyError, TypeError, ValueError) as exc:
        print(f"Could not format audit report: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"Unexpected audit formatting failure: {exc}", file=sys.stderr)
        return 1

    print(report)
    return 0


def cmd_explain(args):
    """entroly explain --why-omitted CHUNK_ID - explain an omitted receipt item."""
    from entroly.context_receipts import explain_omitted
    from entroly.context_receipts.store import latest_receipt_path, read_json

    receipt_path = Path(args.receipt) if args.receipt else latest_receipt_path()
    if receipt_path is None or not receipt_path.exists():
        print(
            f"  {C.RED}No receipt found.{C.RESET} Pass `--receipt receipt.json` or run `entroly select` first.",
            file=sys.stderr,
        )
        return 1
    print(explain_omitted(read_json(receipt_path), args.why_omitted, prefer_rust=not args.python))


def cmd_feedback(args):
    """entroly feedback — signal outcome quality to improve future context selection.

    After an agent completes a task using optimized context, run this to
    tell Entroly whether the context was helpful. Entroly uses this to
    adjust fragment relevance scores for future optimizations.
    """
    from entroly.server import EntrolyEngine

    score = getattr(args, "score", None)
    outcome = getattr(args, "outcome", None)
    if score is None and outcome is not None:
        score = {"success": 1.0, "good": 1.0,
                 "fail": 0.0, "failure": 0.0, "bad": 0.0,
                 "neutral": 0.5}.get(outcome)
    if score is None:
        print(f"  {C.RED}Provide --score (0.0-1.0) or --outcome (success|fail|neutral).{C.RESET}")
        return

    # Load the last optimization state
    state_file = Path.home() / ".entroly" / "last_optimize.json"
    if not state_file.exists():
        print(f"  {C.YELLOW}No previous optimization found.{C.RESET}")
        print(f"  Run {C.CYAN}entroly optimize --task \"...\" {C.RESET}first.")
        return

    try:
        with open(state_file) as f:
            state = json.load(f)
    except Exception:
        print(f"  {C.RED}Could not read last optimization state.{C.RESET}")
        return

    fragment_ids = state.get("fragment_ids", [])
    task = state.get("task", "")

    if not fragment_ids:
        print(f"  {C.YELLOW}No fragments to provide feedback for.{C.RESET}")
        return

    engine = EntrolyEngine()

    if score >= 0.7:
        engine.record_success(fragment_ids)
        icon = f"{C.GREEN}✓{C.RESET}"
        label = "positive"
    elif score <= 0.3:
        engine.record_failure(fragment_ids)
        icon = f"{C.RED}✗{C.RESET}"
        label = "negative"
    else:
        engine.record_reward(fragment_ids, score - 0.5)
        icon = f"{C.YELLOW}~{C.RESET}"
        label = "neutral"

    print(f"\n  {icon} Recorded {label} feedback (score={score:.1f}) for {len(fragment_ids)} fragments")
    if task:
        print(f"  Task: {C.GRAY}{task}{C.RESET}")
    print(f"  {C.GRAY}Entroly will adjust future context selections based on this signal.{C.RESET}\n")


_EXIT_REASON_OPTIONS = (
    ("no_observed_benefit", "I did not observe enough benefit"),
    ("install_problem", "Installation or upgrade problem"),
    ("runtime_error", "Runtime errors or crashes"),
    ("performance_problem", "Too slow or resource intensive"),
    ("quality_problem", "Output quality or missing context"),
    ("hard_to_use", "Setup or workflow was too difficult"),
    ("integration_missing", "My tool or integration was missing"),
    ("privacy_concern", "Privacy or security concern"),
    ("cost_concern", "Cost concern"),
    ("switched_tool", "Switched to another approach"),
    ("temporary_trial", "Trial complete or temporary removal"),
    ("other", "Another structured reason"),
    ("prefer_not_to_say", "Prefer not to say"),
)
_EXIT_BENEFIT_OPTIONS = (
    ("yes", "Yes, I observed useful token reduction"),
    ("no", "No, I did not observe useful token reduction"),
    ("unsure", "Unsure"),
    ("not_measured", "I did not measure it"),
)
_EXIT_SURFACE_OPTIONS = (
    ("cli", "CLI"),
    ("mcp", "MCP server"),
    ("compression_mcp", "Compression MCP"),
    ("repository_mcp", "Repository intelligence MCP"),
    ("proxy", "Provider proxy"),
    ("sdk_compress", "Python SDK compression"),
    ("sdk_messages", "Python SDK message compression"),
    ("other", "Other or not started"),
)
_EXIT_DURATION_OPTIONS = (
    ("not_started", "I could not get started"),
    ("lt_1d", "Less than one day"),
    ("1_7d", "1 to 7 days"),
    ("8_30d", "8 to 30 days"),
    ("31_90d", "31 to 90 days"),
    ("gt_90d", "More than 90 days"),
    ("unknown", "Unsure"),
)


def _prompt_exit_option(
    title: str,
    options: tuple[tuple[str, str], ...],
    *,
    default: str,
) -> str:
    print(f"\n  {C.BOLD}{title}{C.RESET}")
    for index, (_value, label) in enumerate(options, 1):
        print(f"    {index:>2}. {label}")
    while True:
        try:
            raw = input(f"  Select 1-{len(options)} (Enter to skip): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return default
        if not raw:
            return default
        try:
            selected = int(raw)
        except ValueError:
            selected = 0
        if 1 <= selected <= len(options):
            return options[selected - 1][0]
        print(f"  {C.YELLOW}Please enter a number from 1 to {len(options)}.{C.RESET}")


def _confirm_exit_feedback(destination: str) -> bool:
    try:
        answer = input(
            f"\n  Send this one-time structured response to {destination}? [y/N]: "
        ).strip().casefold()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return answer in {"y", "yes"}


def cmd_uninstall(args):
    """Guided Python uninstall with an optional content-blind exit survey."""
    from urllib.parse import urlsplit

    from entroly.product_telemetry import (
        disable_and_purge,
        resolve_exit_feedback_endpoint,
        submit_exit_feedback,
        validate_endpoint,
    )

    explicit_endpoint = getattr(args, "endpoint", None)
    if explicit_endpoint:
        try:
            explicit_endpoint = validate_endpoint(explicit_endpoint)
        except ValueError as error:
            print(f"  {C.RED}Invalid feedback endpoint:{C.RESET} {error}", file=sys.stderr)
            return 2

    dry_run = bool(getattr(args, "dry_run", False))
    feedback_only = bool(getattr(args, "feedback_only", False))
    skip_feedback = bool(getattr(args, "skip_feedback", False))
    interactive = bool(getattr(sys.stdin, "isatty", lambda: False)())
    reason = getattr(args, "reason", None)
    benefit = getattr(args, "benefit", None)
    surface = getattr(args, "surface", None)
    duration = getattr(args, "duration", None)

    if not skip_feedback:
        print(f"\n{C.CYAN}{C.BOLD}  Entroly exit survey (optional){C.RESET}")
        print(
            f"  {C.GRAY}No free text is requested. The response contains only four "
            f"choices plus release, OS family, Python major.minor, UTC day, and a "
            f"rotating or one-event pseudonym.{C.RESET}"
        )
        if interactive:
            reason = reason or _prompt_exit_option(
                "Why are you uninstalling?",
                _EXIT_REASON_OPTIONS,
                default="prefer_not_to_say",
            )
            benefit = benefit or _prompt_exit_option(
                "Did Entroly provide useful token reduction?",
                _EXIT_BENEFIT_OPTIONS,
                default="not_measured",
            )
            surface = surface or _prompt_exit_option(
                "What was your primary Entroly surface?",
                _EXIT_SURFACE_OPTIONS,
                default="other",
            )
            duration = duration or _prompt_exit_option(
                "How long did you use Entroly?",
                _EXIT_DURATION_OPTIONS,
                default="unknown",
            )
        elif not all((reason, benefit, surface, duration)):
            print(
                f"  {C.GRAY}Non-interactive session: no survey response collected. "
                f"Supply all structured flags or use --skip-feedback.{C.RESET}"
            )

    complete_feedback = bool(
        not skip_feedback and all((reason, benefit, surface, duration))
    )
    endpoint = resolve_exit_feedback_endpoint(explicit_endpoint)
    send_feedback = bool(getattr(args, "send_feedback", False))
    destination = "no collector configured"
    if endpoint:
        parsed = urlsplit(endpoint)
        destination = f"{parsed.scheme}://{parsed.netloc}"

    if complete_feedback:
        fields = {
            "reason": reason,
            "benefit_outcome": benefit,
            "primary_surface": surface,
            "use_duration_bucket": duration,
        }
        print(f"\n  Structured response: {json.dumps(fields, sort_keys=True)}")
        print(f"  Destination: {destination}")
        if interactive and not send_feedback and endpoint and not dry_run:
            send_feedback = _confirm_exit_feedback(destination)

    uninstall_command = [sys.executable, "-m", "pip", "uninstall", "entroly"]
    if bool(getattr(args, "yes", False)):
        uninstall_command.append("-y")
    if feedback_only:
        print("\n  Feedback-only mode: the package will not be uninstalled.")
    else:
        print(f"\n  Uninstall command: {subprocess.list2cmdline(uninstall_command)}")
    if dry_run:
        print(f"  {C.GRAY}Dry run: feedback was not sent and nothing was uninstalled.{C.RESET}")
        return 0

    delete_remote = bool(getattr(args, "delete_remote_telemetry", False))
    if delete_remote:
        deletion = disable_and_purge(delete_remote=True)
        if deletion.get("remote_deletion") not in {"deleted", "not_configured"}:
            print(
                f"  {C.YELLOW}Previously uploaded telemetry deletion could not be "
                f"confirmed; collector retention still applies.{C.RESET}"
            )

    if send_feedback and complete_feedback:
        report = submit_exit_feedback(
            reason=str(reason),
            benefit_outcome=str(benefit),
            primary_surface=str(surface),
            use_duration_bucket=str(duration),
            endpoint=endpoint,
        )
        if report["status"] == "sent":
            print(f"  {C.GREEN}One structured exit response sent.{C.RESET}")
        elif report["status"] == "not_configured":
            print(f"  {C.YELLOW}Feedback not sent: no collector is configured.{C.RESET}")
        else:
            print(
                f"  {C.YELLOW}Feedback not sent ({report['status']}); uninstall will "
                f"continue and no response was queued locally.{C.RESET}"
            )
    elif send_feedback and not complete_feedback:
        print(f"  {C.YELLOW}Feedback not sent: all structured fields are required.{C.RESET}")
    else:
        print(f"  {C.GRAY}No exit feedback was sent.{C.RESET}")

    if not delete_remote:
        # Reinstallation must require fresh consent. Historical aggregates age
        # out under collector retention unless the user requested deletion.
        disable_and_purge(delete_remote=False)

    if feedback_only:
        return 0

    completed = subprocess.run(uninstall_command, check=False)
    return int(completed.returncode)


def cmd_compile(args):
    """entroly compile -- compile source code into persistent belief artifacts.

    Scans a directory for source files, extracts code entities, resolves
    dependencies, and writes belief artifacts to the vault. This is the
    foundation of Cross-Session Memory: compile once, start warm forever.
    """
    import os

    from entroly.belief_compiler import BeliefCompiler
    from entroly.vault import VaultConfig, VaultManager

    target = getattr(args, "directory", None) or os.getcwd()
    max_files = getattr(args, "max_files", 0)

    vault_base = os.environ.get(
        "ENTROLY_VAULT",
        os.path.join(os.environ.get("ENTROLY_DIR", os.path.join(os.getcwd(), ".entroly")), "vault"),
    )
    vault = VaultManager(VaultConfig(base_path=vault_base))
    vault.ensure_structure()
    compiler = BeliefCompiler(vault)

    print(f"\n  {C.CYAN}{C.BOLD}Compiling Beliefs{C.RESET}")
    print(f"  {C.GRAY}Source:  {target}{C.RESET}")
    print(f"  {C.GRAY}Vault:   {vault_base}{C.RESET}")
    cap_desc = "unlimited" if max_files <= 0 else str(max_files)
    print(f"  {C.GRAY}Max files: {cap_desc}{C.RESET}\n")

    result = compiler.compile_directory(target, max_files)
    if max_files > 0 and result.files_processed >= max_files:
        print(f"  {C.YELLOW}! Hit --max-files cap ({max_files}); some files not indexed. "
              f"Re-run with --max-files 0 for unlimited.{C.RESET}")

    print(f"  {C.GREEN}Files processed:{C.RESET}    {result.files_processed}")
    print(f"  {C.GREEN}Entities extracted:{C.RESET} {result.entities_extracted}")
    print(f"  {C.GREEN}Beliefs written:{C.RESET}    {result.beliefs_written}")
    if result.errors:
        print(f"  {C.YELLOW}Errors:{C.RESET}             {len(result.errors)}")
        for e in result.errors[:5]:
            print(f"    {C.GRAY}- {e}{C.RESET}")

    coverage = vault.coverage_index()
    print(f"\n  {C.CYAN}Vault coverage:{C.RESET} {coverage['total_beliefs']} beliefs")
    print(f"  {C.CYAN}Avg confidence:{C.RESET} {coverage['average_confidence']:.2f}")
    print(f"\n  {C.GREEN}Beliefs persisted.{C.RESET} Next session starts warm.\n")


def cmd_verify_code(args):
    """entroly verify-code -- statically verify LLM-generated code against
    your codebase's symbol manifest.

    Wraps the verifier CLI in entroly/verifiers/cli.py — it loads (or
    builds and caches) a SymbolVerifier from the local repo, then runs
    Bayesian-symbol + n-gram surprisal scoring on the provided source.

    Exit codes (returned to the shell):
        0 — passes verification (H-score below threshold)
        1 — fails (H-score >= threshold) — useful for CI gating
        2 — usage error
    """
    from entroly.verifiers.cli import main as _verifier_main

    forwarded = list(getattr(args, "verify_code_args", None) or [])
    sys.exit(_verifier_main(forwarded))


def cmd_verify(args):
    """entroly verify -- run verification pass on all beliefs.

    Checks for staleness, contradictions, confidence divergence. Writes
    verification artifacts to vault/verification/. This promotes beliefs
    from 'inferred' to 'verified' or flags them as 'stale'.
    """
    import os

    from entroly.vault import VaultConfig, VaultManager
    from entroly.verification_engine import VerificationEngine

    vault_base = os.environ.get(
        "ENTROLY_VAULT",
        os.path.join(os.environ.get("ENTROLY_DIR", os.path.join(os.getcwd(), ".entroly")), "vault"),
    )
    vault = VaultManager(VaultConfig(base_path=vault_base))
    vault.ensure_structure()
    verifier = VerificationEngine(vault, freshness_hours=24.0, min_confidence=0.5)

    print(f"\n  {C.CYAN}{C.BOLD}Verifying Beliefs{C.RESET}")
    print(f"  {C.GRAY}Vault: {vault_base}{C.RESET}\n")

    report = verifier.full_verification_pass()
    rd = report.to_dict()

    print(f"  {C.GREEN}Beliefs checked:{C.RESET}     {rd.get('total_beliefs_checked', 0)}")
    print(f"  {C.GREEN}Stale:{C.RESET}               {rd.get('stale_count', 0)}")
    print(f"  {C.GREEN}Contradictions:{C.RESET}      {rd.get('contradiction_count', 0)}")
    print(f"  {C.GREEN}Low confidence:{C.RESET}      {rd.get('low_confidence_count', 0)}")

    stale = rd.get("stale", [])
    if stale:
        print(f"\n  {C.YELLOW}Stale beliefs:{C.RESET}")
        for s in stale[:10]:
            ent = s.get("entity", "unknown") if isinstance(s, dict) else str(s)
            print(f"    - {ent}")

    print(f"\n  {C.GREEN}Verification artifacts written to vault/verification/{C.RESET}\n")


def cmd_verify_claims(args):
    """entroly verify-claims -- packaged new-user smoke verifier."""
    from entroly.verify_claims import run as _run_verify_claims

    raise SystemExit(
        _run_verify_claims(
            output=getattr(args, "output", None),
            max_files=getattr(args, "max_files", 120),
        )
    )


def cmd_sync(args):
    """entroly sync -- detect workspace changes and update beliefs.

    Scans for new/modified/deleted files since last sync, marks affected
    beliefs stale, recompiles changed files, and runs verification.
    This is the Change-Driven Pipeline (Flow 4).
    """
    import os

    from entroly.belief_compiler import BeliefCompiler
    from entroly.change_listener import WorkspaceChangeListener
    from entroly.change_pipeline import ChangePipeline
    from entroly.vault import VaultConfig, VaultManager
    from entroly.verification_engine import VerificationEngine

    target = getattr(args, "directory", None) or os.getcwd()
    max_files = getattr(args, "max_files", 100)
    force = getattr(args, "force", False)

    vault_base = os.environ.get(
        "ENTROLY_VAULT",
        os.path.join(os.environ.get("ENTROLY_DIR", os.path.join(os.getcwd(), ".entroly")), "vault"),
    )
    vault = VaultManager(VaultConfig(base_path=vault_base))
    vault.ensure_structure()
    compiler = BeliefCompiler(vault)
    verifier = VerificationEngine(vault, freshness_hours=24.0, min_confidence=0.5)
    change_pipe = ChangePipeline(vault, verifier)

    listener = WorkspaceChangeListener(
        vault=vault, compiler=compiler, verifier=verifier,
        change_pipe=change_pipe, project_dir=target,
    )

    print(f"\n  {C.CYAN}{C.BOLD}Syncing Workspace{C.RESET}")
    print(f"  {C.GRAY}Source: {target}{C.RESET}")
    print(f"  {C.GRAY}Vault:  {vault_base}{C.RESET}\n")

    result = listener.scan_once(force=force, max_files=max_files)
    rd = result.to_dict()

    print(f"  {C.GREEN}Files scanned:{C.RESET}    {rd.get('scanned_files', 0)}")
    print(f"  {C.GREEN}Files changed:{C.RESET}    {len(rd.get('changed_files', []))}")
    print(f"  {C.GREEN}Beliefs written:{C.RESET}  {rd.get('beliefs_written', 0)}")
    print(f"  {C.GREEN}Beliefs staled:{C.RESET}   {len(rd.get('refresh_result', {}).get('updated_entities', []))}")
    print(f"\n  {C.GREEN}Workspace synchronized.{C.RESET}\n")


def cmd_search(args):
    """entroly search -- full-text TF-IDF search across vault beliefs.

    Uses the Rust search engine with entity-name boosting (3x), title
    boosting (2x), and body TF-IDF scoring. Returns ranked results
    with excerpts — far cheaper than dumping all beliefs.
    """
    import os

    query = " ".join(args.query)
    top_k = args.top_k

    vault_base = os.environ.get(
        "ENTROLY_VAULT",
        os.path.join(os.environ.get("ENTROLY_DIR", os.path.join(os.getcwd(), ".entroly")), "vault"),
    )

    print(f"\n  {C.CYAN}{C.BOLD}Vault Search{C.RESET}")
    print(f"  {C.GRAY}Query: {query}{C.RESET}")
    print(f"  {C.GRAY}Vault: {vault_base}{C.RESET}\n")

    try:
        from entroly_core import CogOpsEngine
        engine = CogOpsEngine(vault_base)
        results = engine.vault_search(query, top_k)
        engine_name = "rust"
    except ImportError:
        # Python fallback — simple substring
        from pathlib import Path

        from entroly.vault import VaultConfig, VaultManager, _parse_frontmatter
        vault = VaultManager(VaultConfig(base_path=vault_base))
        vault.ensure_structure()
        beliefs_dir = Path(vault_base) / "beliefs"
        query_lower = query.lower()
        results = []
        for md in sorted(beliefs_dir.rglob("*.md")):
            content = md.read_text(encoding="utf-8", errors="replace")
            if query_lower in content.lower():
                fm = _parse_frontmatter(content) or {}
                results.append({
                    "entity": fm.get("entity", md.stem),
                    "confidence": float(fm.get("confidence", 0)),
                    "status": fm.get("status", ""),
                    "excerpt": "",
                    "score": 1.0,
                })
        results = results[:top_k]
        engine_name = "python"

    if not results:
        print(f"  {C.YELLOW}No results found.{C.RESET}\n")
        return

    for i, r in enumerate(results, 1):
        entity = r.get("entity", r.get("entity", "?"))
        score = r.get("score", 0)
        conf = r.get("confidence", 0)
        status = r.get("status", "?")
        excerpt = r.get("excerpt", "")
        print(f"  {C.BOLD}{i}. {entity}{C.RESET}  (score={score:.2f}  conf={conf:.2f}  status={status})")
        if excerpt:
            for line in excerpt.split("\n")[:3]:
                print(f"     {C.GRAY}{line}{C.RESET}")
        print()

    print(f"  {C.GRAY}{len(results)} results ({engine_name} engine){C.RESET}\n")


def cmd_docs(args):
    """entroly docs -- compile markdown documentation into belief artifacts.

    Ingests README.md, ARCHITECTURE.md, docs/, CONTRIBUTING.md etc. into
    the vault as documentation beliefs with confidence 0.80 (human-authored
    context ranks higher than machine-inferred code beliefs).
    """
    import os

    target = args.directory or os.getcwd()
    max_files = args.max_files
    # CLI documents --max-files 0 as "unlimited", but the Rust
    # CogOpsEngine.compile_docs does `Vec::truncate(max_files)` which
    # empties the list when max_files == 0. Translate the documented
    # sentinel into a high cap here so `entroly docs .` (no args)
    # actually finds the README on a real repo.
    if max_files is None or max_files <= 0:
        max_files = 1_000_000
    vault_base = os.environ.get(
        "ENTROLY_VAULT",
        os.path.join(os.environ.get("ENTROLY_DIR", os.path.join(os.getcwd(), ".entroly")), "vault"),
    )

    print(f"\n  {C.CYAN}{C.BOLD}Compiling Documentation{C.RESET}")
    print(f"  {C.GRAY}Source: {target}{C.RESET}")
    print(f"  {C.GRAY}Vault:  {vault_base}{C.RESET}\n")

    try:
        from entroly_core import CogOpsEngine
        engine = CogOpsEngine(vault_base)
        result = engine.compile_docs(target, max_files)
    except ImportError:
        print(f"  {C.RED}entroly_core not installed — docs compilation requires the Rust engine.{C.RESET}")
        print(f"  {C.GRAY}Install with: python -m pip install -U \"entroly-core>=1.0.78\"{C.RESET}\n")
        return

    print(f"  {C.GREEN}Docs found:{C.RESET}      {result.get('docs_found', 0)}")
    print(f"  {C.GREEN}Docs compiled:{C.RESET}   {result.get('docs_compiled', 0)}")
    entities = result.get("entities", [])
    if entities:
        print(f"  {C.GREEN}Entities:{C.RESET}")
        for e in entities:
            print(f"    {C.GRAY}- {e}{C.RESET}")
    print(f"\n  {C.GREEN}Documentation beliefs persisted.{C.RESET}\n")


def cmd_finetune(args):
    """entroly finetune -- export vault beliefs as JSONL training data.

    Generates instruction-following Q&A pairs from compiled beliefs for
    LLM finetuning. Filters by PRISM 5D scoring: only beliefs with
    confidence >= 0.5 and non-stale status are included. Output is
    OpenAI-compatible JSONL format.

    After finetuning, the model "knows" the codebase in its weights —
    zero tokens needed for context. The ultimate compression.
    """
    import os

    output = args.output
    vault_base = os.environ.get(
        "ENTROLY_VAULT",
        os.path.join(os.environ.get("ENTROLY_DIR", os.path.join(os.getcwd(), ".entroly")), "vault"),
    )

    print(f"\n  {C.CYAN}{C.BOLD}Exporting Training Data{C.RESET}")
    print(f"  {C.GRAY}Vault:  {vault_base}{C.RESET}")
    print(f"  {C.GRAY}Output: {output}{C.RESET}")
    print(f"  {C.GRAY}Filter: PRISM 5D (confidence >= 0.5, non-stale){C.RESET}\n")

    try:
        from entroly_core import CogOpsEngine
        engine = CogOpsEngine(vault_base)
        result = engine.export_training_data(output, "jsonl")
    except ImportError:
        print(f"  {C.RED}entroly_core not installed — training export requires the Rust engine.{C.RESET}")
        print(f"  {C.GRAY}Install with: python -m pip install -U \"entroly-core>=1.0.78\"{C.RESET}\n")
        return

    print(f"  {C.GREEN}Beliefs used:{C.RESET}     {result.get('beliefs_used', 0)}")
    print(f"  {C.GREEN}Beliefs skipped:{C.RESET}  {result.get('beliefs_skipped', 0)} (low confidence / stale)")
    print(f"  {C.GREEN}Training pairs:{C.RESET}   {result.get('training_pairs', 0)}")
    print(f"  {C.GREEN}Approx tokens:{C.RESET}    {result.get('total_tokens_approx', 0):,}")
    if result.get("training_pairs", 0) == 0:
        print(f"\n  {C.YELLOW}No training pairs written.{C.RESET} Run {C.CYAN}entroly compile{C.RESET} first to populate the vault.\n")
        return
    print(f"\n  {C.GREEN}Training data exported.{C.RESET}")
    print(f"  {C.GRAY}Use with: openai api fine_tuning.jobs.create -t {output}{C.RESET}\n")


def _read_witness_text(value: str | None, file_path: str | None, *, stdin_fallback: bool = False) -> str:
    if file_path:
        return Path(file_path).read_text(encoding="utf-8")
    if value:
        return value
    if stdin_fallback and not sys.stdin.isatty():
        return sys.stdin.read()
    return ""


def cmd_witness(args):
    """entroly witness — verify and optionally suppress factual claims."""
    from entroly.witness import WitnessAnalyzer, format_witness_report

    context = _read_witness_text(args.context, args.context_file)
    output = _read_witness_text(args.output, args.output_file, stdin_fallback=True)
    if not output.strip():
        print(
            f"{C.RED}Error:{C.RESET} provide model output via --output, --output-file, or stdin",
            file=sys.stderr,
        )
        return 1

    analyzer = WitnessAnalyzer(use_nli=args.nli, profile=args.profile)
    result, rewrite = analyzer.analyze_and_rewrite(context, output, mode=args.mode)

    if args.json_output:
        print(json.dumps({
            "witness": result.as_dict(),
            "policy": rewrite.as_dict(),
            "output": rewrite.output,
        }, indent=2))
        return

    if args.mode in {"annotate", "strict"} and rewrite.changed:
        print(rewrite.output)
        print()
        print(f"{C.GRAY}{format_witness_report(result)}{C.RESET}", file=sys.stderr)
    else:
        print(format_witness_report(result))


def cmd_cache(args):
    """entroly cache stats — Inspect the EGSC persistent cache.

    Surfaces the cross-session cache that already ships:
      EgscCache → CacheSnapshot → engine state → ~/.entroly/checkpoints/.
    Reports current entries, hit rate, tokens saved, the warm-start
    restore count, and the on-disk checkpoint footprint.
    """
    action = getattr(args, "cache_action", "stats") or "stats"
    if action != "stats":
        print(f"  {C.YELLOW}Usage: entroly cache stats{C.RESET}")
        return

    import time as _time
    try:
        from entroly.config import _project_checkpoint_dir
        ckpt_dir = _project_checkpoint_dir()
    except Exception:
        ckpt_dir = Path.home() / ".entroly" / "checkpoints"

    # On-disk footprint + freshness of the latest checkpoint
    ckpts: list[Path] = []
    if ckpt_dir.exists():
        ckpts = sorted(ckpt_dir.glob("ckpt_*.json.gz"))
    latest_mtime = max((p.stat().st_mtime for p in ckpts), default=0.0)
    total_bytes = sum((p.stat().st_size for p in ckpts), 0)
    if (ckpt_dir / "index.json.gz").exists():
        total_bytes += (ckpt_dir / "index.json.gz").stat().st_size

    # Live cache stats — construct the same engine wrapper the proxy uses
    # and call resume() to load the latest checkpoint (which folds the
    # CacheSnapshot back into EgscCache via engine.import_state).
    cache_stats: dict = {}
    warm_restored = 0
    try:
        from entroly.server import EntrolyEngine
        engine = EntrolyEngine()
        try:
            engine.resume()
        except Exception:
            pass
        rust = getattr(engine, "_rust", None)
        stats = rust.stats() if rust is not None and hasattr(rust, "stats") else {}
        cache_stats = stats.get("cache", {}) if isinstance(stats, dict) else {}
        warm_restored = int(cache_stats.get("entries", 0))
    except Exception as e:
        print(f"  {C.GRAY}(live engine stats unavailable: {e}){C.RESET}")

    age_s = (_time.time() - latest_mtime) if latest_mtime else 0.0
    age_str = (
        f"{int(age_s)}s" if age_s < 90
        else f"{age_s/60:.1f}m" if age_s < 3600
        else f"{age_s/3600:.1f}h"
    )

    print(f"  {C.BOLD}EGSC Persistent Cache{C.RESET}")
    print(f"  {C.GRAY}checkpoint dir:{C.RESET} {ckpt_dir}")
    print(f"  {C.GRAY}checkpoint files:{C.RESET} {len(ckpts)}  "
          f"({total_bytes/1024:.1f} KiB on disk)")
    print(f"  {C.GRAY}latest checkpoint age:{C.RESET} "
          f"{age_str if latest_mtime else 'never'}")
    print()
    print(f"  {C.BOLD}Live cache{C.RESET}")
    if cache_stats:
        print(f"  {C.GRAY}entries:{C.RESET}          {cache_stats.get('entries', 0)}")
        print(f"  {C.GRAY}warm-restored:{C.RESET}    {warm_restored}")
        print(f"  {C.GRAY}lookups:{C.RESET}          {cache_stats.get('lookups', 0)}")
        print(f"  {C.GRAY}hit rate:{C.RESET}         "
              f"{float(cache_stats.get('hit_rate', 0.0))*100:.1f}%")
        print(f"  {C.GRAY}exact hits:{C.RESET}       {cache_stats.get('exact_hits', 0)}")
        print(f"  {C.GRAY}semantic hits:{C.RESET}    {cache_stats.get('semantic_hits', 0)}")
        print(f"  {C.GRAY}misses:{C.RESET}           {cache_stats.get('misses', 0)}")
        print(f"  {C.GRAY}tokens saved:{C.RESET}     {cache_stats.get('tokens_saved', 0)}")
        print(f"  {C.GRAY}admissions:{C.RESET}       {cache_stats.get('admissions', 0)}")
        print(f"  {C.GRAY}rejections:{C.RESET}       {cache_stats.get('rejections', 0)}")
        print(f"  {C.GRAY}evictions:{C.RESET}        {cache_stats.get('evictions', 0)}")
    else:
        print(f"  {C.GRAY}(engine not yet initialized — run "
              f"`entroly proxy` or `entroly serve` first){C.RESET}")


def cmd_ravs(args):
    """entroly ravs — RAVS offline evaluation + passive capture tools.

    Subcommands:
      report  Read the JSONL event log, recompute labels from outcome events,
              and print the primary evaluation report. Same input log always
              produces byte-stable JSON output. Malformed lines are counted
              and skipped, not fatal. Empty logs produce a valid zero report.
              Weak labels only affect metrics with --include-weak. Shadow
              metrics are labeled as estimates/agreement, not regret truth.
    """
    import time as _time

    from entroly.ravs.report import generate_report, format_report_text

    ravs_action = getattr(args, "ravs_action", None)

    if ravs_action == "capture":
        from entroly.ravs.capture import capture_from_stdin, capture_from_args
        quiet = getattr(args, "quiet", False)
        log_path = getattr(args, "log", None)
        use_stdin = getattr(args, "stdin", False)
        if use_stdin:
            result = capture_from_stdin(log_path=log_path)
        else:
            command = getattr(args, "capture_command", None)
            exit_code = getattr(args, "exit_code", None)
            if command is None or exit_code is None:
                if not quiet:
                    print(f"  {C.RED}--stdin or both --command and --exit-code required{C.RESET}")
                return
            result = capture_from_args(
                command=command,
                exit_code=exit_code,
                stdout_tail=getattr(args, "stdout_text", "") or "",
                log_path=log_path,
            )
        if not quiet:
            if result:
                print(f"  \u2713 Captured: {result.get('tool')} \u2192 {result.get('event_type')}/{result.get('value')}")
            else:
                print("  \u00b7 Skipped: not a verifiable command")
        return

    if ravs_action == "hook":
        hook_action = getattr(args, "hook_action", None)
        if hook_action != "install":
            print(f"  {C.YELLOW}Usage: entroly ravs hook install --claude-code [--dry-run]{C.RESET}")
            return
        if not getattr(args, "claude_code", False):
            print(f"  {C.YELLOW}Specify a target: --claude-code{C.RESET}")
            return
        from entroly.ravs.hooks import install_claude_code
        result = install_claude_code(dry_run=getattr(args, "dry_run", False))
        action = result.get("action")
        path = result.get("path", "")
        if action == "installed":
            print(f"  {C.GREEN}\u2713 Installed RAVS PostToolUse hook \u2192 {path}{C.RESET}")
            print(f"  {C.GRAY}Restart Claude Code to activate. Every Bash tool use now feeds RAVS.{C.RESET}")
        elif action == "already_present":
            print(f"  {C.GRAY}\u00b7 Hook already present in {path}{C.RESET}")
        elif action == "dry_run":
            import json as _json
            print(f"  {C.CYAN}Dry-run \u2014 would write to {path}:{C.RESET}")
            print(_json.dumps(result.get("settings", {}), indent=2))
        else:
            print(f"  {C.RED}\u2717 Unknown action: {action}{C.RESET}")
        return

    if ravs_action != "report":
        print(f"  {C.YELLOW}Usage: entroly ravs [report|capture|hook]{C.RESET}")
        return

    # Resolve log path
    log_path = getattr(args, "log", None)
    if not log_path:
        log_path = str(Path.home() / ".entroly" / "ravs" / "events.jsonl")

    # Parse --since
    since_ts: float | None = None
    since_raw = getattr(args, "since", None)
    if since_raw:
        since_raw = since_raw.strip().lower()
        now = _time.time()
        if since_raw.endswith("d"):
            try:
                days = float(since_raw[:-1])
                since_ts = now - (days * 86400)
            except ValueError:
                print(f"  {C.RED}Invalid --since value: {since_raw} (use e.g. 7d, 30d){C.RESET}")
                return
        elif since_raw.endswith("h"):
            try:
                hours = float(since_raw[:-1])
                since_ts = now - (hours * 3600)
            except ValueError:
                print(f"  {C.RED}Invalid --since value: {since_raw} (use e.g. 24h, 48h){C.RESET}")
                return
        else:
            try:
                since_ts = float(since_raw)
            except ValueError:
                print(f"  {C.RED}Invalid --since value: {since_raw} (use e.g. 7d, 24h, or a Unix timestamp){C.RESET}")
                return

    include_weak = getattr(args, "include_weak", False)
    output_format = getattr(args, "format", "text")

    # Check log exists
    if not Path(log_path).exists():
        if output_format == "json":
            report = generate_report(log_path, include_weak=include_weak, since_timestamp=since_ts)
            print(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False))
        else:
            print(f"\n  {C.YELLOW}No RAVS event log found at: {log_path}{C.RESET}")
            print(f"  {C.GRAY}Events are logged automatically when the proxy or MCP server")
            print(f"  processes requests. Start a session first, then re-run this report.{C.RESET}\n")
            # Still produce a valid zero report
            report = generate_report(log_path, include_weak=include_weak, since_timestamp=since_ts)
            print(format_report_text(report))
        return

    # Generate report
    report = generate_report(log_path, include_weak=include_weak, since_timestamp=since_ts)

    if output_format == "json":
        print(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False))
    else:
        print(format_report_text(report))


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="entroly",
        description="\u26a1 Entroly \u2014 Information-theoretic context optimization for AI coding agents",
    )
    parser.add_argument(
        "--version", "-V", action="version",
        version=f"entroly {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command")

    # entroly init
    init_parser = subparsers.add_parser(
        "init",
        help="Auto-detect project + AI tool, generate MCP config",
    )
    init_parser.add_argument(
        "--dry-run", action="store_true",
        help="Show what would be generated without writing files",
    )
    init_parser.add_argument(
        "--yes", "-y", action="store_true",
        help="Non-interactive mode; accept defaults (no-op today; reserved for future prompts)",
    )

    # entroly serve
    serve_parser = subparsers.add_parser(
        "serve",
        help="Start the MCP server with auto-indexing",
    )
    serve_parser.add_argument(
        "--debug", action="store_true",
        help="Enable debug-level logging (all subsystem details to stderr)",
    )

    # entroly attach
    attach_parser = subparsers.add_parser(
        "attach",
        help="Grant scoped, expiring MCP access to an existing agent client",
    )
    attach_subparsers = attach_parser.add_subparsers(dest="attach_action", required=True)
    attach_create = attach_subparsers.add_parser("create", help="Create a local attachment grant")
    attach_create.add_argument("--client", choices=["claude", "codex", "openclaw"], required=True)
    attach_create.add_argument("--project", default=".", help="Project root bound to the grant")
    attach_create.add_argument("--session", default=None, help="Optional client session label")
    attach_create.add_argument("--ttl", default="1h", help="Grant lifetime, for example 30m or 4h")
    attach_create.add_argument(
        "--scope",
        action="append",
        default=[],
        choices=["observe", "context", "receipts", "verify", "remember", "record", "vault"],
        help="Allowed tool group; repeat to combine groups",
    )
    attach_create.add_argument("--install", action="store_true", help="Run the client MCP configuration command")
    attach_create.add_argument("--json", dest="json_output", action="store_true")
    attach_create.add_argument("--state-dir", default=None, help=argparse.SUPPRESS)
    attach_list = attach_subparsers.add_parser("list", help="List attachment grants")
    attach_list.add_argument("--all", action="store_true", help="Include expired and revoked grants")
    attach_list.add_argument("--json", dest="json_output", action="store_true")
    attach_list.add_argument("--state-dir", default=None, help=argparse.SUPPRESS)
    attach_revoke = attach_subparsers.add_parser("revoke", help="Revoke a grant immediately")
    attach_revoke.add_argument("grant_id")
    attach_revoke.add_argument(
        "--uninstall",
        action="store_true",
        help="Also remove the generated MCP entry from the client",
    )
    attach_revoke.add_argument("--json", dest="json_output", action="store_true")
    attach_revoke.add_argument("--state-dir", default=None, help=argparse.SUPPRESS)
    attach_serve = attach_subparsers.add_parser(
        "serve",
        help="Internal grant-bound MCP transport",
    )
    attach_serve.add_argument("--grant-id", required=True)
    attach_serve.add_argument("--token-file", required=True)
    attach_serve.add_argument("--state-dir", required=True)

    # entroly dashboard
    dash_parser = subparsers.add_parser(
        "dashboard",
        help="Launch live web dashboard showing all engine metrics",
    )
    dash_parser.add_argument(
        "--force", action="store_true",
        help="Force re-index even if persistent index exists",
    )
    dash_parser.add_argument(
        "--port", type=int, default=9378,
        help="Dashboard port (default: 9378)",
    )

    # entroly health
    health_parser = subparsers.add_parser(
        "health",
        help="Analyze codebase health (grade A-F, clones, dead code, SAST)",
    )
    health_parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Show details for each finding",
    )

    # entroly autotune
    autotune_parser = subparsers.add_parser(
        "autotune",
        help="Optimize engine hyperparameters via mutation-based search",
    )
    autotune_parser.add_argument(
        "--iterations", type=int, default=50,
        help="Number of optimization iterations (default: 50)",
    )
    autotune_parser.add_argument(
        "--rollback", action="store_true",
        help="Restore previous tuning_config.json (undo last autotune)",
    )

    # entroly go
    go_parser = subparsers.add_parser(
        "go",
        help="One command: auto-detect, init, proxy, and dashboard",
    )
    go_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port (default: 9377)",
    )
    go_parser.add_argument(
        "--quality", type=str, default=None,
        help="Override auto-detected quality (speed|fast|balanced|quality|max)",
    )
    go_parser.add_argument(
        "--force", action="store_true",
        help="Force re-index even if persistent index exists",
    )

    # entroly proxy
    proxy_parser = subparsers.add_parser(
        "proxy",
        help="Start the invisible prompt compiler proxy (any IDE)",
    )
    proxy_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port (default: 9377, or ENTROLY_PROXY_PORT)",
    )
    proxy_parser.add_argument(
        "--host", type=str, default=None,
        help="Bind host (default: 127.0.0.1, or ENTROLY_PROXY_HOST)",
    )
    proxy_parser.add_argument(
        "--quality", type=str, default=None,
        help="Quality: speed|fast|balanced|quality|max or 0.0-1.0",
    )
    proxy_parser.add_argument(
        "--force", action="store_true",
        help="Force re-index even if persistent index exists",
    )
    proxy_parser.add_argument(
        "--debug", action="store_true",
        help="Enable debug-level logging (all subsystem details to stderr)",
    )
    proxy_parser.add_argument(
        "--autotune-daemon", action="store_true",
        help="Start the benchmark autotune daemon alongside the proxy (off by default)",
    )
    proxy_parser.add_argument(
        "--bypass", action="store_true",
        help="Start in bypass mode (forward requests unmodified, no optimization)",
    )
    proxy_parser.add_argument(
        "--witness", choices=["off", "audit", "annotate", "strict"], default=None,
        help="Verify model outputs before returning them: off, audit, annotate, or strict",
    )
    proxy_parser.add_argument(
        "--witness-nli", action="store_true",
        help="Use OpenAI NLI inside WITNESS when OPENAI_API_KEY is available",
    )
    proxy_parser.add_argument(
        "--witness-embed", action="store_true",
        help="Embed WITNESS certificates in provider JSON instead of sidecar headers only",
    )
    proxy_parser.add_argument(
        "--witness-profile",
        choices=["auto", "code", "rag", "qa", "benchmark_qa", "summary", "chat", "dialogue"],
        default=None,
        help="WITNESS suppression profile (default: auto)",
    )

    # entroly optimize
    optimize_parser = subparsers.add_parser(
        "optimize",
        help="Generate optimized context snapshot for a task",
    )
    optimize_parser.add_argument(
        "--task", "-t", type=str, default="",
        help="Description of the task to optimize context for",
    )
    optimize_parser.add_argument(
        "--budget", "-b", type=int, default=8192,
        help="Token budget (default: 8192)",
    )
    optimize_parser.add_argument(
        "--format", "-f", type=str, choices=["markdown", "json"], default="markdown",
        help="Output format (default: markdown)",
    )
    optimize_parser.add_argument(
        "--quiet", "-q", action="store_true",
        help="Suppress progress output (only emit the snapshot)",
    )
    optimize_parser.add_argument(
        "--selector", type=str, choices=["auto", "knapsack", "dopt", "qccr"], default="auto",
        help="Selection objective. auto (default): qccr if task given, else knapsack. knapsack (linear), dopt (BM25 + log-det), qccr (sentence-level query-conditioned extractive + MMR).",
    )
    optimize_parser.add_argument(
        "--exclude", type=str, action="append", default=[],
        help="Substring to exclude from the fragment source path (repeatable; dopt selector only)",
    )

    # entroly ingest
    ingest_parser = subparsers.add_parser(
        "ingest",
        help="Ingest documents for Context Receipts",
    )
    ingest_parser.add_argument("path", type=str, help="Document file or directory (.md, .txt, .rst)")
    ingest_parser.add_argument("--out", type=str, default=None, help="Index JSON path (default: .entroly/receipts/index.json)")
    ingest_parser.add_argument("--chunk-tokens", type=int, default=360, help="Approximate max tokens per chunk")
    ingest_parser.add_argument("--overlap-tokens", type=int, default=32, help="Token overlap for oversized chunks")
    ingest_parser.add_argument("--python", action="store_true", help="Force the Python reference implementation")

    # entroly select
    select_parser = subparsers.add_parser(
        "select",
        help="Select context and write a Context Receipt",
    )
    select_parser.add_argument("--query", "-q", type=str, required=True, help="Question/task to select context for")
    select_parser.add_argument("--budget", "-b", type=int, default=8000, help="Token budget (default: 8000)")
    select_parser.add_argument("--index", type=str, default=None, help="Index JSON path (default: .entroly/receipts/index.json)")
    select_parser.add_argument("--docs", type=str, default=None, help="Ingest this document path on the fly")
    select_parser.add_argument("--receipt", type=str, default=None, help="Receipt JSON output path")
    select_parser.add_argument("--report", type=str, default=None, help="Markdown report output path")
    select_parser.add_argument("--chunk-tokens", type=int, default=360, help="Approximate max tokens per chunk when using --docs")
    select_parser.add_argument("--overlap-tokens", type=int, default=32, help="Token overlap for oversized chunks when using --docs")
    select_parser.add_argument("--python", action="store_true", help="Force the Python reference implementation")

    # entroly receipt
    receipt_parser = subparsers.add_parser(
        "receipt",
        help="Render a Context Receipt as Markdown",
    )
    receipt_parser.add_argument("receipt_path", type=str, help="Context Receipt JSON path")
    receipt_parser.add_argument("--out", type=str, default=None, help="Markdown output path")
    receipt_parser.add_argument("--json", action="store_true", help="Print normalized receipt JSON instead of Markdown")
    receipt_parser.add_argument("--python", action="store_true", help="Force the Python reference implementation")

    context_commit_parser = subparsers.add_parser(
        "context-commit",
        help="Create or verify a portable proof of the exact selected context",
    )
    context_commit_parser.add_argument(
        "path", nargs="?", default=None, help="Document file or directory"
    )
    context_commit_parser.add_argument(
        "--query", "-q", default=None, help="Question/task to select context for"
    )
    context_commit_parser.add_argument(
        "--budget", "-b", type=int, default=8000, help="Token budget (default: 8000)"
    )
    context_commit_parser.add_argument("--out", type=str, default=None, help="Commit JSON output path")
    context_commit_parser.add_argument("--parent", type=str, default=None, help="Parent Context Commit ID")
    context_commit_parser.add_argument("--verify", type=str, default=None, help="Verify an existing commit JSON")
    context_commit_parser.add_argument("--chunk-tokens", type=int, default=360)
    context_commit_parser.add_argument("--overlap-tokens", type=int, default=32)
    context_commit_parser.add_argument("--python", action="store_true", help="Force the Python reference implementation")
    context_commit_parser.add_argument("--json", action="store_true", help="Print the created JSON artifact")

    proof_parser = subparsers.add_parser(
        "proof",
        help="Run the durable proof-guided context and exact-recovery protocol",
    )
    proof_subparsers = proof_parser.add_subparsers(
        dest="proof_action", required=True
    )

    def _add_proof_prepare_arguments(command_parser):
        command_parser.add_argument("path", help="Document file or directory")
        command_parser.add_argument("--query", "-q", required=True)
        command_parser.add_argument("--budget", "-b", type=int, default=8000)
        command_parser.add_argument("--max-rounds", type=int, default=3)
        command_parser.add_argument("--recovery-budget", type=int, default=1200)
        command_parser.add_argument("--max-chunks-per-round", type=int, default=3)
        command_parser.add_argument(
            "--profile",
            choices=["code", "rag", "qa", "benchmark_qa", "summary", "chat", "dialogue"],
            default="rag",
        )
        command_parser.add_argument("--chunk-tokens", type=int, default=360)
        command_parser.add_argument("--overlap-tokens", type=int, default=32)
        command_parser.add_argument("--idempotency-key", default=None)
        command_parser.add_argument("--state-dir", default=None, help=argparse.SUPPRESS)
        command_parser.add_argument("--python", action="store_true")
        command_parser.add_argument(
            "--allow-high-risk",
            action="store_true",
            help="Continue only after explicitly accepting a high-review receipt",
        )

    proof_prepare = proof_subparsers.add_parser(
        "prepare",
        help="Prepare a model request without calling a provider",
    )
    _add_proof_prepare_arguments(proof_prepare)

    proof_advance = proof_subparsers.add_parser(
        "advance",
        help="Verify one model output and produce the next request or final answer",
    )
    proof_advance.add_argument("session_id")
    proof_advance.add_argument("--output", default=None)
    proof_advance.add_argument("--output-file", default=None)
    proof_advance.add_argument("--idempotency-key", required=True)
    proof_advance.add_argument("--state-dir", default=None, help=argparse.SUPPRESS)
    proof_advance.add_argument("--python", action="store_true", help=argparse.SUPPRESS)
    proof_advance.add_argument("--allow-high-risk", action="store_true", help=argparse.SUPPRESS)

    proof_inspect = proof_subparsers.add_parser(
        "inspect",
        help="Inspect the last durable response without advancing it",
    )
    proof_inspect.add_argument("session_id")
    proof_inspect.add_argument("--state-dir", default=None, help=argparse.SUPPRESS)
    proof_inspect.add_argument("--python", action="store_true", help=argparse.SUPPRESS)
    proof_inspect.add_argument("--allow-high-risk", action="store_true", help=argparse.SUPPRESS)

    proof_run = proof_subparsers.add_parser(
        "run",
        help="Run all bounded rounds through an explicit local model command",
    )
    _add_proof_prepare_arguments(proof_run)
    proof_run.add_argument(
        "--model-command",
        required=True,
        help="Command that reads request JSON on stdin and writes model text or {\"output\": ...}",
    )
    proof_run.add_argument("--model-timeout", type=float, default=120.0)
    proof_run.add_argument("--json", dest="json_output", action="store_true")

    # entroly audit
    audit_parser = subparsers.add_parser(
        "audit",
        help="Render a multi-turn session-chain audit report",
    )
    audit_parser.add_argument("session_chain", type=str, help="session_chain.json path")
    audit_parser.add_argument(
        "--taint",
        type=str,
        default=None,
        help="Optional hallucination taint JSON path (default: sibling session_taint.json or taint.json)",
    )
    audit_parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON",
    )
    audit_parser.add_argument(
        "--input-price-per-million",
        type=float,
        default=0.0,
        help="Optional input-token price for estimated per-turn cost attribution",
    )
    audit_parser.add_argument(
        "--max-turns",
        type=int,
        default=20,
        help="Maximum turns to show in the text ledger (default: 20; -1 = all, 0 = none)",
    )

    # entroly explain
    explain_parser = subparsers.add_parser(
        "explain",
        help="Explain receipt decisions such as why a chunk was omitted",
    )
    explain_parser.add_argument("--why-omitted", required=True, help="Chunk id to explain")
    explain_parser.add_argument("--receipt", type=str, default=None, help="Receipt JSON path (default: latest)")
    explain_parser.add_argument("--python", action="store_true", help="Force the Python reference implementation")

    # entroly feedback
    feedback_parser = subparsers.add_parser(
        "feedback",
        help="Signal outcome quality to improve future context selection",
    )
    feedback_parser.add_argument(
        "--score", "-s", type=float, default=None,
        help="Quality score: 0.0 (bad) to 1.0 (good). Mutually exclusive with --outcome.",
    )
    feedback_parser.add_argument(
        "--outcome", choices=["success", "good", "fail", "failure", "bad", "neutral"],
        default=None,
        help="Symbolic outcome; mapped to a score (success/good→1.0, fail/bad→0.0, neutral→0.5).",
    )
    feedback_parser.add_argument(
        "--task", type=str, default=None,
        help="Optional task description for audit logs (metadata only).",
    )

    # entroly uninstall
    uninstall_parser = subparsers.add_parser(
        "uninstall",
        help="Guided Python uninstall with optional structured exit feedback",
    )
    uninstall_parser.add_argument(
        "--reason",
        choices=[value for value, _label in _EXIT_REASON_OPTIONS],
        default=None,
        help="Structured reason for uninstalling (no free text)",
    )
    uninstall_parser.add_argument(
        "--benefit",
        choices=[value for value, _label in _EXIT_BENEFIT_OPTIONS],
        default=None,
        help="Whether useful token reduction was observed",
    )
    uninstall_parser.add_argument(
        "--surface",
        choices=[value for value, _label in _EXIT_SURFACE_OPTIONS],
        default=None,
        help="Primary Entroly surface used",
    )
    uninstall_parser.add_argument(
        "--duration",
        choices=[value for value, _label in _EXIT_DURATION_OPTIONS],
        default=None,
        help="Coarse use-duration bucket",
    )
    uninstall_parser.add_argument(
        "--send-feedback",
        action="store_true",
        help="Explicitly send the structured response without an interactive prompt",
    )
    uninstall_parser.add_argument(
        "--endpoint",
        default=None,
        help="HTTPS feedback collector for this one-time response",
    )
    uninstall_parser.add_argument(
        "--skip-feedback",
        action="store_true",
        help="Uninstall without collecting or sending an exit response",
    )
    uninstall_parser.add_argument(
        "--delete-remote-telemetry",
        action="store_true",
        help="Request deletion of recent linked telemetry before the one-time survey",
    )
    uninstall_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show the survey payload, destination, and pip command without changing anything",
    )
    uninstall_parser.add_argument(
        "--feedback-only",
        action="store_true",
        help="Collect/send feedback and revoke local telemetry without invoking pip",
    )
    uninstall_parser.add_argument(
        "-y", "--yes",
        action="store_true",
        help="Pass --yes to pip uninstall",
    )

    # entroly benchmark
    benchmark_parser = subparsers.add_parser(
        "benchmark",
        help="Run competitive benchmark: Entroly vs Raw vs Top-K",
    )
    benchmark_parser.add_argument(
        "--budget", type=int, default=4096,
        help="Token budget per query (default: 4096)",
    )
    benchmark_parser.add_argument(
        "--compare-baseline", dest="compare_baseline", action="store_true",
        help="Print the explicit baseline comparison used for the benchmark table",
    )

    def _add_local_measure_args(p):
        p.add_argument(
            "--budget", type=int, default=4096,
            help="Token budget per query (default: 4096)",
        )
        p.add_argument(
            "--baseline", type=int, default=0,
            help="Baseline tokens/query; default is min(indexed tokens, 32000)",
        )
        p.add_argument(
            "--query", action="append", default=[],
            help="Query to simulate. Repeat for multiple queries.",
        )
        p.add_argument(
            "--json", action="store_true",
            help="Emit machine-readable JSON",
        )
        p.add_argument(
            "--max-files", type=int, default=100,
            help="Maximum files to index for this local smoke estimate (default: 100; 0 = full auto-index limit)",
        )

    simulate_parser = subparsers.add_parser(
        "simulate",
        help="Estimate local token savings without calling an LLM",
    )
    _add_local_measure_args(simulate_parser)

    compress_parser = subparsers.add_parser(
        "compress",
        help="Compress a file with the content codecs and print a receipt",
    )
    compress_parser.add_argument("path", help="File to compress")
    compress_parser.add_argument(
        "--out", dest="out_path", default=None,
        help="Write the compressed form here (default: stdout is not used; "
             "only the receipt is printed)",
    )
    compress_parser.add_argument(
        "--store", dest="store_path", default=None,
        help="Recovery store path (default: <ENTROLY_DIR>/recovery.json)",
    )
    compress_parser.add_argument(
        "--query", default="", help="Query to condition document selection on",
    )
    compress_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Emit the receipt as JSON",
    )

    recover_parser = subparsers.add_parser(
        "recover",
        help="Recover the exact original bytes for a recovery digest",
    )
    recover_parser.add_argument(
        "digest", help="Recovery digest from a compress receipt (sha256:...)",
    )
    recover_parser.add_argument(
        "--store", dest="store_path", default=None,
        help="Recovery store path (default: <ENTROLY_DIR>/recovery.json)",
    )
    recover_parser.add_argument(
        "--out", dest="out_path", default=None,
        help="Write recovered bytes here (default: stdout)",
    )

    perf_parser = subparsers.add_parser(
        "perf",
        help="Measure local optimizer savings and latency without calling an LLM",
    )
    _add_local_measure_args(perf_parser)

    value_parser = subparsers.add_parser(
        "value",
        help="Show measured provider value separately from local-only reductions",
    )
    value_parser.add_argument(
        "--json",
        dest="json_output",
        action="store_true",
        help="Emit a machine-readable Context Value Receipt",
    )

    # entroly status
    status_parser = subparsers.add_parser(
        "status",
        help="Check if entroly server/proxy is running",
    )
    status_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port to check (default: 9377)",
    )
    status_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Emit a stable machine-readable local status report",
    )
    status_parser.add_argument(
        "--require-running", action="store_true",
        help="Exit nonzero when the local Entroly proxy is not ready",
    )

    # entroly config
    subparsers.add_parser(
        "config",
        help="Show current configuration",
    )

    # entroly telemetry
    telem_parser = subparsers.add_parser(
        "telemetry",
        help="Manage explicit-consent pseudonymous product-health telemetry",
    )
    telem_parser.add_argument(
        "action", choices=["on", "off", "status", "preview", "flush"],
        nargs="?", default="status",
        help="Manage product-health telemetry (default: status)",
    )
    telem_parser.add_argument(
        "--endpoint",
        default=None,
        help="HTTPS collector URL stored only after `telemetry on`",
    )
    telem_parser.add_argument(
        "--no-error-events",
        action="store_true",
        help="Collect adoption events but not coarse error categories",
    )
    telem_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Emit machine-readable status or flush output",
    )

    # entroly clean
    clean_parser = subparsers.add_parser(
        "clean",
        help="Clear cached state (checkpoints, index, pull cache)",
    )
    clean_parser.add_argument(
        "-y", "--yes", action="store_true",
        help="Skip confirmation prompt",
    )

    # entroly export
    export_parser = subparsers.add_parser(
        "export",
        help="Export learned state for sharing with teammates",
    )
    export_parser.add_argument(
        "output_path", nargs="?", default=None,
        help="Positional output path (alternative to --output).",
    )
    export_parser.add_argument(
        "-o", "--output", type=str, default=None,
        help="Output file path (default: entroly_export.json).",
    )

    # entroly import
    import_parser = subparsers.add_parser(
        "import",
        help="Import shared learned state from an export file",
    )
    import_parser.add_argument(
        "file", type=str,
        help="Path to entroly_export.json",
    )

    # entroly drift
    subparsers.add_parser(
        "drift",
        help="Detect weight drift / staleness in learned configuration",
    )

    # entroly profile
    profile_parser = subparsers.add_parser(
        "profile",
        help="Manage per-project weight profiles",
    )
    profile_parser.add_argument(
        "profile_action", choices=["save", "load", "list"],
        help="Save current config as profile, load a profile, or list profiles",
    )
    profile_parser.add_argument(
        "name", nargs="?", default=None,
        help="Profile name (defaults to project hash for 'save')",
    )

    # entroly batch
    batch_parser = subparsers.add_parser(
        "batch",
        help="Headless/CI mode: optimize batch queries from stdin or file",
    )
    batch_parser.add_argument(
        "-i", "--input", type=str, default="-",
        help="Input file with one query per line (default: stdin)",
    )
    batch_parser.add_argument(
        "--budget", type=int, default=128000,
        help="Token budget per query (default: 128000)",
    )
    batch_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Output results as JSON (for CI pipelines)",
    )
    batch_parser.add_argument(
        "--fail-over-budget", dest="fail_over_budget", action="store_true",
        help="Exit with non-zero status if any query's optimized tokens exceed --budget (for CI gating)",
    )

    # entroly demo (bounded local measurement)
    demo_parser = subparsers.add_parser(
        "demo",
        help="Quick-win demo: before/after comparison showing token savings",
    )
    _add_local_measure_args(demo_parser)

    # entroly wrap
    wrap_parser = subparsers.add_parser(
        "wrap",
        help="Start proxy, configure MCP, or print setup for a coding agent",
    )
    wrap_parser.add_argument(
        "agent", type=str, nargs="?",
        help=f"Agent to wrap: {_wrap_agent_names()}",
    )
    wrap_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port (default: 9377)",
    )
    wrap_parser.add_argument(
        "--dry-run", action="store_true",
        help="Preview actions (config writes / proxy start / agent launch) without performing them",
    )
    wrap_parser.add_argument(
        "agent_args", nargs=argparse.REMAINDER,
        help="Additional arguments passed to the agent",
    )

    # entroly unwrap
    unwrap_parser = subparsers.add_parser(
        "unwrap",
        help="Remove Entroly's persistent integration without touching other tools",
    )
    unwrap_parser.add_argument(
        "agent", type=str, nargs="?",
        help=f"Agent to unwrap: {_wrap_agent_names()}",
    )
    unwrap_parser.add_argument(
        "--dry-run", action="store_true",
        help="Preview the resulting config without writing files",
    )

    # entroly learn
    learn_parser = subparsers.add_parser(
        "learn",
        help="Analyze session for failure patterns, write corrections",
    )
    learn_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port to read feedback from (default: 9377)",
    )
    learn_parser.add_argument(
        "--apply", action="store_true",
        help="Write learnings to CLAUDE.md / AGENTS.md",
    )

    # entroly capabilities
    capabilities_parser = subparsers.add_parser(
        "capabilities",
        help="Report installed runtime capabilities without network calls",
    )
    capabilities_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Emit a stable machine-readable capability report",
    )

    # entroly doctor (Gap #52)
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Diagnose common issues: index, config, proxy, weights",
    )
    doctor_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port to check (default: 9377)",
    )
    doctor_parser.add_argument(
        "--privacy", action="store_true", default=False,
        help="Run privacy audit: verify no data leaves your machine",
    )
    doctor_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Emit a stable machine-readable local diagnostic report",
    )

    # entroly digest (Gap #44)
    digest_parser = subparsers.add_parser(
        "digest",
        help="Show weekly summary of entroly's value (tokens saved, costs, etc.)",
    )
    digest_parser.add_argument(
        "--port", type=int, default=None,
        help="Proxy port (default: 9377)",
    )

    # entroly migrate (Gap #53)
    subparsers.add_parser(
        "migrate",
        help="Auto-migrate config/index to current version format",
    )

    # entroly role (Gap #49)
    role_parser = subparsers.add_parser(
        "role",
        help="Role-based weight presets (frontend, backend, sre, data, fullstack)",
    )
    role_parser.add_argument(
        "role_action", nargs="?", choices=["list", "apply"], default="list",
        help="List available roles or apply one (default: list)",
    )
    role_parser.add_argument(
        "name", nargs="?", default=None,
        help="Role name to apply",
    )
    role_parser.add_argument(
        "--preset", type=str, default=None,
        help="Shorthand: entroly role --preset backend",
    )

    # entroly completions
    comp_parser = subparsers.add_parser(
        "completions",
        help="Generate shell completion script (bash|zsh|fish)",
    )
    comp_parser.add_argument(
        "shell", choices=["bash", "zsh", "fish"],
        help="Shell type",
    )

    # entroly compile
    compile_parser = subparsers.add_parser(
        "compile",
        help="Compile source code into persistent belief artifacts (Cross-Session Memory)",
    )
    compile_parser.add_argument(
        "directory", nargs="?", default=None,
        help="Directory to scan (default: current directory)",
    )
    compile_parser.add_argument(
        "--max-files", type=int, default=0,
        help="Maximum files to process (default: 0 = unlimited)",
    )

    # entroly verify
    subparsers.add_parser(
        "verify",
        help="Run verification pass on all beliefs (staleness, contradictions)",
    )

    verify_claims_parser = subparsers.add_parser(
        "verify-claims",
        help="Run packaged install and README smoke verification",
    )
    verify_claims_parser.add_argument(
        "--output", "-o", default=None,
        help="Machine-readable report path (default: .entroly_verification.json)",
    )
    verify_claims_parser.add_argument(
        "--max-files", type=int, default=120,
        help="Maximum files to sample for the bounded smoke check (default: 120)",
    )

    # entroly verify-code — statically verify LLM-generated code
    # Pass-through: all remaining args are forwarded to verifiers/cli.py,
    # which has its own arg parser (handles `path`, --repo, --lambda,
    # --threshold, --json, --rebuild, --max-items).
    import argparse as _argparse
    verify_code_parser = subparsers.add_parser(
        "verify-code",
        help="Statically verify LLM-generated code against the codebase symbol manifest",
    )
    verify_code_parser.add_argument(
        "verify_code_args",
        nargs=_argparse.REMAINDER,
        help="Path to source file (use '-' for stdin) plus optional flags",
    )

    # entroly sync
    sync_parser = subparsers.add_parser(
        "sync",
        help="Detect workspace changes and update beliefs (Change-Driven Pipeline)",
    )
    sync_parser.add_argument(
        "directory", nargs="?", default=None,
        help="Directory to scan (default: current directory)",
    )
    sync_parser.add_argument(
        "--max-files", type=int, default=0,
        help="Maximum files to process (default: 0 = unlimited)",
    )
    sync_parser.add_argument(
        "--force", action="store_true",
        help="Force full rescan even if no changes detected",
    )

    # entroly search
    search_parser = subparsers.add_parser(
        "search",
        help="Full-text TF-IDF search across vault beliefs (Rust engine)",
    )
    search_parser.add_argument(
        "query", nargs="+",
        help="Search query (e.g., 'knapsack optimization')",
    )
    search_parser.add_argument(
        "--top-k", type=int, default=5,
        help="Number of results to return (default: 5)",
    )

    # entroly docs
    docs_parser = subparsers.add_parser(
        "docs",
        help="Compile markdown docs (README, ARCHITECTURE, docs/) into beliefs",
    )
    docs_parser.add_argument(
        "directory", nargs="?", default=None,
        help="Project root to scan (default: current directory)",
    )
    docs_parser.add_argument(
        "--max-files", type=int, default=0,
        help="Maximum doc files to process (default: 0 = unlimited)",
    )

    # entroly share
    share_parser = subparsers.add_parser(
        "share",
        help="Generate a shareable Context Report Card for your codebase",
    )
    share_parser.add_argument(
        "--output", "-o", default="entroly-report.html",
        help="Output file path (default: entroly-report.html)",
    )

    # entroly finetune
    finetune_parser = subparsers.add_parser(
        "finetune",
        help="Export vault beliefs as JSONL training data for LLM finetuning",
    )
    finetune_parser.add_argument(
        "--output", "-o", default="training_data.jsonl",
        help="Output file path (default: training_data.jsonl)",
    )

    # entroly witness
    witness_parser = subparsers.add_parser(
        "witness",
        help="Verify and suppress unsupported factual claims",
    )
    witness_parser.add_argument(
        "--context", default=None,
        help="Evidence/context text used to verify the model output",
    )
    witness_parser.add_argument(
        "--context-file", default=None,
        help="Path to evidence/context text",
    )
    witness_parser.add_argument(
        "--output", default=None,
        help="Model output text to verify (default: stdin)",
    )
    witness_parser.add_argument(
        "--output-file", default=None,
        help="Path to model output text",
    )
    witness_parser.add_argument(
        "--mode", choices=["audit", "annotate", "strict"], default="audit",
        help="Policy to apply after verification (default: audit)",
    )
    witness_parser.add_argument(
        "--profile",
        choices=["auto", "code", "rag", "qa", "benchmark_qa", "summary", "chat", "dialogue"],
        default="auto",
        help="Workload-specific suppression profile (default: auto)",
    )
    witness_parser.add_argument(
        "--nli", action="store_true",
        help="Use OpenAI NLI when OPENAI_API_KEY is available",
    )
    witness_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Emit machine-readable JSON",
    )

    # entroly ravs
    ravs_parser = subparsers.add_parser(
        "ravs",
        help="RAVS v1 offline evaluation tools",
    )
    ravs_subparsers = ravs_parser.add_subparsers(dest="ravs_action")
    ravs_report_parser = ravs_subparsers.add_parser(
        "report",
        help="Generate offline evaluation report from RAVS event log",
    )
    ravs_report_parser.add_argument(
        "--log", type=str, default=None,
        help="Path to RAVS event JSONL log (default: ~/.entroly/ravs/events.jsonl)",
    )
    ravs_report_parser.add_argument(
        "--format", type=str, choices=["text", "json"], default="text",
        help="Output format: text (human-readable) or json (byte-stable)",
    )
    ravs_report_parser.add_argument(
        "--since", type=str, default=None,
        help="Only include traces since this time (e.g. 7d, 24h, or Unix timestamp)",
    )
    ravs_report_parser.add_argument(
        "--include-weak", action="store_true",
        help="Include weak (agent self-report) signals in headline metrics",
    )

    # entroly ravs capture — called by the PostToolUse hook
    ravs_capture_parser = ravs_subparsers.add_parser(
        "capture",
        help="Capture a tool outcome into the RAVS event log (called by PostToolUse hook)",
    )
    ravs_capture_parser.add_argument(
        "--stdin", action="store_true",
        help="Read Claude Code PostToolUse JSON payload from stdin",
    )
    ravs_capture_parser.add_argument(
        "--quiet", action="store_true",
        help="Suppress output (for hook usage)",
    )
    ravs_capture_parser.add_argument(
        "--command", dest="capture_command", type=str, default=None,
        help="Command string (used with --exit-code instead of --stdin)",
    )
    ravs_capture_parser.add_argument(
        "--exit-code", dest="exit_code", type=int, default=None,
        help="Exit code of the command",
    )
    ravs_capture_parser.add_argument(
        "--stdout", dest="stdout_text", type=str, default="",
        help="Last portion of stdout for verdict refinement",
    )
    ravs_capture_parser.add_argument(
        "--log", type=str, default=None,
        help="Override RAVS event log path",
    )

    # entroly ravs hook — install/manage PostToolUse hooks
    ravs_hook_parser = ravs_subparsers.add_parser(
        "hook",
        help="Install RAVS PostToolUse hooks into your IDE",
    )
    ravs_hook_subparsers = ravs_hook_parser.add_subparsers(dest="hook_action")
    ravs_hook_install = ravs_hook_subparsers.add_parser(
        "install",
        help="Install the PostToolUse hook into a supported IDE",
    )
    ravs_hook_install.add_argument(
        "--claude-code", action="store_true",
        help="Install into Claude Code (~/.claude/settings.json)",
    )
    ravs_hook_install.add_argument(
        "--dry-run", action="store_true",
        help="Print the merged settings without writing",
    )

    # ── daemon command ─────────────────────────────────────────────
    cache_parser = subparsers.add_parser(
        "cache",
        help="Inspect EGSC persistent cache (entries, hit rate, on-disk size)",
    )
    cache_subparsers = cache_parser.add_subparsers(dest="cache_action")
    cache_subparsers.add_parser("stats", help="Show persistent cache statistics")

    daemon_parser = subparsers.add_parser(
        "daemon",
        help="Start unified supervisor (proxy + dashboard + MCP + learning)",
    )
    daemon_parser.add_argument("--proxy-port", type=int, default=9377, help="Proxy port")
    daemon_parser.add_argument("--dashboard-port", type=int, default=9378, help="Dashboard port")
    daemon_parser.add_argument("--mcp-port", type=int, default=9379, help="MCP (SSE) port")
    daemon_parser.add_argument("--host", type=str, default="127.0.0.1", help="Bind host")
    daemon_parser.add_argument("--no-proxy", action="store_true", help="Skip proxy server")
    daemon_parser.add_argument("--no-mcp", action="store_true", help="Skip MCP server")
    daemon_parser.add_argument("--quality", type=str, default="balanced", help="Quality mode: fast/balanced/max")
    daemon_parser.add_argument("--debug", action="store_true", help="Enable debug logging")

    args = parser.parse_args()

    # First-run output would corrupt the stdio JSON-RPC stream used by an
    # attached MCP server, so the internal serve action stays protocol-clean.
    internal_attach_serve = args.command == "attach" and args.attach_action == "serve"
    machine_readable = (
        (args.command == "value" and getattr(args, "json_output", False))
        or args.command == "proof"
    )
    lifecycle_exit = args.command == "uninstall"
    if not internal_attach_serve and not machine_readable and not lifecycle_exit:
        _check_first_run()
        if args.command not in (None, "completions"):
            _check_for_update()

    _dispatch = {
        "optimize": cmd_optimize,
        "feedback": cmd_feedback,
        "uninstall": cmd_uninstall,
        "init": cmd_init,
        "serve": cmd_serve,
        "attach": cmd_attach,
        "go": cmd_go,
        "dashboard": cmd_dashboard,
        "value": cmd_value,
        "health": cmd_health,
        "autotune": cmd_autotune,
        "proxy": cmd_proxy,
        "benchmark": cmd_benchmark,
        "simulate": cmd_simulate,
        "compress": cmd_compress,
        "recover": cmd_recover,
        "perf": cmd_perf,
        "ingest": cmd_ingest,
        "select": cmd_select,
        "receipt": cmd_receipt,
        "context-commit": cmd_context_commit,
        "proof": cmd_proof,
        "audit": cmd_audit,
        "explain": cmd_explain,
        "status": cmd_status,
        "config": cmd_config,
        "clean": cmd_clean,
        "telemetry": cmd_telemetry,
        "export": cmd_export,
        "import": cmd_import,
        "drift": cmd_drift,
        "profile": cmd_profile,
        "batch": cmd_batch,
        "demo": cmd_demo,
        "doctor": cmd_doctor,
        "capabilities": cmd_capabilities,
        "digest": cmd_digest,
        "migrate": cmd_migrate,
        "role": cmd_role,
        "completions": cmd_completions,
        "compile": cmd_compile,
        "verify": cmd_verify,
        "verify-claims": cmd_verify_claims,
        "verify-code": cmd_verify_code,
        "sync": cmd_sync,
        "search": cmd_search,
        "docs": cmd_docs,
        "finetune": cmd_finetune,
        "witness": cmd_witness,
        "wrap": cmd_wrap,
        "unwrap": cmd_unwrap,
        "learn": cmd_learn,
        "share": cmd_share,
        "ravs": cmd_ravs,
        "cache": cmd_cache,
        "daemon": cmd_daemon,
    }

    handler = _dispatch.get(args.command)
    telemetry_started = __import__("time").monotonic()
    telemetry_error: BaseException | None = None
    telemetry_result = "success"
    rc = 0
    if handler:
        try:
            ret = handler(args)
            # Commands signal failure by returning a non-zero int. Returning
            # None (the common success path) keeps rc=0. This is what lets
            # `profile`/`autotune`/`doctor` exit non-zero when they print a
            # failure, instead of silently exiting 0.
            if isinstance(ret, int):
                rc = ret
        except KeyboardInterrupt:
            print(f"\n  {C.GRAY}Interrupted.{C.RESET}")
            rc = 130
            telemetry_result = "interrupted"
        except Exception as e:
            print(f"\n  {C.RED}Error:{C.RESET} {e}", file=sys.stderr)
            rc = 1
            telemetry_result = "error"
            telemetry_error = e
    else:
        parser.print_help()

    if rc not in {0, 130}:
        telemetry_result = "error"
    if handler:
        try:
            from entroly.product_telemetry import capture_cli_result, flush

            capture_cli_result(
                args.command,
                result=telemetry_result,
                elapsed_seconds=__import__("time").monotonic() - telemetry_started,
                error=telemetry_error,
            )
            flush()
        except Exception:
            # Product-health telemetry can never change a command result.
            pass

    # Flush and terminate immediately.
    #
    # We use os._exit() instead of sys.exit() because:
    #   1. The Rust engine (entroly_core via PyO3) may hold OS-level threads
    #      that Python's threading.join() cannot interrupt, causing sys.exit()
    #      to block indefinitely during interpreter shutdown.
    #   2. Python's logging shutdown flushes handlers synchronously; if the
    #      Rust engine's log sink is slow or blocked, this hangs.
    #   3. On Windows/PowerShell, sys.exit() raises SystemExit which can be
    #      misinterpreted as a failure when stderr has prior output.
    #
    # This is the standard pattern used by pip, poetry, and other CLI tools
    # that wrap native libraries.
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    os._exit(rc)


if __name__ == "__main__":
    main()
